/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import modelo.Diseño;
import modelo.Material;
import modelo.Usuario;
import persistencia.DiseñosXML;
import persistencia.MaterialesXML;
import persistencia.UsuariosXML;
/**
 *
 * @author Cristian De Sousa
 */
public class Controladora {
    
    //DECLARACIÓN DE VARIABLES
    JFrame ventana;
    JDialog subVentana;
    JTable tablaDisenos;
    JComboBox comboElegirDiseno;
    UsuariosXML datosUsua = new UsuariosXML();
    ArrayList <Usuario> listaUsuarios = datosUsua.todosLosUsuarios();
    
    DiseñosXML datosDise = new DiseñosXML();
    ArrayList <Diseño> listaDiseños = datosDise.todosLosDiseños();
    
    MaterialesXML datosMat = new MaterialesXML();
    ArrayList <Material> listaMateriales = datosMat.todosLosMateriales();
    
    //CONTROLADORA APARTADO VISUAL DE LAS VENTANAS
    public Controladora(JFrame ventana){
       this.ventana = ventana;
    }
    
    public Controladora(JDialog subVentana){
       this.subVentana = subVentana;
    }
    
    public void iniciaVentana(JFrame ventana, String ruta){
       ventana.setLocationRelativeTo(null); 
       ventana.setIconImage(new ImageIcon(ruta).getImage()); 
       ventana.setResizable(false); 
       ventana.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        
    }
    
    public void activaVentana(JFrame ventana,JFrame ventana2) {
        ventana.setLocationRelativeTo(null);
        ventana.setVisible(true);
        ventana2.dispose(); 
        
     }
    
    public void iniciaVentana(JDialog subVentana){
       subVentana.setLocationRelativeTo(null);  
       subVentana.setResizable(false); 
       
        
    }
    
    public void activaVentana(JDialog subVentana){
        subVentana.setLocationRelativeTo(null);
        subVentana.setVisible(true);
    }
    
    
    
    //CONTROLADORA VENTANA REGISTRO
        //declaración de variables
        JTextField nombre,usuarioReg,email,contrasenaReg;


        public Controladora(JFrame ventana, JTextField nombre,JTextField usuario, JTextField email, JTextField contrasena){
           this.ventana = ventana;
           this.nombre = nombre;
           this.usuarioReg = usuario;
           this.email = email;
           this.contrasenaReg = contrasena;
        }

        public void datosUsuario(ArrayList <Usuario> usuariosReg,Usuario usuarioNuevo){
            usuarioNuevo.setNombre(nombre.getText());
            usuarioNuevo.setUser(usuarioReg.getText());
            usuarioNuevo.setEmail(email.getText());
            usuarioNuevo.setContrasena(contrasenaReg.getText());
            usuariosReg.add(usuarioNuevo);       
        }
        
       
    
    //CONTROLADORA VENTANA LOGIN
        //declaración de variables
        JTextField usuarioLog;
        JPasswordField contrasenaLog;

        public Controladora (JFrame ventana, JTextField usuario, JPasswordField contrasena) {
            this.ventana = ventana;
            this.usuarioLog = usuario;
            this.contrasenaLog = contrasena;
        }
        
        //validaciones
        public boolean validarUsuario(String user) {
            boolean existeUsuario=false;
            
            if (listaUsuarios==null) {
                existeUsuario=false;
            }
            
            else {
                int n = listaUsuarios.size();
            
                for (int i=0; i<n; i++) {
                    String userReg = listaUsuarios.get(i).getUser();

                    if (userReg.equals(user)){
                        existeUsuario=true;
                        }
                }
            }
            
            return existeUsuario;
        }
        
        public Usuario usuarioActual(String user) {
            Usuario usuarioActual= new Usuario();
            int n=listaUsuarios.size();
            
            for (int i=0; i<n; i++) {
                    String userReg = listaUsuarios.get(i).getUser();

                    if (userReg.equals(user)){
                        int index=i;
                        usuarioActual = listaUsuarios.get(i);
                        }
                    
            
                }
            return usuarioActual;
        }
        
        public Diseño diseñoActual(String nombre, String user) {
            Diseño diseñoActual = new Diseño();
            int n=listaDiseños.size();
            
            for (int i=0; i<n; i++) {
                
                    String nameD = listaDiseños.get(i).getNombre();
                    String userD = listaDiseños.get(i).getUserAutor();

                    if ((nameD.equals(nombre))&&(userD.equals(user))){
                        diseñoActual = listaDiseños.get(i);
                        }
                    
            
                }
            return diseñoActual;
        }
        
        public boolean validarContrasena(String user, String contrasena) {
            boolean coincideContrasena=true;
            
            int n = listaUsuarios.size();
            
            for (int i=0; i<n; i++) {
                String userReg = listaUsuarios.get(i).getUser();
                
                
                if (userReg.equals(user)){
                    String contraReg = listaUsuarios.get(i).getContrasena();
                    if (!contraReg.equals(contrasena)) {
                        coincideContrasena=false;
                    }
                }
                
                
            }
            return coincideContrasena;
            
        }
        
        public String obtenerNametag(String user) {
            String nametag="";
            
            int n = listaUsuarios.size();
            
            for (int i=0; i<n; i++) {
                String userReg = listaUsuarios.get(i).getUser();
                
                
                if (userReg.equals(user)){
                    nametag = listaUsuarios.get(i).getNombre();
                }
            
            }
            return nametag;
        }
        
       
        
    //CONTROLADORA VENTANA PRINCIPAL
        //declaración de variables
        JLabel nametag,diseñar_btn,comprarbtn,misDiseños_btn,salir_btn;
        String name;
        
        public Controladora(JFrame ventana, String name,JLabel nametag, JLabel botonDiseñar, JLabel botonComprar, JLabel botonMisDiseños, JLabel botonSalir) {
            this.name=name;
            this.ventana=ventana;
            this.nametag=nametag;
            this.diseñar_btn=botonDiseñar;
            this.comprarbtn=botonComprar;
            this.misDiseños_btn=botonMisDiseños;
            this.salir_btn=botonSalir;
        }
        
        
        
        
    //CONTROLADORA VENTANA DISEÑAR TIPO
        JPanel pExterior, pInterior;
        
        public Controladora(JFrame ventana, JPanel exterior, JPanel interior) {
            this.pExterior=exterior;
            this.pInterior=interior;
        }
        
    //CONTROLADORA VENTANA DISEÑAR MEDIDAS
        JTextField campoMedidas;
        public Controladora(JFrame ventana, JTextField medidas) {
            campoMedidas=medidas;
        }
        
       
        public boolean validarMedida(int m) {
            boolean medidaValida=false;
            if ((m>9)&&(m<31)) {
                medidaValida=true;
            }
            return medidaValida;
        }
        
        
     //CONTROLADORA VENTANA DISEÑAR NOMBRE
        
        public boolean validarNombre(ArrayList <Diseño> disponibles,String nombre, String user) {
            boolean existeNombre=false;
            Diseño diseño = new Diseño();
            
            for (int i=0; i<disponibles.size();i++) {
                diseño = disponibles.get(i);
                
                if ((diseño.getUserAutor().equals(user))&&(diseño.getNombre().equals(nombre))) {
                    existeNombre=true;
                }
                        
                
            }
            return existeNombre;
        }
     
        


    //CONTROLADORA RESUMEN DE DISEÑO
        
        JLabel nombreD,tipoD,medidasD,estiloD;
        
        public Controladora(JFrame Ventana,JLabel nombre1, JLabel tipo1, JLabel medidas1, JLabel estilo1) {
            this.ventana=Ventana;
            this.nombreD=nombre1;
            this.tipoD=tipo1;
            this.medidasD=medidas1;
            this.estiloD=estilo1;
            
            
        }
        
        

    
    
    
    
    //CONTROLADORA VENTANA COMPRAR
    
    public Controladora(JFrame ventana, JTable tablaDisenos, JComboBox comboElegirDiseno) {
        this.ventana = ventana;
        this.tablaDisenos = tablaDisenos;
        this.comboElegirDiseno = comboElegirDiseno;
     }
    public void llenarTabla(ArrayList<Diseño> diseños, JTable tablaDiseñosDisponibles){  
      
      String[] columna = { "Nombre", "Estilo" };
      DefaultTableModel dtm = new DefaultTableModel(null,columna);
      
      for (Diseño diseño : diseños)
          {
            String[] row = {diseño.getNombre(), diseño.getEstilo() };
            dtm.addRow(row);
          }
      tablaDiseñosDisponibles.setModel(dtm);

    }
    
    public void llenarCombo(JComboBox opciones, ArrayList <Diseño> diseños)
      { 
        int n= diseños.size();
        for (int i=0; i<n;i++) {
            opciones.addItem(diseños.get(i).getNombre());
        }
        
      }
    
    public void activa_Desactiva(boolean verdadOFalso, JButton boton){
      boton.setEnabled(verdadOFalso);
    }
    
    public void activa_Desactiva2(boolean verdadOFalso, JSpinner spinner){
      spinner.setEnabled(verdadOFalso);
    }
    
    public void activa_Desactiva3(boolean verdadOFalso, JLabel label){
      label.setEnabled(verdadOFalso);
    }
    
    public void super_Spinners (JCheckBox button, JSpinner spinner, JLabel label){
        if (button.isSelected()){
            spinner.setValue(1);
            activa_Desactiva2(true, spinner);
            activa_Desactiva3(true, label);
        }
        else{
            spinner.setValue(0);
            activa_Desactiva2(false, spinner);
        }
    }
    
    public void spinner_Off(JSpinner S){
        S.setValue(0);
        S.setEnabled(false);
    }
    
    public void chequear_Spinners(JCheckBox B, JSpinner S, ArrayList<Material> L, String nombre, String rubro, double costo, String diseno){
        if (B.isSelected()){
            Material mat = new Material(nombre, rubro, (int) S.getValue(), costo, diseno);
            L.add(mat);
        }
    }
    
    public void llenar_tabla_materiales(JTable tablamateriales, ArrayList<Material> materiales){
        String[] columna = { "Material", "Rubro", "Cantidad", "Costo P/U", "Costo Total" };
        DefaultTableModel dtm = new DefaultTableModel(null,columna);
        for (Material mat : materiales)
            {
                String[] row = {mat.getNombre(), mat.getRubro(),Integer.toString(mat.getCantidad()), Double.toString(mat.getCostound()), Double.toString(mat.getCostound()*mat.getCantidad())};
                dtm.addRow(row);
            }
        tablamateriales.setModel(dtm);
    }
    
    public String costo_Final(ArrayList<Material> materiales){
        double suma = 0;
        for(Material mat : materiales){
            double cont = mat.getCantidad()*mat.getCostound();
            suma += cont;
        }
        String costototal = Double.toString(suma);
        return costototal;
    }
    
    
    //CONTROLADORA MIS DISEÑOS
    public void llenarTablaDiseños(ArrayList<Diseño> diseños, JTable tablaMisDiseños){  
      
      String[] columna = { "Nombre", "Tipo","Medidas","Estilo","Costo Total" };
      DefaultTableModel dtm = new DefaultTableModel(null,columna);
      
      for (Diseño diseño : diseños)
          {
            String[] row = {diseño.getNombre(), diseño.getTipo(),diseño.getMedidas(), diseño.getEstilo(), (diseño.getCostoTotal()+"$") };
            dtm.addRow(row);
          }
      tablaMisDiseños.setModel(dtm);

    }
    
    public void llenarTablaMisMateriales(ArrayList<Material> materiales, JTable tablaMisDiseños){  
      
      String[] columna = { "Nombre", "Rubro","Cantidad","Costo P/U","Costo Total" };
      DefaultTableModel dtm = new DefaultTableModel(null,columna);
      
      for (Material material : materiales)
          { 
            int cantidadint = material.getCantidad();
            String cantidad = Integer.toString(cantidadint);
            
            double costouint = material.getCostound();
            String costou = Double.toString(costouint);
            
            double costotint = material.getCostototal();
            String costot = Double.toString(costotint);
            
            String[] row = {material.getNombre(), material.getRubro(),cantidad, (costou +"$"), (costot+"u") };
            dtm.addRow(row);
          }
      tablaMisDiseños.setModel(dtm);

    }
    
    //CONTROLADORA ALMACENAMIENTO USUARIOS
     public void salvarUsuario(UsuariosXML datosUsua,JTextField txtNombre,JTextField txtUser, JTextField txtEmail, JTextField txtContrasena){
     
        Usuario usua = new Usuario();
                   usua.setNombre(txtNombre.getText());
                   usua.setUser(txtUser.getText());
                   usua.setEmail(txtEmail.getText());
                   usua.setContrasena(txtContrasena.getText());
                   datosUsua.actualizarUsuario(usua, usua.getUser());
    }
    
     public void salvarUsuario(UsuariosXML datosUsua, Usuario usua, String userOriginal){

        datosUsua.actualizarUsuario(usua, userOriginal);
    }
    
     public void eliminarCuenta(UsuariosXML datosUsua, String user){
     
         datosUsua.borrarUsuario(user);
         
     }
     
     //CONTROLADORA ALMACENAMIENTO DISEÑOS
     
     public void guardarDiseño(DiseñosXML datosDiseño, Diseño diseño){
      
        datosDiseño.agregarDiseño(diseño);
    }
     
     public void actualizarDiseño(DiseñosXML datosDise, Diseño nuevoD, String nombreOriginal){

        datosDise.actualizarDiseño(nuevoD,nombreOriginal);
    }
     
    public void eliminarDiseño(DiseñosXML datosDise, String nombre){
     
         datosDise.borrarDiseño(nombre);
         
     }
     public int diseñosUsuarioSize(String user, ArrayList<Diseño> disponibles) {
     
      Diseño diseño = new Diseño();
      int size=0;
      for (int i=0; i<disponibles.size();i++) {
          diseño = disponibles.get(i);
          
          if ((diseño.getUserAutor().equals(user))) {
              size++;
          }
      }
     
        return size;
    }
     
    public int misDiseñosSize(String user, ArrayList<Diseño> disponibles) {
     
      Diseño diseño = new Diseño();
      int size=0;
      for (int i=0; i<disponibles.size();i++) {
          diseño = disponibles.get(i);
          
          if ((diseño.getUserAutor().equals(user))&&(diseño.getTerminado().equals("1"))) {
              size++;
          }
      }
     
        return size;
    }
     
     public ArrayList<Diseño> llenarMisCompras(String user) {
      ArrayList<Diseño> diseñosDisponibles = new ArrayList<Diseño>();
      Diseño diseño = new Diseño();
      for (int i=0; i<listaDiseños.size();i++) {
          diseño = listaDiseños.get(i);
          
          if ((diseño.getTerminado().equals("0"))&&(diseño.getUserAutor().equals(user))) {
              diseñosDisponibles.add(diseño);
          }
      }
     
        return diseñosDisponibles;
    }
     
     public ArrayList<Diseño> llenarMisDiseños(String user) {
         
      
      ArrayList<Diseño> diseñosDisponibles = new ArrayList<Diseño>();
      Diseño diseño = new Diseño();
      for (int i=0; i<listaDiseños.size();i++) {
          diseño = listaDiseños.get(i);
          
          if ((diseño.getTerminado().equals("1"))&&(diseño.getUserAutor().equals(user))) {
              diseñosDisponibles.add(diseño);
          }
      }
     
        return diseñosDisponibles;
    }
    
     
    //CONTROLADORA ALMACENAMIENTO MATERIALES
    
    public void guardarMaterial(MaterialesXML datosMaterial, Material material){
      
        datosMaterial.agregarMaterial(material);
    }
    
    public ArrayList<Material> llenarMisMateriales(String nombre) {
      ArrayList<Material> materialesDelDiseño = new ArrayList<Material>();
      Material material =new Material ();
      for (int i=0; i<listaMateriales.size();i++) {
          material = listaMateriales.get(i);
          
          if (material.getDiseno().equals(nombre)) {
              materialesDelDiseño.add(material);
          }
      }
     
        return materialesDelDiseño;
    }
                                                                      
   
}
    
    
    
    
    
