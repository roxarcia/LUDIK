/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;


import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import modelo.Usuario;

public class VentanaDiseñarTipo extends javax.swing.JFrame {

    Object[] opciones = {"Sí", "No"};
    ArrayList<String> camposDiseño;
    boolean interiorClickeado=false;
    boolean exteriorClickeado=false;
    Usuario usuarioActual;
    
    Controladora control;
    public VentanaDiseñarTipo() {
        initComponents();
        control= new Controladora(this,panelExterior,panelInterior);
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        this.camposDiseño= new ArrayList<>();
        this.usuarioActual= new Usuario();
    }
    
    public VentanaDiseñarTipo(Usuario usuario) {
        initComponents();
        control= new Controladora(this,panelExterior,panelInterior);
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        this.camposDiseño= new ArrayList<>();
        this.usuarioActual=usuario;
    }
    
    public VentanaDiseñarTipo(Usuario usuario,ArrayList<String> campos) {
        initComponents();
        control= new Controladora(this,panelExterior,panelInterior);
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        this.camposDiseño=campos;
        this.usuarioActual=usuario;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        Banner1 = new javax.swing.JLabel();
        Plano1 = new javax.swing.JLabel();
        Plano2 = new javax.swing.JLabel();
        Seleccion1 = new javax.swing.JLabel();
        Salir1 = new javax.swing.JLabel();
        Continuar1 = new javax.swing.JLabel();
        panelInterior = new javax.swing.JPanel();
        iconoInterior = new javax.swing.JLabel();
        Interior = new javax.swing.JLabel();
        panelExterior = new javax.swing.JPanel();
        iconoExterior1 = new javax.swing.JLabel();
        Exterior1 = new javax.swing.JLabel();
        progressbar1 = new javax.swing.JPanel();
        progressbar = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Banner1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Diseñar.PNG"))); // NOI18N
        Fondo.add(Banner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1070, 140));

        Plano1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano2.PNG"))); // NOI18N
        Fondo.add(Plano1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 270, 360));

        Plano2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano1.PNG"))); // NOI18N
        Fondo.add(Plano2, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 190, 200, 360));

        Seleccion1.setBackground(new java.awt.Color(0, 74, 173));
        Seleccion1.setFont(new java.awt.Font("Questrial", 0, 36)); // NOI18N
        Seleccion1.setForeground(new java.awt.Color(0, 74, 173));
        Seleccion1.setText("Seleccione el tipo de kiosco lúdico...");
        Fondo.add(Seleccion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 200, 600, -1));

        Salir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/homeIcon.PNG"))); // NOI18N
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Salir1MouseClicked(evt);
            }
        });
        Fondo.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 540, 120, 90));

        Continuar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/continuar1.PNG"))); // NOI18N
        Continuar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Continuar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Continuar1MouseClicked(evt);
            }
        });
        Fondo.add(Continuar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 550, 100, 80));

        panelInterior.setBackground(new java.awt.Color(255, 255, 255));
        panelInterior.setForeground(new java.awt.Color(0, 255, 255));
        panelInterior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelInteriorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelInteriorMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelInteriorMousePressed(evt);
            }
        });
        panelInterior.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoInterior.setBackground(new java.awt.Color(0, 204, 204));
        iconoInterior.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Interior1.PNG"))); // NOI18N
        iconoInterior.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelInterior.add(iconoInterior, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 20, 200, 210));

        Interior.setBackground(new java.awt.Color(0, 74, 173));
        Interior.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Interior.setForeground(new java.awt.Color(0, 204, 204));
        Interior.setText("INTERIOR");
        panelInterior.add(Interior, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 140, 70));

        Fondo.add(panelInterior, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, 270, 280));

        panelExterior.setBackground(new java.awt.Color(255, 255, 255));
        panelExterior.setForeground(new java.awt.Color(0, 255, 255));
        panelExterior.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelExteriorMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelExteriorMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelExteriorMousePressed(evt);
            }
        });
        panelExterior.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoExterior1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Exterior1.PNG"))); // NOI18N
        iconoExterior1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelExterior.add(iconoExterior1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 190, 210));

        Exterior1.setBackground(new java.awt.Color(0, 74, 173));
        Exterior1.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Exterior1.setForeground(new java.awt.Color(0, 204, 204));
        Exterior1.setText("EXTERIOR");
        panelExterior.add(Exterior1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, 140, 70));

        Fondo.add(panelExterior, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 270, 270, 280));

        progressbar1.setBackground(new java.awt.Color(150, 242, 242));
        Fondo.add(progressbar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 90, 20));

        progressbar.setBackground(new java.awt.Color(218, 238, 241));

        javax.swing.GroupLayout progressbarLayout = new javax.swing.GroupLayout(progressbar);
        progressbar.setLayout(progressbarLayout);
        progressbarLayout.setHorizontalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        progressbarLayout.setVerticalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        Fondo.add(progressbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 340, 20));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void panelExteriorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelExteriorMousePressed
       exteriorClickeado=true;
       Seleccion1.setForeground(new Color (0,74,173));
       panelExterior.setBackground(new Color(229,254,255));
       panelExterior.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
       
       
       panelInterior.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelInterior.setBackground(new Color(255,255,255));
       interiorClickeado=false;
       
       
    }//GEN-LAST:event_panelExteriorMousePressed

    private void panelInteriorMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelInteriorMousePressed
       interiorClickeado=true;
       Seleccion1.setForeground(new Color (0,74,173));
       panelInterior.setBackground(new Color(229,254,255));
       panelInterior.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
      
       panelExterior.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelExterior.setBackground(new Color(255,255,255));
       exteriorClickeado=false;
       
       
    }//GEN-LAST:event_panelInteriorMousePressed

    private void panelExteriorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelExteriorMouseEntered
       if (exteriorClickeado==false) {
           panelExterior.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelExteriorMouseEntered

    private void panelExteriorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelExteriorMouseExited
        if (exteriorClickeado==false) {
            panelExterior.setBackground(new Color(255,255,255));
        }
    }//GEN-LAST:event_panelExteriorMouseExited

    private void panelInteriorMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelInteriorMouseEntered
        if ((interiorClickeado==false)) {
           panelInterior.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelInteriorMouseEntered

    private void panelInteriorMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelInteriorMouseExited
        if (interiorClickeado==false) {
            panelInterior.setBackground(new Color(255,255,255));
        }
    }//GEN-LAST:event_panelInteriorMouseExited

    private void Continuar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Continuar1MouseClicked
        if ((interiorClickeado==false)&&(exteriorClickeado==false)) {
            Seleccion1.setForeground(new Color (204,0,51));
        }
        
        else if (camposDiseño.size()<1) {
            if (interiorClickeado==true) {
                camposDiseño.add("Interior");
            }
            else {
                camposDiseño.add("Exterior");
            }
            VentanaDiseñarMedidas ventana = new VentanaDiseñarMedidas(usuarioActual,camposDiseño);
            ventana.usuarioActual = usuarioActual;

            ventana.camposDiseño = camposDiseño;
            control.activaVentana(ventana, this);
        }
        else {
            if (interiorClickeado==true) {
                camposDiseño.set(0,"Interior");
            }
            else {
                camposDiseño.set(0,"Exterior");
            }
            
            VentanaDiseñarMedidas ventana = new VentanaDiseñarMedidas(usuarioActual,camposDiseño);
            ventana.usuarioActual = usuarioActual;

            ventana.camposDiseño = camposDiseño;
            control.activaVentana(ventana, this);
        }
        
        
    }//GEN-LAST:event_Continuar1MouseClicked

    private void Salir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseClicked
        UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 12));
        UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 12));
        int confirmacion = JOptionPane.showOptionDialog(
            null, "¿Seguro quieres salir? Perderás tu progreso.", "Confirmación",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, new ImageIcon("src/images/ventanaPrincipal/aviso_icono.png"), opciones, opciones[0]);
        
        if (confirmacion == 0){
            VentanaPrincipal ventana = new VentanaPrincipal(usuarioActual);
            ventana.usuarioActual = usuarioActual;
            control.activaVentana(ventana, this);
        }
        
    }//GEN-LAST:event_Salir1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarTipo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarTipo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarTipo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarTipo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaDiseñarTipo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Banner1;
    private javax.swing.JLabel Continuar1;
    private javax.swing.JLabel Exterior1;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Interior;
    private javax.swing.JLabel Plano1;
    private javax.swing.JLabel Plano2;
    private javax.swing.JLabel Salir1;
    private javax.swing.JLabel Seleccion1;
    private javax.swing.JLabel iconoExterior1;
    private javax.swing.JLabel iconoInterior;
    private javax.swing.JPanel panelExterior;
    private javax.swing.JPanel panelInterior;
    private javax.swing.JPanel progressbar;
    private javax.swing.JPanel progressbar1;
    // End of variables declaration//GEN-END:variables
}
