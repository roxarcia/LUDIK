/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import AppPackage.AnimationClass;
import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Diseño;
import modelo.Usuario;
import persistencia.DiseñosXML;

public class VentanaDiseñarNombre extends javax.swing.JFrame {
    
    ArrayList <String> camposDiseño;
    DiseñosXML datosDise = new DiseñosXML();
    ArrayList <Diseño> diseñosDisponibles = datosDise.todosLosDiseños();
    Usuario usuarioActual;
    boolean bordeInterior=false;
    boolean bordeExterior=false;
    boolean interiorClickeado=false;
    boolean exteriorClickeado=false;
    
    Controladora control;
    public VentanaDiseñarNombre() {
        initComponents();
        control= new Controladora(this);
        this.camposDiseño= new ArrayList<>();
        this.usuarioActual=new Usuario();
        this.diseñosDisponibles=new ArrayList<>();
        
        
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
    }
    
    public VentanaDiseñarNombre(Usuario user,ArrayList <String> campos) {
        initComponents();
        control= new Controladora(this);
        this.camposDiseño= campos;
        this.usuarioActual=user;
        this.diseñosDisponibles=new ArrayList<>();
        diseñosDisponibles=datosDise.todosLosDiseños();
        
        
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
    }


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        errorNombre = new javax.swing.JLabel();
        progressbar1 = new javax.swing.JPanel();
        progressbar = new javax.swing.JPanel();
        Plano1 = new javax.swing.JLabel();
        Plano2 = new javax.swing.JLabel();
        Salir1 = new javax.swing.JLabel();
        Continuar1 = new javax.swing.JLabel();
        Seleccion2 = new javax.swing.JLabel();
        Banner1 = new javax.swing.JLabel();
        nombreDiseno = new javax.swing.JTextField();
        FondoCampo = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        errorNombre.setBackground(new java.awt.Color(0, 74, 173));
        errorNombre.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        errorNombre.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(errorNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 450, 480, 30));

        progressbar1.setBackground(new java.awt.Color(150, 242, 242));
        Fondo.add(progressbar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 340, 20));

        progressbar.setBackground(new java.awt.Color(218, 238, 241));

        javax.swing.GroupLayout progressbarLayout = new javax.swing.GroupLayout(progressbar);
        progressbar.setLayout(progressbarLayout);
        progressbarLayout.setHorizontalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        progressbarLayout.setVerticalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        Fondo.add(progressbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 340, 20));

        Plano1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Diseñar.PNG"))); // NOI18N
        Fondo.add(Plano1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1070, 140));

        Plano2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano1.PNG"))); // NOI18N
        Fondo.add(Plano2, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 190, 200, 360));

        Salir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/boton_continuar_invertido.png"))); // NOI18N
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Salir1MouseClicked(evt);
            }
        });
        Fondo.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 550, 90, 80));

        Continuar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/continuar1.PNG"))); // NOI18N
        Continuar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Continuar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Continuar1MouseClicked(evt);
            }
        });
        Fondo.add(Continuar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 550, 100, 80));

        Seleccion2.setBackground(new java.awt.Color(0, 74, 173));
        Seleccion2.setFont(new java.awt.Font("Questrial", 0, 36)); // NOI18N
        Seleccion2.setForeground(new java.awt.Color(0, 74, 173));
        Seleccion2.setText("Asigne un nombre a su kiosco lúdico...");
        Fondo.add(Seleccion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 230, 610, -1));

        Banner1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano2.PNG"))); // NOI18N
        Fondo.add(Banner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 270, 360));

        nombreDiseno.setFont(new java.awt.Font("Garet Heavy", 0, 36)); // NOI18N
        nombreDiseno.setForeground(new java.awt.Color(204, 204, 204));
        nombreDiseno.setText("Nombre");
        nombreDiseno.setBorder(null);
        nombreDiseno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                nombreDisenoMousePressed(evt);
            }
        });
        nombreDiseno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreDisenoActionPerformed(evt);
            }
        });
        Fondo.add(nombreDiseno, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 380, 310, 40));

        FondoCampo.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampoLayout = new javax.swing.GroupLayout(FondoCampo);
        FondoCampo.setLayout(FondoCampoLayout);
        FondoCampoLayout.setHorizontalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FondoCampoLayout.setVerticalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 430, 480, 5));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nombreDisenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreDisenoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreDisenoActionPerformed

    private void nombreDisenoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nombreDisenoMousePressed
        nombreDiseno.setText("");
        nombreDiseno.setForeground(new Color(0,74,173));
        FondoCampo.setBackground(new Color(0,74,173));
        Seleccion2.setForeground(new Color (0,74,173));
        errorNombre.setText("");
    }//GEN-LAST:event_nombreDisenoMousePressed

    private void Continuar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Continuar1MouseClicked
        String usuario = usuarioActual.getUser();
        if (nombreDiseno.getText().equals("Nombre")) {
            Seleccion2.setForeground(new Color (204,0,51));
            FondoCampo.setBackground(new Color(204,0,51));
        }
        
        else if ((control.validarNombre(diseñosDisponibles, nombreDiseno.getText(), usuario))==true) {
            FondoCampo.setBackground(new Color(204,0,51));
            errorNombre.setText("Ya tiene un diseño con ese nombre.");
            errorNombre.setForeground(new Color(204,0,51));
        }
        
        else {
            
            if (camposDiseño.size()<4) {
                camposDiseño.add(nombreDiseno.getText());
            }
            else {
                camposDiseño.set(3,nombreDiseno.getText());
            }
       
            VentanaDiseñarResumen ventana = new VentanaDiseñarResumen(usuarioActual,camposDiseño);
            ventana.camposDiseño=camposDiseño;
            ventana.usuarioActual=usuarioActual;
            control.activaVentana(ventana, this);
        }
    }//GEN-LAST:event_Continuar1MouseClicked

    private void Salir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseClicked

        VentanaDiseñarEstilo ventana = new VentanaDiseñarEstilo(usuarioActual,camposDiseño);
        ventana.camposDiseño=camposDiseño;
        ventana.usuarioActual=usuarioActual;
        control.activaVentana(ventana, this);
    }//GEN-LAST:event_Salir1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarNombre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarNombre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarNombre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarNombre.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaDiseñarNombre().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Banner1;
    private javax.swing.JLabel Continuar1;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoCampo;
    private javax.swing.JLabel Plano1;
    private javax.swing.JLabel Plano2;
    private javax.swing.JLabel Salir1;
    private javax.swing.JLabel Seleccion2;
    private javax.swing.JLabel errorNombre;
    private javax.swing.JTextField nombreDiseno;
    private javax.swing.JPanel progressbar;
    private javax.swing.JPanel progressbar1;
    // End of variables declaration//GEN-END:variables
}
