/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import modelo.Utilitaria;
import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.event.DocumentEvent; 
import javax.swing.event.DocumentListener;
import modelo.Usuario;
import persistencia.UsuariosXML;


public class VentanaRegistro extends javax.swing.JFrame {
    
    Controladora control;
    ArrayList <Usuario> usuarios;
    Usuario userBase;
    Utilitaria util;
    UsuariosXML datosUsua = new UsuariosXML();
    private javax.swing.JLabel mensajeError;
    private String patronEmail = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.com$";
    private Boolean habilitar1 = false, habilitar2 = false, habilitar3 = false, habilitar4 = false, habilitar5 = false, habilitar6 = false;

    public VentanaRegistro() {
        initComponents();
        
        
        control= new Controladora(this,IngreseNombre,IngreseUsuario,IngreseEmail,CreeContrasena);
        this.usuarios= new ArrayList<>();
        userBase = new Usuario("elraul123","Raúl Pineda","12345678","raul@gmail.com");
        usuarios.add(userBase);
        focus_btn.requestFocus();
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        
        IngreseNombre.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
                if(IngreseNombre.getText().equals("¿Cómo le gustaría ser llamado?") || IngreseNombre.getText().equals("")){
                    habilitar1 = false;
                }else{
                    habilitar1 = true;
                }
                habilitarHecho(IngreseNombre, "¿Cómo le gustaría ser llamado?");
                
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                if(IngreseNombre.getText().equals("¿Cómo le gustaría ser llamado?") || IngreseNombre.getText().equals("")){
                    habilitar1 = false;
                }else{
                    habilitar1 = true;
                }
                habilitarHecho(IngreseNombre, "¿Cómo le gustaría ser llamado?");
                
            }
            
            @Override 
            public void changedUpdate(DocumentEvent e) { 

            }
            
            
        });
        
        IngreseUsuario.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
                habilitar2 = actualizarEstado(util.cantidadDeCaracteres(IngreseUsuario, 4), IngreseUsuario, FondoCampo2, mensajeError2_label, "El nombre debe tener al menos 4 carácteres");
                if (habilitar2){
                    habilitar6 = actualizarEstado(util.usuarioExistente(IngreseUsuario), IngreseUsuario, FondoCampo2, mensajeError2_label, "El usuario ya se encuentra registrado");
                }
                habilitarHecho(IngreseUsuario, "Cree su usuario con al menos 4 carácteres.");
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                habilitar2 = actualizarEstado(util.cantidadDeCaracteres(IngreseUsuario, 4), IngreseUsuario, FondoCampo2, mensajeError2_label, "El nombre debe tener al menos 4 carácteres");
                if (habilitar2){
                    habilitar6 = actualizarEstado(util.usuarioExistente(IngreseUsuario), IngreseUsuario, FondoCampo2, mensajeError2_label, "El usuario ya se encuentra registrado");
                }
                habilitarHecho(IngreseUsuario, "Cree su usuario con al menos 4 carácteres.");
            }
            
            @Override 
            public void changedUpdate(DocumentEvent e) { 

            }
            
            
        });
        
        
        IngreseEmail.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
                habilitar3 = actualizarEstado(util.validarPatron(patronEmail, IngreseEmail.getText()), IngreseEmail, FondoCampo3, mensajeError3_label, "El correo no cumple con: ejemplo@dominio.com");
                habilitarHecho(IngreseEmail, "Ingrese su dirección de correo electrónico.");
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                habilitar3 = actualizarEstado(util.validarPatron(patronEmail, IngreseEmail.getText()), IngreseEmail, FondoCampo3, mensajeError3_label, "El correo no cumple con: ejemplo@dominio.com");
                habilitarHecho(IngreseEmail, "Ingrese su dirección de correo electrónico.");
            }
            
            @Override 
            public void changedUpdate(DocumentEvent e) { 

            }
            
            
        });
        
        CreeContrasena.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
                habilitar4 = actualizarEstado(util.cantidadDeCaracteres(CreeContrasena, 8), CreeContrasena, FondoCampo4, mensajeError4_label, "La contraseña debe tener al menos 8 carácteres");
                if (!ConfirmarContra.getText().isEmpty()&&!ConfirmarContra.getText().equals("Confirme su contraseña.")) {
                  habilitar5 = actualizarEstado(util.confirmarContrasena(ConfirmarContra, CreeContrasena), CreeContrasena, FondoCampo5, mensajeError5_label, "Las contraseñas deben ser iguales"); 
                }
                habilitarHecho(CreeContrasena, "Cree una contraseña con al menos 8 carácteres.");
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                habilitar4 = actualizarEstado(util.cantidadDeCaracteres(CreeContrasena, 8), CreeContrasena, FondoCampo4, mensajeError4_label, "La contraseña debe tener al menos 8 carácteres");
                if (!ConfirmarContra.getText().isEmpty()&&!ConfirmarContra.getText().equals("Confirme su contraseña.")) {
                  habilitar5 = actualizarEstado(util.confirmarContrasena(ConfirmarContra, CreeContrasena), CreeContrasena, FondoCampo5, mensajeError5_label, "Las contraseñas deben ser iguales");  
                }
                habilitarHecho(CreeContrasena, "Cree una contraseña con al menos 8 carácteres.");
            }
            
            @Override 
            public void changedUpdate(DocumentEvent e) { 
                //no lleva nada
            }
            
            
        });
        
        ConfirmarContra.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void insertUpdate(DocumentEvent e) {
                habilitar5 = actualizarEstado(util.confirmarContrasena(ConfirmarContra, CreeContrasena), ConfirmarContra, FondoCampo5, mensajeError5_label, "Las contraseñas deben ser iguales");
                habilitarHecho(ConfirmarContra, "Confirme su contraseña.");
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                habilitar5 = actualizarEstado(util.confirmarContrasena(ConfirmarContra, CreeContrasena), ConfirmarContra, FondoCampo5, mensajeError5_label, "Las contraseñas deben ser iguales");
                habilitarHecho(ConfirmarContra, "Confirme su contraseña.");
            }
            
            @Override 
            public void changedUpdate(DocumentEvent e) { 

            }
            
            
        });
        
    
    }
    
    public Boolean actualizarEstado(Boolean invalid, JTextField textField, JPanel panel, JLabel mensajeError, String texto){
        if(invalid){
            if(!textField.getText().isEmpty()){
                panel.setBackground(new java.awt.Color(204,0,51));
                mensajeError.setText(texto);
            }else{
                mensajeError.setText("");
            }
            return false;
            
        }else{
            panel.setBackground(new Color(0,74,173));
            mensajeError.setText("");
            return true;
        }
    }
    
    public void habilitarHecho(JTextField entrada, String texto){
        if(habilitar1 && habilitar2 && habilitar3 && habilitar4 && habilitar5 && habilitar6 && !entrada.getText().equals(texto)){
            hecho_btn.setEnabled(true);
        }else{
            hecho_btn.setEnabled(false);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        Banner = new javax.swing.JLabel();
        bannerRegistrarse = new javax.swing.JLabel();
        Nombre = new javax.swing.JLabel();
        IngreseNombre = new javax.swing.JTextField();
        arroba = new javax.swing.JLabel();
        FondoCampo1 = new javax.swing.JPanel();
        Usuario = new javax.swing.JLabel();
        IngreseUsuario = new javax.swing.JTextField();
        FondoCampo2 = new javax.swing.JPanel();
        Email = new javax.swing.JLabel();
        IngreseEmail = new javax.swing.JTextField();
        FondoCampo3 = new javax.swing.JPanel();
        Contrasena = new javax.swing.JLabel();
        CreeContrasena = new javax.swing.JTextField();
        FondoCampo4 = new javax.swing.JPanel();
        ContraConfirmada = new javax.swing.JLabel();
        ConfirmarContra = new javax.swing.JTextField();
        FondoCampo5 = new javax.swing.JPanel();
        cancelar_btn = new javax.swing.JLabel();
        mensajeError5_label = new javax.swing.JLabel();
        hecho_btn = new javax.swing.JLabel();
        mensajeError4_label = new javax.swing.JLabel();
        mensajeError2_label = new javax.swing.JLabel();
        mensajeError3_label = new javax.swing.JLabel();
        mensajeError1_label = new javax.swing.JLabel();
        focus_btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Banner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/BienvenidoALudik11.PNG"))); // NOI18N
        Fondo.add(Banner, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 640));

        bannerRegistrarse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Registrarse.PNG"))); // NOI18N
        Fondo.add(bannerRegistrarse, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 10, 300, 80));

        Nombre.setBackground(new java.awt.Color(0, 74, 173));
        Nombre.setFont(new java.awt.Font("Questrial", 0, 21)); // NOI18N
        Nombre.setForeground(new java.awt.Color(0, 74, 173));
        Nombre.setText("Nombre");
        Fondo.add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, -1, -1));

        IngreseNombre.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        IngreseNombre.setForeground(new java.awt.Color(143, 167, 198));
        IngreseNombre.setText("¿Cómo le gustaría ser llamado?");
        IngreseNombre.setBorder(null);
        IngreseNombre.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                IngreseNombreMousePressed(evt);
            }
        });
        IngreseNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngreseNombreActionPerformed(evt);
            }
        });
        Fondo.add(IngreseNombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 120, 380, 30));

        arroba.setBackground(new java.awt.Color(0, 74, 173));
        arroba.setFont(new java.awt.Font("Questrial", 0, 20)); // NOI18N
        arroba.setForeground(new java.awt.Color(153, 153, 153));
        arroba.setText("@");
        arroba.setToolTipText("");
        Fondo.add(arroba, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 210, 40, 30));

        FondoCampo1.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo1Layout = new javax.swing.GroupLayout(FondoCampo1);
        FondoCampo1.setLayout(FondoCampo1Layout);
        FondoCampo1Layout.setHorizontalGroup(
            FondoCampo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampo1Layout.setVerticalGroup(
            FondoCampo1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 150, 380, 5));

        Usuario.setBackground(new java.awt.Color(0, 74, 173));
        Usuario.setFont(new java.awt.Font("Questrial", 0, 21)); // NOI18N
        Usuario.setForeground(new java.awt.Color(0, 74, 173));
        Usuario.setText("Usuario");
        Fondo.add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 180, -1, -1));

        IngreseUsuario.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        IngreseUsuario.setForeground(new java.awt.Color(143, 167, 198));
        IngreseUsuario.setText("Cree su usuario con al menos 4 carácteres.");
        IngreseUsuario.setBorder(null);
        IngreseUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                IngreseUsuarioMousePressed(evt);
            }
        });
        IngreseUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngreseUsuarioActionPerformed(evt);
            }
        });
        Fondo.add(IngreseUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 210, 380, 30));

        FondoCampo2.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo2Layout = new javax.swing.GroupLayout(FondoCampo2);
        FondoCampo2.setLayout(FondoCampo2Layout);
        FondoCampo2Layout.setHorizontalGroup(
            FondoCampo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FondoCampo2Layout.setVerticalGroup(
            FondoCampo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 240, 380, 5));

        Email.setBackground(new java.awt.Color(0, 74, 173));
        Email.setFont(new java.awt.Font("Questrial", 0, 21)); // NOI18N
        Email.setForeground(new java.awt.Color(0, 74, 173));
        Email.setText("Email");
        Fondo.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 270, -1, -1));

        IngreseEmail.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        IngreseEmail.setForeground(new java.awt.Color(143, 167, 198));
        IngreseEmail.setText("Ingrese su dirección de correo electrónico.");
        IngreseEmail.setBorder(null);
        IngreseEmail.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                IngreseEmailMousePressed(evt);
            }
        });
        IngreseEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngreseEmailActionPerformed(evt);
            }
        });
        Fondo.add(IngreseEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 300, 380, 30));

        FondoCampo3.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo3Layout = new javax.swing.GroupLayout(FondoCampo3);
        FondoCampo3.setLayout(FondoCampo3Layout);
        FondoCampo3Layout.setHorizontalGroup(
            FondoCampo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampo3Layout.setVerticalGroup(
            FondoCampo3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo3, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 330, 380, 5));

        Contrasena.setBackground(new java.awt.Color(0, 74, 173));
        Contrasena.setFont(new java.awt.Font("Questrial", 0, 21)); // NOI18N
        Contrasena.setForeground(new java.awt.Color(0, 74, 173));
        Contrasena.setText("Contraseña");
        Fondo.add(Contrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 370, -1, -1));

        CreeContrasena.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        CreeContrasena.setForeground(new java.awt.Color(143, 167, 198));
        CreeContrasena.setText("Cree una contraseña con al menos 8 carácteres.");
        CreeContrasena.setBorder(null);
        CreeContrasena.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                CreeContrasenaMousePressed(evt);
            }
        });
        CreeContrasena.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreeContrasenaActionPerformed(evt);
            }
        });
        Fondo.add(CreeContrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 400, 370, 30));
        CreeContrasena.getDocument().addDocumentListener(new DocumentListener(){

            @Override
            public void changedUpdate(DocumentEvent e) {
                if(util.cantidadDeCaracteres(CreeContrasena, 8)){
                    FondoCampo4.setBackground(new java.awt.Color(204,0,51));
                    mensajeError = new javax.swing.JLabel();
                    mensajeError.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
                    mensajeError.setForeground(new java.awt.Color(204, 0, 51));
                    mensajeError.setText("mensajeError4_label");
                    Fondo.add(mensajeError, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 440, -1, -1));
                }
            }

            @Override
            public void insertUpdate(DocumentEvent e) {

            }

            @Override
            public void removeUpdate(DocumentEvent e) {

            }
        });

        FondoCampo4.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo4Layout = new javax.swing.GroupLayout(FondoCampo4);
        FondoCampo4.setLayout(FondoCampo4Layout);
        FondoCampo4Layout.setHorizontalGroup(
            FondoCampo4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampo4Layout.setVerticalGroup(
            FondoCampo4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo4, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 430, 380, 5));

        ContraConfirmada.setBackground(new java.awt.Color(0, 74, 173));
        ContraConfirmada.setFont(new java.awt.Font("Questrial", 0, 21)); // NOI18N
        ContraConfirmada.setForeground(new java.awt.Color(0, 74, 173));
        ContraConfirmada.setText("Confirmar contraseña");
        Fondo.add(ContraConfirmada, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 470, -1, -1));

        ConfirmarContra.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        ConfirmarContra.setForeground(new java.awt.Color(143, 167, 198));
        ConfirmarContra.setText("Confirme su contraseña.");
        ConfirmarContra.setBorder(null);
        ConfirmarContra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ConfirmarContraMousePressed(evt);
            }
        });
        ConfirmarContra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmarContraActionPerformed(evt);
            }
        });
        Fondo.add(ConfirmarContra, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 500, 360, 30));

        FondoCampo5.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo5Layout = new javax.swing.GroupLayout(FondoCampo5);
        FondoCampo5.setLayout(FondoCampo5Layout);
        FondoCampo5Layout.setHorizontalGroup(
            FondoCampo5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampo5Layout.setVerticalGroup(
            FondoCampo5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo5, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 530, 380, 5));

        cancelar_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/boton_cancelar.png"))); // NOI18N
        cancelar_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cancelar_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelar_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cancelar_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cancelar_btnMouseExited(evt);
            }
        });
        Fondo.add(cancelar_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 560, 200, 70));

        mensajeError5_label.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        mensajeError5_label.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(mensajeError5_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 540, -1, -1));

        hecho_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/botonHecho.png"))); // NOI18N
        hecho_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        hecho_btn.setEnabled(false);
        hecho_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hecho_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                hecho_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                hecho_btnMouseExited(evt);
            }
        });
        Fondo.add(hecho_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 550, 210, 80));

        mensajeError4_label.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        mensajeError4_label.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(mensajeError4_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 440, -1, -1));

        mensajeError2_label.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        mensajeError2_label.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(mensajeError2_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, -1, -1));

        mensajeError3_label.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        mensajeError3_label.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(mensajeError3_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 340, -1, -1));

        mensajeError1_label.setFont(new java.awt.Font("Questrial", 0, 16)); // NOI18N
        mensajeError1_label.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(mensajeError1_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 160, -1, 0));

        focus_btn.setText("jButton1");
        Fondo.add(focus_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 160, -1, -1));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IngreseNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngreseNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IngreseNombreActionPerformed

    private void IngreseNombreMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IngreseNombreMousePressed
        mensajeError1_label.setText("");
        arroba.setForeground(new Color(153,153,153));
        if (IngreseNombre.getText().equals("¿Cómo le gustaría ser llamado?")) {
           IngreseNombre.setText("");
           IngreseNombre.setForeground(new Color(47,58,129));
       }
      
      if (IngreseUsuario.getText().isEmpty()) {
          IngreseUsuario.setText("Cree su usuario con al menos 4 carácteres.");
          IngreseUsuario.setForeground(new Color(143,167,198));
          FondoCampo2.setBackground(new Color(213,225,240));  
      }
      
      if (IngreseEmail.getText().isEmpty()) {
          IngreseEmail.setText("Ingrese su dirección de correo electrónico.");
          mensajeError3_label.setText("");
          IngreseEmail.setForeground(new Color(143,167,198));
          FondoCampo3.setBackground(new Color(213,225,240));  
      }
      
      if (CreeContrasena.getText().isEmpty()) {
          CreeContrasena.setText("Cree una contraseña con al menos 8 carácteres.");
          CreeContrasena.setForeground(new Color(143,167,198));
          FondoCampo4.setBackground(new Color(213,225,240));  
      }
      
      if (ConfirmarContra.getText().isEmpty()) {
          ConfirmarContra.setText("Confirme su contraseña.");
          mensajeError5_label.setText("");
          ConfirmarContra.setForeground(new Color(143,167,198));
          FondoCampo5.setBackground(new Color(213,225,240));  
      }
      
      FondoCampo1.setBackground(new Color(0,74,173));
      if(IngreseNombre.getText().equals("¿Cómo le gustaría ser llamado?") || IngreseNombre.getText().equals("")){
            habilitar1 = false;
      }else{
            habilitar1 = true;
      }
    }//GEN-LAST:event_IngreseNombreMousePressed

    private void ConfirmarContraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ConfirmarContraMousePressed
        mensajeError5_label.setText("");
        arroba.setForeground(new Color(153,153,153));
        if (ConfirmarContra.getText().equals("Confirme su contraseña.")) {
           ConfirmarContra.setText("");
           ConfirmarContra.setForeground(new Color(47,58,129));
       }
        
      if (IngreseNombre.getText().isEmpty()) {
          IngreseNombre.setText("¿Cómo le gustaría ser llamado?");
          IngreseNombre.setForeground(new Color(143,167,198));
          FondoCampo1.setBackground(new Color(213,225,240));  
      }
      
      if (IngreseUsuario.getText().isEmpty()) {
          IngreseUsuario.setText("Cree su usuario con al menos 4 carácteres.");
          IngreseUsuario.setForeground(new Color(143,167,198));
          FondoCampo2.setBackground(new Color(213,225,240));
      }
      
      if (IngreseEmail.getText().isEmpty()) {
          IngreseEmail.setText("Ingrese su dirección de correo electrónico.");
          mensajeError3_label.setText("");
          IngreseEmail.setForeground(new Color(143,167,198));
          FondoCampo3.setBackground(new Color(213,225,240));  
      }
      
      if (CreeContrasena.getText().isEmpty()) {
          CreeContrasena.setText("Cree una contraseña con al menos 8 carácteres.");
          CreeContrasena.setForeground(new Color(143,167,198));
          FondoCampo4.setBackground(new Color(213,225,240));  
      }
      FondoCampo5.setBackground(new Color(0,74,173));
      
      habilitar5 = actualizarEstado(util.confirmarContrasena(ConfirmarContra, CreeContrasena), ConfirmarContra, FondoCampo5, mensajeError5_label, "Las contraseñas deben ser iguales");
    }//GEN-LAST:event_ConfirmarContraMousePressed

    private void ConfirmarContraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmarContraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ConfirmarContraActionPerformed

    private void IngreseUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IngreseUsuarioMousePressed
        mensajeError2_label.setText("");
        
        if (IngreseUsuario.getText().equals("Cree su usuario con al menos 4 carácteres.")) {
           IngreseUsuario.setText("");
           IngreseUsuario.setForeground(new Color(47,58,129));
           arroba.setForeground(new Color(47,58,129));
       }
        
      if (IngreseNombre.getText().isEmpty()) {
          IngreseNombre.setText("¿Cómo le gustaría ser llamado?");
          IngreseNombre.setForeground(new Color(143,167,198));
          FondoCampo1.setBackground(new Color(213,225,240));  
      }
      
      if (IngreseEmail.getText().isEmpty()) {
          IngreseEmail.setText("Ingrese su dirección de correo electrónico.");
          mensajeError3_label.setText("");
          IngreseEmail.setForeground(new Color(143,167,198));
          FondoCampo3.setBackground(new Color(213,225,240));  
      }
      
      if (CreeContrasena.getText().isEmpty()) {
          CreeContrasena.setText("Cree una contraseña con al menos 8 carácteres.");
          CreeContrasena.setForeground(new Color(143,167,198));
          FondoCampo4.setBackground(new Color(213,225,240));  
      }
      
      if (ConfirmarContra.getText().isEmpty()) {
          ConfirmarContra.setText("Confirme su contraseña.");
          mensajeError5_label.setText("");
          ConfirmarContra.setForeground(new Color(143,167,198));
          FondoCampo5.setBackground(new Color(213,225,240));  
      }
      
      FondoCampo2.setBackground(new Color(0,74,173));
      habilitar2 = actualizarEstado(util.cantidadDeCaracteres(IngreseUsuario, 4), IngreseUsuario, FondoCampo2, mensajeError2_label, "El nombre debe tener al menos 4 carácteres");
      if (habilitar2){
        habilitar6 = actualizarEstado(util.usuarioExistente(IngreseUsuario), IngreseUsuario, FondoCampo2, mensajeError2_label, "El usuario ya se encuentra registrado");
      }
    }//GEN-LAST:event_IngreseUsuarioMousePressed

    private void IngreseUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngreseUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IngreseUsuarioActionPerformed

    private void IngreseEmailMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IngreseEmailMousePressed
        mensajeError3_label.setText("");
        arroba.setForeground(new Color(153,153,153));
        if (IngreseEmail.getText().equals("Ingrese su dirección de correo electrónico.")) {
           IngreseEmail.setText("");
           IngreseEmail.setForeground(new Color(47,58,129));
       }
        
        
      if (IngreseNombre.getText().isEmpty()) {
          IngreseNombre.setText("¿Cómo le gustaría ser llamado?");
          IngreseNombre.setForeground(new Color(143,167,198));
          FondoCampo1.setBackground(new Color(213,225,240));  
      }
      
      if (IngreseUsuario.getText().isEmpty()) {
          IngreseUsuario.setText("Cree su usuario con al menos 4 carácteres.");
          IngreseUsuario.setForeground(new Color(143,167,198));
          FondoCampo2.setBackground(new Color(213,225,240));  
      }
      
      if (CreeContrasena.getText().isEmpty()) {
          CreeContrasena.setText("Cree una contraseña con al menos 8 carácteres.");
          CreeContrasena.setForeground(new Color(143,167,198));
          FondoCampo4.setBackground(new Color(213,225,240));  
      }
      
      if (ConfirmarContra.getText().isEmpty()) {
          ConfirmarContra.setText("Confirme su contraseña.");
          mensajeError5_label.setText("");
          ConfirmarContra.setForeground(new Color(143,167,198));
          FondoCampo5.setBackground(new Color(213,225,240));  
      }
      
      FondoCampo3.setBackground(new Color(0,74,173));
      habilitar3 = actualizarEstado(util.validarPatron(patronEmail, IngreseEmail.getText()), IngreseEmail, FondoCampo3, mensajeError3_label, "El correo no cumple con: ejemplo@dominio.com");
    }//GEN-LAST:event_IngreseEmailMousePressed

    private void IngreseEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngreseEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IngreseEmailActionPerformed

    private void CreeContrasenaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CreeContrasenaMousePressed
        mensajeError4_label.setText("");
        arroba.setForeground(new Color(153,153,153));
        if (CreeContrasena.getText().equals("Cree una contraseña con al menos 8 carácteres.")) {
           CreeContrasena.setText("");
           CreeContrasena.setForeground(new Color(47,58,129));
       }
       
       
       if (IngreseNombre.getText().isEmpty()) {
           
          IngreseNombre.setText("¿Cómo le gustaría ser llamado?");
          IngreseNombre.setForeground(new Color(143,167,198));
          FondoCampo1.setBackground(new Color(213,225,240));  
      }
      
      if (IngreseUsuario.getText().isEmpty()) {
          IngreseUsuario.setText("Cree su usuario con al menos 4 carácteres.");
          IngreseUsuario.setForeground(new Color(143,167,198));
          FondoCampo2.setBackground(new Color(213,225,240));  
      }
      
       if (IngreseEmail.getText().isEmpty()) {
          IngreseEmail.setText("Ingrese su dirección de correo electrónico.");
          mensajeError3_label.setText("");
          IngreseEmail.setForeground(new Color(143,167,198));
          FondoCampo3.setBackground(new Color(213,225,240));  
      }
      
      if (ConfirmarContra.getText().isEmpty()) {
          ConfirmarContra.setText("Confirme su contraseña.");
          ConfirmarContra.setForeground(new Color(143,167,198));
          mensajeError5_label.setText("");
          FondoCampo5.setBackground(new Color(213,225,240));  
      }

      FondoCampo4.setBackground(new Color(0,74,173));
      habilitar4 = actualizarEstado(util.cantidadDeCaracteres(CreeContrasena, 8), CreeContrasena, FondoCampo4, mensajeError4_label, "La contraseña debe tener al menos 8 carácteres");
    }//GEN-LAST:event_CreeContrasenaMousePressed

    private void CreeContrasenaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreeContrasenaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CreeContrasenaActionPerformed

    private void hecho_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hecho_btnMouseClicked
       if (hecho_btn.isEnabled()) {
           
            control.salvarUsuario(datosUsua, IngreseNombre, IngreseUsuario, IngreseEmail, CreeContrasena);
           
            /*
            Usuario user = new Usuario();
            control.datosUsuario(usuarios, user);**/

            VentanaLogin ventana = new VentanaLogin();
            control.activaVentana(ventana,this); 
       }
    }//GEN-LAST:event_hecho_btnMouseClicked

    private void hecho_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hecho_btnMouseEntered
        if(hecho_btn.isEnabled()){
            hecho_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/boton_hecho_claro.png"));
        }
    }//GEN-LAST:event_hecho_btnMouseEntered

    private void hecho_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hecho_btnMouseExited
        hecho_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/botonHecho.png"));
    }//GEN-LAST:event_hecho_btnMouseExited

    private void cancelar_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelar_btnMouseEntered
        cancelar_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/boton_cancelar_claro.png"));
    }//GEN-LAST:event_cancelar_btnMouseEntered

    private void cancelar_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelar_btnMouseExited
        cancelar_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/boton_cancelar.png"));
    }//GEN-LAST:event_cancelar_btnMouseExited

    private void cancelar_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelar_btnMouseClicked
        VentanaLogin ventana = new VentanaLogin();
        control.activaVentana(ventana,this); 
    }//GEN-LAST:event_cancelar_btnMouseClicked
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaRegistro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaRegistro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Banner;
    private javax.swing.JTextField ConfirmarContra;
    private javax.swing.JLabel ContraConfirmada;
    private javax.swing.JLabel Contrasena;
    private javax.swing.JTextField CreeContrasena;
    private javax.swing.JLabel Email;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoCampo1;
    private javax.swing.JPanel FondoCampo2;
    private javax.swing.JPanel FondoCampo3;
    private javax.swing.JPanel FondoCampo4;
    private javax.swing.JPanel FondoCampo5;
    private javax.swing.JTextField IngreseEmail;
    private javax.swing.JTextField IngreseNombre;
    private javax.swing.JTextField IngreseUsuario;
    private javax.swing.JLabel Nombre;
    private javax.swing.JLabel Usuario;
    private javax.swing.JLabel arroba;
    private javax.swing.JLabel bannerRegistrarse;
    private javax.swing.JLabel cancelar_btn;
    private javax.swing.JButton focus_btn;
    private javax.swing.JLabel hecho_btn;
    private javax.swing.JLabel mensajeError1_label;
    private javax.swing.JLabel mensajeError2_label;
    private javax.swing.JLabel mensajeError3_label;
    private javax.swing.JLabel mensajeError4_label;
    private javax.swing.JLabel mensajeError5_label;
    // End of variables declaration//GEN-END:variables
}
