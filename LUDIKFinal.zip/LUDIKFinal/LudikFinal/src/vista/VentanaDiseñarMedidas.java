/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import AppPackage.AnimationClass;
import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Diseño;
import modelo.Usuario;

public class VentanaDiseñarMedidas extends javax.swing.JFrame {

   ArrayList<String> camposDiseño;
   boolean errorMedida=false;
   Usuario usuarioActual;
   
    
   Controladora control;
    
    public VentanaDiseñarMedidas() {
        initComponents();
        control= new Controladora(this,medidaUsuario);
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
        this.camposDiseño = new ArrayList<>();
        this.usuarioActual=new Usuario();
        
    }
    
    public VentanaDiseñarMedidas(Usuario user,ArrayList<String> campos) {
        initComponents();
        control= new Controladora(this,medidaUsuario);
        this.usuarioActual=user;
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
        this.camposDiseño = campos;
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        progressbar1 = new javax.swing.JPanel();
        progressbar = new javax.swing.JPanel();
        errorMedidaInv = new javax.swing.JLabel();
        Banner = new javax.swing.JLabel();
        Plano1 = new javax.swing.JLabel();
        Plano2 = new javax.swing.JLabel();
        Seleccion1 = new javax.swing.JLabel();
        Atras = new javax.swing.JLabel();
        Continuar1 = new javax.swing.JLabel();
        Seleccion2 = new javax.swing.JLabel();
        Banner1 = new javax.swing.JLabel();
        metroCuadrado = new javax.swing.JTextField();
        medidaUsuario = new javax.swing.JTextField();
        FondoCampo = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        progressbar1.setBackground(new java.awt.Color(150, 242, 242));
        Fondo.add(progressbar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 170, 20));

        progressbar.setBackground(new java.awt.Color(218, 238, 241));

        javax.swing.GroupLayout progressbarLayout = new javax.swing.GroupLayout(progressbar);
        progressbar.setLayout(progressbarLayout);
        progressbarLayout.setHorizontalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        progressbarLayout.setVerticalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        Fondo.add(progressbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 340, 20));

        errorMedidaInv.setBackground(new java.awt.Color(0, 74, 173));
        errorMedidaInv.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        errorMedidaInv.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(errorMedidaInv, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 420, 380, 30));

        Banner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Regla2.PNG"))); // NOI18N
        Fondo.add(Banner, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 430, 470, 110));

        Plano1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Diseñar.PNG"))); // NOI18N
        Fondo.add(Plano1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1070, 140));

        Plano2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano1.PNG"))); // NOI18N
        Fondo.add(Plano2, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 190, 200, 360));

        Seleccion1.setBackground(new java.awt.Color(0, 74, 173));
        Seleccion1.setFont(new java.awt.Font("Questrial", 1, 30)); // NOI18N
        Seleccion1.setForeground(new java.awt.Color(153, 204, 255));
        Seleccion1.setText("(10m2 - 30m2)");
        Fondo.add(Seleccion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 250, 240, -1));

        Atras.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/boton_continuar_invertido.png"))); // NOI18N
        Atras.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                AtrasMouseClicked(evt);
            }
        });
        Fondo.add(Atras, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 90, 80));

        Continuar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/continuar1.PNG"))); // NOI18N
        Continuar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Continuar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Continuar1MouseClicked(evt);
            }
        });
        Fondo.add(Continuar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 540, 100, 80));

        Seleccion2.setBackground(new java.awt.Color(0, 74, 173));
        Seleccion2.setFont(new java.awt.Font("Questrial", 0, 36)); // NOI18N
        Seleccion2.setForeground(new java.awt.Color(0, 74, 173));
        Seleccion2.setText("Inserte las medidas de su kiosco lúdico...");
        Fondo.add(Seleccion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 660, -1));

        Banner1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano2.PNG"))); // NOI18N
        Fondo.add(Banner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 270, 360));

        metroCuadrado.setFont(new java.awt.Font("Garet Heavy", 0, 26)); // NOI18N
        metroCuadrado.setForeground(new java.awt.Color(153, 153, 255));
        metroCuadrado.setText("m2");
        metroCuadrado.setBorder(null);
        metroCuadrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                metroCuadradoActionPerformed(evt);
            }
        });
        Fondo.add(metroCuadrado, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 380, 50, 30));

        medidaUsuario.setFont(new java.awt.Font("Garet Heavy", 0, 70)); // NOI18N
        medidaUsuario.setForeground(new java.awt.Color(204, 204, 204));
        medidaUsuario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        medidaUsuario.setText("9");
        medidaUsuario.setBorder(null);
        medidaUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                medidaUsuarioMousePressed(evt);
            }
        });
        medidaUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                medidaUsuarioActionPerformed(evt);
            }
        });
        medidaUsuario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                medidaUsuarioKeyTyped(evt);
            }
        });
        Fondo.add(medidaUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 340, 360, 70));

        FondoCampo.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampoLayout = new javax.swing.GroupLayout(FondoCampo);
        FondoCampo.setLayout(FondoCampoLayout);
        FondoCampoLayout.setHorizontalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        FondoCampoLayout.setVerticalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 410, 380, 5));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void medidaUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_medidaUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_medidaUsuarioActionPerformed

    private void metroCuadradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_metroCuadradoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_metroCuadradoActionPerformed

    private void medidaUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_medidaUsuarioMousePressed
        medidaUsuario.setText("");
        medidaUsuario.setForeground(new Color(0,74,173));
        errorMedidaInv.setText("");
        FondoCampo.setBackground(new Color(0,74,173));
        Seleccion2.setForeground(new Color (0,74,173));
        

    }//GEN-LAST:event_medidaUsuarioMousePressed

    private void Continuar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Continuar1MouseClicked
        String medidastr = medidaUsuario.getText();
        int medidaint = Integer.parseInt(medidastr);
        
        if (medidaUsuario.getText().equals("9")) {
            Seleccion2.setForeground(new Color (204,0,51));
            FondoCampo.setBackground(new Color(204,0,51));
        }
        else if (control.validarMedida(medidaint)==false) {
            errorMedida=true;
            FondoCampo.setBackground(new Color(204,0,51));
            errorMedidaInv.setText("La medida mínima es 10m2 y la máxima 30m2");
            errorMedidaInv.setForeground(new Color(204,0,51));
            medidaUsuario.requestFocus();
        }
        
        else {
            if (camposDiseño.size()<2) {
                camposDiseño.add(medidaUsuario.getText());
            }
            else {
                camposDiseño.set(1,medidaUsuario.getText());
            }
            
            camposDiseño.add(medidaUsuario.getText());
            VentanaDiseñarEstilo ventana = new VentanaDiseñarEstilo(usuarioActual,camposDiseño);
            ventana.camposDiseño = camposDiseño;
            ventana.usuarioActual=usuarioActual;
            control.activaVentana(ventana, this);
        }
    }//GEN-LAST:event_Continuar1MouseClicked

    private void AtrasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_AtrasMouseClicked
        
        VentanaDiseñarTipo ventana = new VentanaDiseñarTipo(usuarioActual,camposDiseño);
        ventana.camposDiseño = camposDiseño;
        ventana.usuarioActual=usuarioActual;
        control.activaVentana(ventana, this);

    }//GEN-LAST:event_AtrasMouseClicked

    private void medidaUsuarioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_medidaUsuarioKeyTyped
        char c = evt.getKeyChar();
        
        if ((c<'0')||(c>'9'))evt.consume();
    }//GEN-LAST:event_medidaUsuarioKeyTyped

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarMedidas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaDiseñarMedidas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Atras;
    private javax.swing.JLabel Banner;
    private javax.swing.JLabel Banner1;
    private javax.swing.JLabel Continuar1;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoCampo;
    private javax.swing.JLabel Plano1;
    private javax.swing.JLabel Plano2;
    private javax.swing.JLabel Seleccion1;
    private javax.swing.JLabel Seleccion2;
    private javax.swing.JLabel errorMedidaInv;
    private javax.swing.JTextField medidaUsuario;
    private javax.swing.JTextField metroCuadrado;
    private javax.swing.JPanel progressbar;
    private javax.swing.JPanel progressbar1;
    // End of variables declaration//GEN-END:variables
}
