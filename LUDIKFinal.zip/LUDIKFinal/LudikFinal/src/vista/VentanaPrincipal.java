/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import modelo.Diseño;
import controller.Controladora;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import java.awt.Font;
import AppPackage.AnimationClass;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JLabel;
import modelo.Usuario;
import persistencia.DiseñosXML;
import vista.VentanaMisDiseños;


/**
 *
 * @author Cristian De Sousa
 */
public class VentanaPrincipal extends javax.swing.JFrame {
    Controladora control;
    Object[] opciones = {"Sí", "No"};
    
    boolean Pasouno=false;
    Usuario usuarioActual;
    
    String nombre;
    DiseñosXML datosDise = new DiseñosXML();
    ArrayList<Diseño> listaDiseños = datosDise.todosLosDiseños();
    
    
    
    
    
    public VentanaPrincipal() {
        initComponents();
        control = new Controladora(this);
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        this.listaDiseños= new ArrayList<>();
        this.nombre="";
        
        
        
        String nametag=("Hola, "+nombre);
        
        
       
    }
    
    public VentanaPrincipal(Usuario usuarioActual) {
        initComponents();
        
        control = new Controladora(this,nombre,botonNametag,diseñar_label_btn,comprar_label_btn,misDiseños_label_btn,salir_label_btn);
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        this.listaDiseños= new ArrayList<>();
        listaDiseños=datosDise.todosLosDiseños();
        this.usuarioActual = usuarioActual;
        this.nombre=usuarioActual.getNombre();
        
        String nametag=("Hola, "+nombre);
        botonNametag.setText(nametag);
        
        
        
        AnimationClass bienvenida = new AnimationClass();
        bienvenida.jLabelXRight(420,440,15,1,botonNametag);
        botonNametag.setLocation(440,220);
    }
    
    
    public VentanaPrincipal(Usuario usuario, ArrayList <Diseño> diseños) {
        control = new Controladora(this,nombre,botonNametag,diseñar_label_btn,comprar_label_btn,misDiseños_label_btn,salir_label_btn);
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        this.usuarioActual=usuario;
        this.nombre=usuarioActual.getNombre();
        this.botonNametag.setText(nombre);
        this.botonNametag.setForeground(new Color(0,74,173));
        this.listaDiseños = diseños;
        botonNametag.setLocation(450,250);
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        listo = new javax.swing.JLabel();
        siguientea = new javax.swing.JLabel();
        siguienteb = new javax.swing.JLabel();
        siguientec = new javax.swing.JLabel();
        iconoideas = new javax.swing.JLabel();
        lineaInferior_label = new javax.swing.JLabel();
        botonDashBoard = new javax.swing.JLabel();
        iconoporhacer = new javax.swing.JLabel();
        iconoperfil1 = new javax.swing.JLabel();
        barraOpciones = new javax.swing.JLabel();
        botonNametag = new javax.swing.JLabel();
        tutorial = new javax.swing.JLabel();
        diseñar_label_btn = new javax.swing.JLabel();
        Flecha4 = new javax.swing.JLabel();
        Paso4 = new javax.swing.JLabel();
        Paso1 = new javax.swing.JLabel();
        fondo_label3 = new javax.swing.JLabel();
        comprar_label_btn = new javax.swing.JLabel();
        Paso2 = new javax.swing.JLabel();
        misDiseños_label_btn = new javax.swing.JLabel();
        Flecha3 = new javax.swing.JLabel();
        Paso3 = new javax.swing.JLabel();
        quienesSomos_label = new javax.swing.JLabel();
        contecto_label = new javax.swing.JLabel();
        encabezado_label = new javax.swing.JLabel();
        salir_label_btn = new javax.swing.JLabel();
        iconoperfil = new javax.swing.JLabel();
        fondo_label1 = new javax.swing.JLabel();
        Flecha2 = new javax.swing.JLabel();
        Flecha1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setMaximumSize(new java.awt.Dimension(1060, 640));
        Fondo.setPreferredSize(new java.awt.Dimension(1060, 640));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        listo.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        listo.setForeground(new java.awt.Color(0, 74, 173));
        listo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        listo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                listoMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                listoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                listoMouseExited(evt);
            }
        });
        Fondo.add(listo, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, 70, 70));

        siguientea.setFont(new java.awt.Font("Arial Black", 0, 40)); // NOI18N
        siguientea.setForeground(new java.awt.Color(0, 74, 173));
        siguientea.setToolTipText("");
        siguientea.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        siguientea.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                siguienteaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                siguienteaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                siguienteaMouseExited(evt);
            }
        });
        Fondo.add(siguientea, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, 70, 80));

        siguienteb.setFont(new java.awt.Font("Arial Black", 0, 40)); // NOI18N
        siguienteb.setForeground(new java.awt.Color(0, 74, 173));
        siguienteb.setToolTipText("");
        siguienteb.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        siguienteb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                siguientebMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                siguientebMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                siguientebMouseExited(evt);
            }
        });
        Fondo.add(siguienteb, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 560, 70, 70));

        siguientec.setFont(new java.awt.Font("Arial Black", 0, 40)); // NOI18N
        siguientec.setForeground(new java.awt.Color(0, 74, 173));
        siguientec.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        siguientec.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                siguientecMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                siguientecMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                siguientecMouseExited(evt);
            }
        });
        Fondo.add(siguientec, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 270, 80, 70));

        iconoideas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        iconoideas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconoideasMouseClicked(evt);
            }
        });
        Fondo.add(iconoideas, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 480, 120, 140));

        lineaInferior_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/lineaInferior.png"))); // NOI18N
        Fondo.add(lineaInferior_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 650, -1, 20));

        botonDashBoard.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/botonDashboard.PNG"))); // NOI18N
        botonDashBoard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        botonDashBoard.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                botonDashBoardMouseClicked(evt);
            }
        });
        Fondo.add(botonDashBoard, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, -1, 60));

        iconoporhacer.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        iconoporhacer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconoporhacerMouseClicked(evt);
            }
        });
        Fondo.add(iconoporhacer, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 130, 140));

        iconoperfil1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        iconoperfil1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconoperfil1MouseClicked(evt);
            }
        });
        Fondo.add(iconoperfil1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, 130, 140));

        barraOpciones.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/nDashboard1.PNG"))); // NOI18N
        Fondo.add(barraOpciones, new org.netbeans.lib.awtextra.AbsoluteConstraints(-90, 20, 140, 630));

        botonNametag.setFont(new java.awt.Font("Questrial", 0, 35)); // NOI18N
        botonNametag.setForeground(new java.awt.Color(0, 74, 173));
        botonNametag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botonNametagMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                botonNametagMouseExited(evt);
            }
        });
        botonNametag.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                botonNametagKeyPressed(evt);
            }
        });
        Fondo.add(botonNametag, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 220, 490, 110));

        tutorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/boton_tutorial.png"))); // NOI18N
        tutorial.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tutorial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tutorialMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                tutorialMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                tutorialMouseExited(evt);
            }
        });
        Fondo.add(tutorial, new org.netbeans.lib.awtextra.AbsoluteConstraints(1020, 540, 110, 110));

        diseñar_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/boton_diseñar.png"))); // NOI18N
        diseñar_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        diseñar_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                diseñar_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                diseñar_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                diseñar_label_btnMouseExited(evt);
            }
        });
        Fondo.add(diseñar_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 340, 230, 69));

        Flecha4.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Flecha4.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Flecha4, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 128, 100, 120));

        Paso4.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Paso4.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Paso4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 220, 440, 100));

        Paso1.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Paso1.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Paso1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, 270, 100));

        fondo_label3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/planos.PNG"))); // NOI18N
        Fondo.add(fondo_label3, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 210, -1, 380));

        comprar_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/boton_comprar.png"))); // NOI18N
        comprar_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        comprar_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comprar_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                comprar_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                comprar_label_btnMouseExited(evt);
            }
        });
        Fondo.add(comprar_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 460, 240, 71));

        Paso2.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Paso2.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Paso2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 530, 270, 100));

        misDiseños_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/boton_misDiseños.png"))); // NOI18N
        misDiseños_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        misDiseños_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                misDiseños_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                misDiseños_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                misDiseños_label_btnMouseExited(evt);
            }
        });
        Fondo.add(misDiseños_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 340, 240, 70));

        Flecha3.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Flecha3.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Flecha3, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 290, 100, 120));

        Paso3.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Paso3.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Paso3, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 250, 270, 90));

        quienesSomos_label.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        quienesSomos_label.setForeground(new java.awt.Color(232, 246, 250));
        quienesSomos_label.setText("¿Quiénes somos?");
        quienesSomos_label.setToolTipText("");
        quienesSomos_label.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        quienesSomos_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                quienesSomos_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                quienesSomos_labelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                quienesSomos_labelMouseExited(evt);
            }
        });
        Fondo.add(quienesSomos_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 150, 200, -1));

        contecto_label.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        contecto_label.setForeground(new java.awt.Color(232, 246, 250));
        contecto_label.setText("Contacto");
        contecto_label.setToolTipText("");
        contecto_label.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        contecto_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contecto_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                contecto_labelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                contecto_labelMouseExited(evt);
            }
        });
        Fondo.add(contecto_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 150, 110, 30));

        encabezado_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/LudikBannner.PNG"))); // NOI18N
        Fondo.add(encabezado_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, 1070, -1));

        salir_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/boton_cerrarSesion.png"))); // NOI18N
        salir_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        salir_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                salir_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                salir_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                salir_label_btnMouseExited(evt);
            }
        });
        Fondo.add(salir_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 460, 230, -1));

        iconoperfil.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/perfil2.PNG"))); // NOI18N
        iconoperfil.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        iconoperfil.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                iconoperfilMouseClicked(evt);
            }
        });
        Fondo.add(iconoperfil, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 230, -1, 80));

        fondo_label1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaPrincipal/planos.PNG"))); // NOI18N
        Fondo.add(fondo_label1, new org.netbeans.lib.awtextra.AbsoluteConstraints(940, 250, 210, 360));

        Flecha2.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Flecha2.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Flecha2, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 510, 70, 90));

        Flecha1.setFont(new java.awt.Font("Questrial", 0, 40)); // NOI18N
        Flecha1.setForeground(new java.awt.Color(0, 74, 173));
        Fondo.add(Flecha1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 260, 100, 120));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(-90, -20, 1150, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void diseñar_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diseñar_label_btnMouseClicked
        VentanaDiseñarTipo ventana1 = new VentanaDiseñarTipo(usuarioActual);
        ventana1.usuarioActual= usuarioActual;
        control.activaVentana(ventana1, this);
    }//GEN-LAST:event_diseñar_label_btnMouseClicked

    private void comprar_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprar_label_btnMouseClicked
        
        int size = control.diseñosUsuarioSize(usuarioActual.getUser(), listaDiseños);
        if(size<1){
            UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 24));
            UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 24));
            JOptionPane.showMessageDialog(null, "No ha creado ningún diseño. Cree uno y compre los materiales.", "Diseños no disponibles", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/ventanaPrincipal/cajaVacia_icono.png"));
        } 
        
        else{
            VentanaComprar1 ventana = new VentanaComprar1(usuarioActual);
            ventana.usuarioActual = usuarioActual;
            control.activaVentana(ventana, this);
        }
        
        
    }//GEN-LAST:event_comprar_label_btnMouseClicked

    private void misDiseños_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_misDiseños_label_btnMouseClicked
        int size = control.misDiseñosSize(usuarioActual.getUser(),listaDiseños);
        
        if (size<1){

            UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 24));
            UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 24));
            JOptionPane.showMessageDialog(null, "No se encontraron diseños terminados.", "Diseños no disponibles", JOptionPane.INFORMATION_MESSAGE, new ImageIcon("src/images/ventanaPrincipal/cajaVacia_icono.png"));
        } else{
            VentanaMisDiseños ventana = new VentanaMisDiseños(usuarioActual);
            ventana.usuarioActual = usuarioActual;
            control.activaVentana(ventana, this);
        }
        
    }//GEN-LAST:event_misDiseños_label_btnMouseClicked

    private void salir_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salir_label_btnMouseClicked
        UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 24));
        UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 24));
        int confirmacion = JOptionPane.showOptionDialog(
            null, "¿Cerrar sesión?", "Confirmación",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, new ImageIcon("src/images/ventanaPrincipal/aviso_icono.png"), opciones, opciones[0]);
        if (confirmacion == 0){
            VentanaLogin ventana = new VentanaLogin();
            control.activaVentana(ventana,this);
        }
    }//GEN-LAST:event_salir_label_btnMouseClicked

    private void quienesSomos_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quienesSomos_labelMouseClicked
        VentanaQuienesSomos ventana = new VentanaQuienesSomos(usuarioActual);
        ventana.usuarioActual = usuarioActual;
        control.activaVentana(ventana,this);
        
    }//GEN-LAST:event_quienesSomos_labelMouseClicked

    private void contecto_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contecto_labelMouseClicked
        VentanaContactanos ventana = new VentanaContactanos(usuarioActual);
        ventana.usuarioActual = usuarioActual;
        control.activaVentana(ventana,this);
    }//GEN-LAST:event_contecto_labelMouseClicked

    
    //eventos al pasar el cursor sobre label
    private void diseñar_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diseñar_label_btnMouseEntered
        diseñar_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_diseñar_claro.png"));
    }//GEN-LAST:event_diseñar_label_btnMouseEntered

    private void diseñar_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_diseñar_label_btnMouseExited
        diseñar_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_diseñar.png"));
    }//GEN-LAST:event_diseñar_label_btnMouseExited

    private void salir_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salir_label_btnMouseEntered
        salir_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_cerrarSesion_claro.png"));
    }//GEN-LAST:event_salir_label_btnMouseEntered

    private void salir_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_salir_label_btnMouseExited
        salir_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_cerrarSesion.png"));
    }//GEN-LAST:event_salir_label_btnMouseExited

    private void misDiseños_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_misDiseños_label_btnMouseEntered
        if(misDiseños_label_btn.isEnabled()){
            misDiseños_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_misDiseños_claro.png"));
        }
    }//GEN-LAST:event_misDiseños_label_btnMouseEntered

    private void misDiseños_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_misDiseños_label_btnMouseExited
        if(true){
            misDiseños_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_misDiseños.png"));
        }
    }//GEN-LAST:event_misDiseños_label_btnMouseExited

    private void comprar_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprar_label_btnMouseEntered
        if(comprar_label_btn.isEnabled()){
            comprar_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_comprar_claro.png"));
        }
    }//GEN-LAST:event_comprar_label_btnMouseEntered

    private void comprar_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comprar_label_btnMouseExited
        if(true){
            comprar_label_btn.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_comprar.png"));
        }
    }//GEN-LAST:event_comprar_label_btnMouseExited

    private void botonDashBoardMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonDashBoardMouseClicked
        AnimationClass barraDashboardR = new AnimationClass();
        barraDashboardR.jLabelXRight(-90, 90, 10, 5, barraOpciones);
        iconoperfil1.setIcon(new ImageIcon("src/images/ventanaPrincipal/perfil3.png"));

        AnimationClass barraDashboardL = new AnimationClass();
        barraDashboardL.jLabelXLeft(90, -90, 10, 5, barraOpciones);
        iconoperfil1.setIcon(null);
        
        

    }//GEN-LAST:event_botonDashBoardMouseClicked

    private void botonNametagKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_botonNametagKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonNametagKeyPressed

    private void botonNametagMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNametagMouseExited
        
        botonNametag.setForeground(new Color (0,74,173));
        
    }//GEN-LAST:event_botonNametagMouseExited

    private void botonNametagMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_botonNametagMouseEntered
        
        botonNametag.setForeground(new Color (0,204,204));
        
    }//GEN-LAST:event_botonNametagMouseEntered

    private void tutorialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tutorialMouseClicked

       botonNametag.setText("");
       iconoperfil.setIcon(null);
       botonNametag.setEnabled(false);
       iconoperfil.setEnabled(false);
       
       
       siguientea.setIcon(new ImageIcon("src/images/ventanaPrincipal/tutosiguiente.png"));
       Paso1.setIcon(new ImageIcon("src/images/ventanaPrincipal/Paso1.png"));
       Flecha1.setIcon(new ImageIcon("src/images/ventanaPrincipal/Flecha1.png"));
       
       AnimationClass Despliegue = new AnimationClass();
       Despliegue.jLabelXRight(320, 350, 10, 5, Paso1);
       
      
    }//GEN-LAST:event_tutorialMouseClicked

    private void siguienteaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguienteaMouseClicked
        Paso1.setIcon(null);
        Flecha1.setIcon(null);
        siguientea.setIcon(null);
        
        siguienteb.setIcon(new ImageIcon("src/images/ventanaPrincipal/tutosiguiente.png"));
        Paso2.setIcon(new ImageIcon("src/images/ventanaPrincipal/PASO2.png"));
        Flecha2.setIcon(new ImageIcon("src/images/ventanaPrincipal/Flecha2.png"));
        
        AnimationClass Despliegue = new AnimationClass();
        Despliegue.jLabelXRight(600, 630, 10, 5, Paso2);
        
    }//GEN-LAST:event_siguienteaMouseClicked

    private void siguienteaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguienteaMouseEntered
        
    }//GEN-LAST:event_siguienteaMouseEntered

    private void siguienteaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguienteaMouseExited
        
    }//GEN-LAST:event_siguienteaMouseExited

    private void siguientebMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientebMouseClicked
        Paso2.setIcon(null);
        Flecha2.setIcon(null);
        siguienteb.setIcon(null);
        
        siguientec.setIcon(new ImageIcon("src/images/ventanaPrincipal/tutosiguiente.png"));
        Paso3.setIcon(new ImageIcon("src/images/ventanaPrincipal/Paso3.png"));
        Flecha3.setIcon(new ImageIcon("src/images/ventanaPrincipal/Flecha3.png"));
        
        AnimationClass Despliegue = new AnimationClass();
        Despliegue.jLabelXRight(630, 650, 10, 5, Paso3);
       
    }//GEN-LAST:event_siguientebMouseClicked

    private void siguientebMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientebMouseEntered
        
    }//GEN-LAST:event_siguientebMouseEntered

    private void siguientebMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientebMouseExited
         
    }//GEN-LAST:event_siguientebMouseExited

    private void siguientecMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientecMouseClicked
        Paso3.setIcon(null);
        Flecha3.setIcon(null);
        siguientec.setIcon(null);
        
        Paso4.setIcon(new ImageIcon("src/images/ventanaPrincipal/Paso4.png"));
        Flecha4.setIcon(new ImageIcon("src/images/ventanaPrincipal/Flecha4.png"));
        listo.setIcon(new ImageIcon("src/images/ventanaPrincipal/tutolisto.png"));
        AnimationClass Despliegue = new AnimationClass();
        Despliegue.jLabelXRight(140, 160, 10, 5, Paso4);
    }//GEN-LAST:event_siguientecMouseClicked

    private void siguientecMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientecMouseEntered
        
    }//GEN-LAST:event_siguientecMouseEntered

    private void siguientecMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguientecMouseExited
        
    }//GEN-LAST:event_siguientecMouseExited

    private void listoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listoMouseClicked
        Paso4.setIcon(null);
        Flecha4.setIcon(null);
        listo.setIcon(null);
        siguientea.setEnabled(false);
        botonNametag.setEnabled(true);
        iconoperfil.setEnabled(true);
        iconoperfil.setIcon(new ImageIcon("src/images/ventanaPrincipal/perfil2.png"));
        String nametag=("Hola, "+nombre);
        botonNametag.setText(nametag);
    }//GEN-LAST:event_listoMouseClicked

    private void listoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listoMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_listoMouseEntered

    private void listoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_listoMouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_listoMouseExited

    private void tutorialMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tutorialMouseEntered
        tutorial.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_tutorial_claro.png"));
       
       
    }//GEN-LAST:event_tutorialMouseEntered

    private void tutorialMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tutorialMouseExited
        
        tutorial.setIcon(new ImageIcon("src/images/ventanaPrincipal/boton_tutorial.png"));
       
    }//GEN-LAST:event_tutorialMouseExited

    private void iconoperfil1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconoperfil1MouseClicked
        VentanaPerfil ventana = new VentanaPerfil(usuarioActual);
        control.activaVentana(ventana,this);
    }//GEN-LAST:event_iconoperfil1MouseClicked

    private void iconoperfilMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconoperfilMouseClicked

    }//GEN-LAST:event_iconoperfilMouseClicked

    private void iconoporhacerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconoporhacerMouseClicked
        VentanaPorHacer ventana = new VentanaPorHacer(usuarioActual);
        ventana.usuarioActual=usuarioActual;
        control.activaVentana(ventana,this);
    }//GEN-LAST:event_iconoporhacerMouseClicked

    private void iconoideasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_iconoideasMouseClicked
        VentanaInspirate ventana = new VentanaInspirate(usuarioActual);
        ventana.usuarioActual = usuarioActual;
        control.activaVentana(ventana,this);
    }//GEN-LAST:event_iconoideasMouseClicked

    private void quienesSomos_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quienesSomos_labelMouseEntered
        quienesSomos_label.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_quienesSomos_labelMouseEntered

    private void quienesSomos_labelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_quienesSomos_labelMouseExited
       quienesSomos_label.setForeground(new Color(232,246,250));
    }//GEN-LAST:event_quienesSomos_labelMouseExited

    private void contecto_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contecto_labelMouseEntered
        quienesSomos_label.setForeground(new Color(255,255,255));
    }//GEN-LAST:event_contecto_labelMouseEntered

    private void contecto_labelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contecto_labelMouseExited
        quienesSomos_label.setForeground(new Color(232,246,250));
    }//GEN-LAST:event_contecto_labelMouseExited

        
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Flecha1;
    private javax.swing.JLabel Flecha2;
    private javax.swing.JLabel Flecha3;
    private javax.swing.JLabel Flecha4;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Paso1;
    private javax.swing.JLabel Paso2;
    private javax.swing.JLabel Paso3;
    private javax.swing.JLabel Paso4;
    private javax.swing.JLabel barraOpciones;
    private javax.swing.JLabel botonDashBoard;
    private javax.swing.JLabel botonNametag;
    private javax.swing.JLabel comprar_label_btn;
    private javax.swing.JLabel contecto_label;
    private javax.swing.JLabel diseñar_label_btn;
    private javax.swing.JLabel encabezado_label;
    private javax.swing.JLabel fondo_label1;
    private javax.swing.JLabel fondo_label3;
    private javax.swing.JLabel iconoideas;
    private javax.swing.JLabel iconoperfil;
    private javax.swing.JLabel iconoperfil1;
    private javax.swing.JLabel iconoporhacer;
    private javax.swing.JLabel lineaInferior_label;
    private javax.swing.JLabel listo;
    private javax.swing.JLabel misDiseños_label_btn;
    private javax.swing.JLabel quienesSomos_label;
    private javax.swing.JLabel salir_label_btn;
    private javax.swing.JLabel siguientea;
    private javax.swing.JLabel siguienteb;
    private javax.swing.JLabel siguientec;
    private javax.swing.JLabel tutorial;
    // End of variables declaration//GEN-END:variables
}
