/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import AppPackage.AnimationClass;
import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import modelo.Usuario;

public class VentanaDiseñarEstilo extends javax.swing.JFrame {

    ArrayList <String> camposDiseño;
    Usuario usuarioActual;
    boolean folkClickeado=false;
    boolean modClickeado=false;
    boolean minClickeado=false;
    boolean popClickeado=false;
    
    
    Controladora control;
    
    public VentanaDiseñarEstilo() {
        initComponents();
        
        control= new Controladora(this);
        this.usuarioActual=new Usuario();
        this.camposDiseño=new ArrayList<>();
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
        
    }
    
    public VentanaDiseñarEstilo(Usuario usuario,ArrayList <String> campos) {
        initComponents();
        
        control= new Controladora(this);
        this.usuarioActual=usuario;
        this.camposDiseño=campos;
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.png");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        progressbar1 = new javax.swing.JPanel();
        progressbar = new javax.swing.JPanel();
        Seleccion1 = new javax.swing.JLabel();
        Salir1 = new javax.swing.JLabel();
        Continuar1 = new javax.swing.JLabel();
        Banner1 = new javax.swing.JLabel();
        panelMinimalista = new javax.swing.JPanel();
        iconoExterior6 = new javax.swing.JLabel();
        Exterior7 = new javax.swing.JLabel();
        panelPopart = new javax.swing.JPanel();
        iconoExterior5 = new javax.swing.JLabel();
        Exterior6 = new javax.swing.JLabel();
        panelModerno = new javax.swing.JPanel();
        iconoExterior4 = new javax.swing.JLabel();
        Exterior5 = new javax.swing.JLabel();
        panelFolk = new javax.swing.JPanel();
        iconoExterior3 = new javax.swing.JLabel();
        Exterior4 = new javax.swing.JLabel();
        Plano1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Plano2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        progressbar1.setBackground(new java.awt.Color(150, 242, 242));
        Fondo.add(progressbar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 240, 20));

        progressbar.setBackground(new java.awt.Color(218, 238, 241));

        javax.swing.GroupLayout progressbarLayout = new javax.swing.GroupLayout(progressbar);
        progressbar.setLayout(progressbarLayout);
        progressbarLayout.setHorizontalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 340, Short.MAX_VALUE)
        );
        progressbarLayout.setVerticalGroup(
            progressbarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 20, Short.MAX_VALUE)
        );

        Fondo.add(progressbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 340, 20));

        Seleccion1.setBackground(new java.awt.Color(0, 74, 173));
        Seleccion1.setFont(new java.awt.Font("Questrial", 0, 36)); // NOI18N
        Seleccion1.setForeground(new java.awt.Color(0, 74, 173));
        Seleccion1.setText("Seleccione el estilo artístico del kiosco lúdico...");
        Fondo.add(Seleccion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 200, 740, -1));

        Salir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/boton_continuar_invertido.png"))); // NOI18N
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Salir1MouseClicked(evt);
            }
        });
        Fondo.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 560, 90, 80));

        Continuar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/continuar1.PNG"))); // NOI18N
        Continuar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Continuar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Continuar1MouseClicked(evt);
            }
        });
        Fondo.add(Continuar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 560, 90, 80));

        Banner1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Diseñar.PNG"))); // NOI18N
        Fondo.add(Banner1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1070, 140));

        panelMinimalista.setBackground(new java.awt.Color(255, 255, 255));
        panelMinimalista.setForeground(new java.awt.Color(0, 255, 255));
        panelMinimalista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelMinimalistaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelMinimalistaMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelMinimalistaMousePressed(evt);
            }
        });
        panelMinimalista.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoExterior6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Minmalista_1.PNG"))); // NOI18N
        iconoExterior6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelMinimalista.add(iconoExterior6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, 210));

        Exterior7.setBackground(new java.awt.Color(0, 74, 173));
        Exterior7.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Exterior7.setForeground(new java.awt.Color(0, 74, 173));
        Exterior7.setText("MINIMALISTA");
        panelMinimalista.add(Exterior7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 190, 70));

        Fondo.add(panelMinimalista, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 250, 220, 280));

        panelPopart.setBackground(new java.awt.Color(255, 255, 255));
        panelPopart.setForeground(new java.awt.Color(0, 255, 255));
        panelPopart.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelPopartMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelPopartMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelPopartMousePressed(evt);
            }
        });
        panelPopart.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoExterior5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Popart.PNG"))); // NOI18N
        iconoExterior5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelPopart.add(iconoExterior5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 40, 160, 190));

        Exterior6.setBackground(new java.awt.Color(0, 74, 173));
        Exterior6.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Exterior6.setForeground(new java.awt.Color(0, 74, 173));
        Exterior6.setText("POPART");
        panelPopart.add(Exterior6, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 170, 70));

        Fondo.add(panelPopart, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 250, 220, 280));

        panelModerno.setBackground(new java.awt.Color(255, 255, 255));
        panelModerno.setForeground(new java.awt.Color(0, 255, 255));
        panelModerno.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelModernoMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelModernoMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelModernoMousePressed(evt);
            }
        });
        panelModerno.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoExterior4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/moderno.PNG"))); // NOI18N
        iconoExterior4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelModerno.add(iconoExterior4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 200, 210));

        Exterior5.setBackground(new java.awt.Color(0, 74, 173));
        Exterior5.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Exterior5.setForeground(new java.awt.Color(0, 74, 173));
        Exterior5.setText("MODERNO");
        panelModerno.add(Exterior5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 170, 70));

        Fondo.add(panelModerno, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 250, 220, 280));

        panelFolk.setBackground(new java.awt.Color(255, 255, 255));
        panelFolk.setForeground(new java.awt.Color(0, 255, 255));
        panelFolk.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelFolkMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelFolkMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelFolkMousePressed(evt);
            }
        });
        panelFolk.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        iconoExterior3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Folklorico.PNG"))); // NOI18N
        iconoExterior3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        panelFolk.add(iconoExterior3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, -1, 210));

        Exterior4.setBackground(new java.awt.Color(0, 74, 173));
        Exterior4.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Exterior4.setForeground(new java.awt.Color(0, 74, 173));
        Exterior4.setText("FOLKLÓRICO");
        panelFolk.add(Exterior4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, 170, 70));

        Fondo.add(panelFolk, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, 220, 280));

        Plano1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano2.PNG"))); // NOI18N
        Fondo.add(Plano1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, 270, 360));

        jLabel2.setFont(new java.awt.Font("Questrial", 1, 22)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 204, 204));
        jLabel2.setText("Ver más");
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        Fondo.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 530, 110, -1));

        jLabel3.setFont(new java.awt.Font("Questrial", 1, 22)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 204, 204));
        jLabel3.setText("Ver más");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        Fondo.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 530, -1, -1));

        jLabel4.setFont(new java.awt.Font("Questrial", 1, 22)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 204, 204));
        jLabel4.setText("Ver más");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        Fondo.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 530, -1, -1));

        jLabel6.setFont(new java.awt.Font("Questrial", 1, 22)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 204, 204));
        jLabel6.setText("Ver más");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        Fondo.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 530, -1, -1));

        Plano2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/plano1.PNG"))); // NOI18N
        Fondo.add(Plano2, new org.netbeans.lib.awtextra.AbsoluteConstraints(850, 190, 200, 360));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void panelFolkMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelFolkMouseEntered
       if ((folkClickeado==false)&&(minClickeado==false)&&(modClickeado==false)&&(popClickeado)) {
           panelFolk.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelFolkMouseEntered

    private void panelFolkMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelFolkMouseExited
        if (folkClickeado==false) {
            panelFolk.setBackground(new Color (255,255,255));
        }
    }//GEN-LAST:event_panelFolkMouseExited

    private void panelFolkMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelFolkMousePressed
       folkClickeado=true;
       Seleccion1.setForeground(new Color (0,74,173));
       panelFolk.setBackground(new Color(229,254,255));
       panelFolk.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
       
       panelMinimalista.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelMinimalista.setBackground(new Color(255,255,255));
       minClickeado=false;
       
       panelModerno.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelModerno.setBackground(new Color(255,255,255));
       modClickeado=false;
       
       panelPopart.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelPopart.setBackground(new Color(255,255,255));
       popClickeado=false;
    }//GEN-LAST:event_panelFolkMousePressed

    private void panelModernoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelModernoMouseEntered
        if ((folkClickeado==false)&&(minClickeado==false)&&(modClickeado==false)&&(popClickeado)) {
           panelModerno.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelModernoMouseEntered

    private void panelModernoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelModernoMouseExited
        if (modClickeado==false) {
            panelModerno.setBackground(new Color (255,255,255));
        }
    }//GEN-LAST:event_panelModernoMouseExited

    private void panelModernoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelModernoMousePressed
       modClickeado=true;
       Seleccion1.setForeground(new Color (0,74,173));
       panelModerno.setBackground(new Color(229,254,255));
       panelModerno.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
       
       panelMinimalista.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelMinimalista.setBackground(new Color(255,255,255));
       minClickeado=false;
       
       panelFolk.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelFolk.setBackground(new Color(255,255,255));
       folkClickeado=false;
       
       panelPopart.setBorder(javax.swing.BorderFactory.createEmptyBorder());
       panelPopart.setBackground(new Color(255,255,255));
       popClickeado=false;
    }//GEN-LAST:event_panelModernoMousePressed

    private void panelPopartMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelPopartMouseEntered
        if ((folkClickeado==false)&&(minClickeado==false)&&(modClickeado==false)&&(popClickeado)) {
           panelPopart.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelPopartMouseEntered

    private void panelPopartMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelPopartMouseExited
      if (popClickeado==false) {
            panelPopart.setBackground(new Color (255,255,255));
        }
    }//GEN-LAST:event_panelPopartMouseExited

    private void panelPopartMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelPopartMousePressed
     popClickeado=true;
     Seleccion1.setForeground(new Color (0,74,173));
     panelPopart.setBackground(new Color(229,254,255));
     panelPopart.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
      
    panelMinimalista.setBorder(javax.swing.BorderFactory.createEmptyBorder());
    panelMinimalista.setBackground(new Color(255,255,255));
    minClickeado=false;
       
    panelFolk.setBorder(javax.swing.BorderFactory.createEmptyBorder());
    panelFolk.setBackground(new Color(255,255,255));
    folkClickeado=false;
       
       
    panelModerno.setBorder(javax.swing.BorderFactory.createEmptyBorder());
    panelModerno.setBackground(new Color(255,255,255));
    modClickeado=false;
       
       
      
    }//GEN-LAST:event_panelPopartMousePressed

    private void panelMinimalistaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMinimalistaMouseEntered
        if ((folkClickeado==false)&&(minClickeado==false)&&(modClickeado==false)&&(popClickeado)) {
           panelMinimalista.setBackground(new Color(229,254,255));
       }
    }//GEN-LAST:event_panelMinimalistaMouseEntered

    private void panelMinimalistaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMinimalistaMouseExited
        if (minClickeado==false) {
            panelMinimalista.setBackground(new Color (255,255,255));
        }
    }//GEN-LAST:event_panelMinimalistaMouseExited

    private void panelMinimalistaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelMinimalistaMousePressed
        minClickeado=true;
        Seleccion1.setForeground(new Color (0,74,173));
        panelMinimalista.setBackground(new Color(229,254,255));
        panelMinimalista.setBorder(javax.swing.BorderFactory.createLineBorder(new Color(0,204,204), 2));
        
        panelFolk.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        panelFolk.setBackground(new Color(255,255,255));
        folkClickeado=false;
        
        panelModerno.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        panelModerno.setBackground(new Color(255,255,255));
        modClickeado=false;
        
        panelPopart.setBorder(javax.swing.BorderFactory.createEmptyBorder());
        panelPopart.setBackground(new Color(255,255,255));
        popClickeado=false;
    
    }//GEN-LAST:event_panelMinimalistaMousePressed

    private void Continuar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Continuar1MouseClicked
       if ((minClickeado==false)&&(modClickeado==false)&&(folkClickeado==false)&&(popClickeado==false)) {
           Seleccion1.setForeground(new Color(204,0,51));
       }
       
       else 
       {
           if (camposDiseño.size()<3) 
            {
                if (folkClickeado==true) {
                   camposDiseño.add("Folklórico");
                }
                else if (minClickeado==true) {
                   camposDiseño.add("Minimalista");
                }
                else if (modClickeado==true) {
                   camposDiseño.add("Moderno");
                }
                else if (popClickeado==true) {
                   camposDiseño.add("PopArt");
                }
            }
           
            else 
            {
                 if (folkClickeado==true) {
                     camposDiseño.set(2,"Folklórico");
                 }
                 else if (minClickeado==true) {
                      camposDiseño.set(2,"Minimalista");
                 }
                 else if (modClickeado==true) {
                      camposDiseño.set(2,"Moderno");
                 }
                 else if (popClickeado==true) {
                      camposDiseño.set(2,"PopArt");
                 }
            }
           
           VentanaDiseñarNombre ventana = new VentanaDiseñarNombre(usuarioActual,camposDiseño);
           ventana.camposDiseño=camposDiseño;
           ventana.usuarioActual=usuarioActual;
           control.activaVentana(ventana, this);
        }
        
        
       
      
    }//GEN-LAST:event_Continuar1MouseClicked

    private void Salir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseClicked
        VentanaDiseñarMedidas ventana = new VentanaDiseñarMedidas(usuarioActual,camposDiseño);
        ventana.camposDiseño = camposDiseño;
        ventana.usuarioActual= usuarioActual;
        control.activaVentana(ventana, this);
    }//GEN-LAST:event_Salir1MouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        SubVentanaVerMas2 subVentana = new SubVentanaVerMas2(this, true);
        control.activaVentana(subVentana);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        SubVentanaVerMas3 subVentana = new SubVentanaVerMas3(this, true);
        control.activaVentana(subVentana);
    }//GEN-LAST:event_jLabel3MouseClicked

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        SubVentanaVerMas4 subVentana = new SubVentanaVerMas4(this, true);
        control.activaVentana(subVentana);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        SubVentanaVerMas1 subVentana = new SubVentanaVerMas1(this, true);
        control.activaVentana(subVentana);
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarEstilo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarEstilo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarEstilo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaDiseñarEstilo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaDiseñarEstilo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Banner1;
    private javax.swing.JLabel Continuar1;
    private javax.swing.JLabel Exterior4;
    private javax.swing.JLabel Exterior5;
    private javax.swing.JLabel Exterior6;
    private javax.swing.JLabel Exterior7;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Plano1;
    private javax.swing.JLabel Plano2;
    private javax.swing.JLabel Salir1;
    private javax.swing.JLabel Seleccion1;
    private javax.swing.JLabel iconoExterior3;
    private javax.swing.JLabel iconoExterior4;
    private javax.swing.JLabel iconoExterior5;
    private javax.swing.JLabel iconoExterior6;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel panelFolk;
    private javax.swing.JPanel panelMinimalista;
    private javax.swing.JPanel panelModerno;
    private javax.swing.JPanel panelPopart;
    private javax.swing.JPanel progressbar;
    private javax.swing.JPanel progressbar1;
    // End of variables declaration//GEN-END:variables
}
