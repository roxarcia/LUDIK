/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import controller.Controladora;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.JOptionPane;
import modelo.Material;
import java.util.ArrayList;
import modelo.Diseño;
import modelo.Usuario;
import persistencia.DiseñosXML;
import persistencia.MaterialesXML;



/**
 *
 * @author Cristian De Sousa
 */
public class VentanaComprar2 extends javax.swing.JFrame {
    Controladora control;
    String nombre;
    Object[] opciones = {"Sí", "No"};
    DiseñosXML datosDise = new DiseñosXML();
    ArrayList<Diseño> listaDiseños= datosDise.todosLosDiseños();
    
    MaterialesXML datosMat = new MaterialesXML();
    ArrayList<Material> materiales = new ArrayList<Material>();
    Usuario usuarioActual;
    Diseño diseñoActual;
    
    /**
     * Creates new form VentanaComprar2
     */
    public VentanaComprar2() {
        initComponents();
        this.nombre="";
        this.usuarioActual= new Usuario();
        this.diseñoActual= new Diseño();
        this.listaDiseños = new ArrayList<>();
        control = new Controladora(this);
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        control.spinner_Off(CantidadE1);
        control.spinner_Off(CantidadE2);
        control.spinner_Off(CantidadE3);
        control.spinner_Off(CantidadE4);
        control.spinner_Off(CantidadE5);
        control.spinner_Off(CantidadE6);
        control.spinner_Off(CantidadE7);
        control.spinner_Off(CantidadE8);
        control.spinner_Off(CantidadE9);
        control.spinner_Off(CantidadEn1);
        control.spinner_Off(CantidadEn2);
        control.spinner_Off(CantidadEn3);
        control.spinner_Off(CantidadEn4);
        control.spinner_Off(CantidadEn5);
        control.spinner_Off(CantidadEn6);
        control.spinner_Off(CantidadEn7);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH2);
        control.spinner_Off(CantidadH3);
        control.spinner_Off(CantidadH4);
        control.spinner_Off(CantidadH5);
        control.spinner_Off(CantidadH6);
        control.spinner_Off(CantidadH7);
        control.spinner_Off(CantidadH8);
        control.spinner_Off(CantidadH9);
        control.spinner_Off(CantidadH10);
        control.spinner_Off(CantidadH11);
        control.spinner_Off(CantidadH12);
        control.spinner_Off(CantidadH13);
        control.spinner_Off(CantidadH14);
        control.spinner_Off(CantidadH15);
        control.spinner_Off(CantidadH16);
        control.spinner_Off(CantidadH17);
        control.spinner_Off(CantidadH18);
        control.spinner_Off(CantidadD1);
        control.spinner_Off(CantidadD2);
        control.spinner_Off(CantidadD3);
        control.spinner_Off(CantidadD4);
        control.spinner_Off(CantidadD5);
        control.spinner_Off(CantidadD6);
        control.spinner_Off(CantidadP1);
        control.spinner_Off(CantidadP2);
        control.spinner_Off(CantidadP3);
        control.spinner_Off(CantidadP4);
        control.activa_Desactiva3(false, FinalizarB);
    }
    
    public VentanaComprar2(Diseño diseño, Usuario user) {
        initComponents();
        this.usuarioActual=user;
        this.diseñoActual=diseño;
        this.nombre=diseño.getNombre();
        this.listaDiseños = new ArrayList<>();
        listaDiseños=datosDise.todosLosDiseños();
        control = new Controladora(this);
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        control.spinner_Off(CantidadE1);
        control.spinner_Off(CantidadE2);
        control.spinner_Off(CantidadE3);
        control.spinner_Off(CantidadE4);
        control.spinner_Off(CantidadE5);
        control.spinner_Off(CantidadE6);
        control.spinner_Off(CantidadE7);
        control.spinner_Off(CantidadE8);
        control.spinner_Off(CantidadE9);
        control.spinner_Off(CantidadEn1);
        control.spinner_Off(CantidadEn2);
        control.spinner_Off(CantidadEn3);
        control.spinner_Off(CantidadEn4);
        control.spinner_Off(CantidadEn5);
        control.spinner_Off(CantidadEn6);
        control.spinner_Off(CantidadEn7);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH1);
        control.spinner_Off(CantidadH2);
        control.spinner_Off(CantidadH3);
        control.spinner_Off(CantidadH4);
        control.spinner_Off(CantidadH5);
        control.spinner_Off(CantidadH6);
        control.spinner_Off(CantidadH7);
        control.spinner_Off(CantidadH8);
        control.spinner_Off(CantidadH9);
        control.spinner_Off(CantidadH10);
        control.spinner_Off(CantidadH11);
        control.spinner_Off(CantidadH12);
        control.spinner_Off(CantidadH13);
        control.spinner_Off(CantidadH14);
        control.spinner_Off(CantidadH15);
        control.spinner_Off(CantidadH16);
        control.spinner_Off(CantidadH17);
        control.spinner_Off(CantidadH18);
        control.spinner_Off(CantidadD1);
        control.spinner_Off(CantidadD2);
        control.spinner_Off(CantidadD3);
        control.spinner_Off(CantidadD4);
        control.spinner_Off(CantidadD5);
        control.spinner_Off(CantidadD6);
        control.spinner_Off(CantidadP1);
        control.spinner_Off(CantidadP2);
        control.spinner_Off(CantidadP3);
        control.spinner_Off(CantidadP4);
        control.activa_Desactiva3(false, FinalizarB);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ComprarBanner = new javax.swing.JLabel();
        TiposMateriales = new javax.swing.JTabbedPane();
        PanelTipos = new javax.swing.JPanel();
        Salir1 = new javax.swing.JLabel();
        FinalizarB = new javax.swing.JLabel();
        ElegirTipoMaterial = new javax.swing.JLabel();
        proteccion_label_btn = new javax.swing.JLabel();
        estructura_label_btn = new javax.swing.JLabel();
        ensamblaje_label_btn = new javax.swing.JLabel();
        decoracion_label_btn = new javax.swing.JLabel();
        herramientas_label_btn = new javax.swing.JLabel();
        Recurso1 = new javax.swing.JLabel();
        Recurso2 = new javax.swing.JLabel();
        Tractoricon1 = new javax.swing.JLabel();
        SubVentanaE = new javax.swing.JScrollPane();
        jPanel12 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        Estructura8 = new javax.swing.JLabel();
        Estructura9 = new javax.swing.JLabel();
        Recurso8 = new javax.swing.JLabel();
        Materiales6 = new javax.swing.JLabel();
        CostoPU6 = new javax.swing.JLabel();
        CostoE8 = new javax.swing.JLabel();
        CostoE9 = new javax.swing.JLabel();
        Atras12B = new javax.swing.JLabel();
        Cantidad6 = new javax.swing.JLabel();
        CantidadE8 = new javax.swing.JSpinner();
        CantidadE9 = new javax.swing.JSpinner();
        Estructura8B = new javax.swing.JCheckBox();
        Estructura9B = new javax.swing.JCheckBox();
        SustentablesE = new javax.swing.JLabel();
        SubVentanaE_S = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Estructura1 = new javax.swing.JLabel();
        Estructura2 = new javax.swing.JLabel();
        Estructura3 = new javax.swing.JLabel();
        Estructura4 = new javax.swing.JLabel();
        Estructura5 = new javax.swing.JLabel();
        Estructura6 = new javax.swing.JLabel();
        Estructura7 = new javax.swing.JLabel();
        Recurso3 = new javax.swing.JLabel();
        Materiales1 = new javax.swing.JLabel();
        CostoPU1 = new javax.swing.JLabel();
        CostoE1 = new javax.swing.JLabel();
        CostoE2 = new javax.swing.JLabel();
        CostoE3 = new javax.swing.JLabel();
        CostoE4 = new javax.swing.JLabel();
        CostoE5 = new javax.swing.JLabel();
        CostoE6 = new javax.swing.JLabel();
        CostoE7 = new javax.swing.JLabel();
        Atras1B = new javax.swing.JLabel();
        Cantidad1 = new javax.swing.JLabel();
        CantidadE1 = new javax.swing.JSpinner();
        CantidadE2 = new javax.swing.JSpinner();
        CantidadE3 = new javax.swing.JSpinner();
        CantidadE4 = new javax.swing.JSpinner();
        CantidadE5 = new javax.swing.JSpinner();
        CantidadE6 = new javax.swing.JSpinner();
        CantidadE7 = new javax.swing.JSpinner();
        Estructura1B = new javax.swing.JCheckBox();
        Estructura2B = new javax.swing.JCheckBox();
        Estructura3B = new javax.swing.JCheckBox();
        Estructura4B = new javax.swing.JCheckBox();
        Estructura5B = new javax.swing.JCheckBox();
        Estructura6B = new javax.swing.JCheckBox();
        Estructura7B = new javax.swing.JCheckBox();
        NoSustentablesE = new javax.swing.JLabel();
        SubVentanaEn = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        Materiales2 = new javax.swing.JLabel();
        Ensamblaje1 = new javax.swing.JLabel();
        Ensamblaje2 = new javax.swing.JLabel();
        Ensamblaje3 = new javax.swing.JLabel();
        Ensamblaje4 = new javax.swing.JLabel();
        Ensamblaje5 = new javax.swing.JLabel();
        Ensamblaje6 = new javax.swing.JLabel();
        Ensamblaje7 = new javax.swing.JLabel();
        CostoPU2 = new javax.swing.JLabel();
        CostoEn1 = new javax.swing.JLabel();
        CostoEn2 = new javax.swing.JLabel();
        CostoEn3 = new javax.swing.JLabel();
        CostoEn4 = new javax.swing.JLabel();
        CostoEn5 = new javax.swing.JLabel();
        CostoEn6 = new javax.swing.JLabel();
        CostoEn7 = new javax.swing.JLabel();
        Cantidad2 = new javax.swing.JLabel();
        CantidadEn1 = new javax.swing.JSpinner();
        CantidadEn2 = new javax.swing.JSpinner();
        CantidadEn3 = new javax.swing.JSpinner();
        CantidadEn4 = new javax.swing.JSpinner();
        CantidadEn5 = new javax.swing.JSpinner();
        CantidadEn6 = new javax.swing.JSpinner();
        CantidadEn7 = new javax.swing.JSpinner();
        Atras2B = new javax.swing.JLabel();
        Recurso4 = new javax.swing.JLabel();
        Ensamblaje1B = new javax.swing.JCheckBox();
        Ensamblaje2B = new javax.swing.JCheckBox();
        Ensamblaje3B = new javax.swing.JCheckBox();
        Ensamblaje4B = new javax.swing.JCheckBox();
        Ensamblaje5B = new javax.swing.JCheckBox();
        Ensamblaje6B = new javax.swing.JCheckBox();
        Ensamblaje7B = new javax.swing.JCheckBox();
        SubVentanaH = new javax.swing.JScrollPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        Materiales3 = new javax.swing.JLabel();
        Herramienta1 = new javax.swing.JLabel();
        Herramienta2 = new javax.swing.JLabel();
        Herramienta3 = new javax.swing.JLabel();
        Herramienta4 = new javax.swing.JLabel();
        Herramienta5 = new javax.swing.JLabel();
        Herramienta6 = new javax.swing.JLabel();
        Herramienta7 = new javax.swing.JLabel();
        Herramienta8 = new javax.swing.JLabel();
        Herramienta9 = new javax.swing.JLabel();
        Herramienta10 = new javax.swing.JLabel();
        Herramienta11 = new javax.swing.JLabel();
        Herramienta12 = new javax.swing.JLabel();
        Herramienta13 = new javax.swing.JLabel();
        Herramienta14 = new javax.swing.JLabel();
        Herramienta15 = new javax.swing.JLabel();
        Herramienta16 = new javax.swing.JLabel();
        Herramienta17 = new javax.swing.JLabel();
        Herramienta18 = new javax.swing.JLabel();
        Recurso5 = new javax.swing.JLabel();
        CostoPU3 = new javax.swing.JLabel();
        CostoH1 = new javax.swing.JLabel();
        CostoH2 = new javax.swing.JLabel();
        CostoH3 = new javax.swing.JLabel();
        CostoH4 = new javax.swing.JLabel();
        CostoH5 = new javax.swing.JLabel();
        CostoH6 = new javax.swing.JLabel();
        CostoH7 = new javax.swing.JLabel();
        CostoH8 = new javax.swing.JLabel();
        CostoH9 = new javax.swing.JLabel();
        CostoH10 = new javax.swing.JLabel();
        CostoH11 = new javax.swing.JLabel();
        CostoH12 = new javax.swing.JLabel();
        CostoH13 = new javax.swing.JLabel();
        CostoH14 = new javax.swing.JLabel();
        CostoH15 = new javax.swing.JLabel();
        CostoH16 = new javax.swing.JLabel();
        CostoH17 = new javax.swing.JLabel();
        CostoH18 = new javax.swing.JLabel();
        Atras3B = new javax.swing.JLabel();
        Cantidad3 = new javax.swing.JLabel();
        CantidadH1 = new javax.swing.JSpinner();
        CantidadH2 = new javax.swing.JSpinner();
        CantidadH3 = new javax.swing.JSpinner();
        CantidadH4 = new javax.swing.JSpinner();
        CantidadH5 = new javax.swing.JSpinner();
        CantidadH6 = new javax.swing.JSpinner();
        CantidadH7 = new javax.swing.JSpinner();
        CantidadH8 = new javax.swing.JSpinner();
        CantidadH9 = new javax.swing.JSpinner();
        CantidadH10 = new javax.swing.JSpinner();
        CantidadH11 = new javax.swing.JSpinner();
        CantidadH12 = new javax.swing.JSpinner();
        CantidadH13 = new javax.swing.JSpinner();
        CantidadH14 = new javax.swing.JSpinner();
        CantidadH15 = new javax.swing.JSpinner();
        CantidadH16 = new javax.swing.JSpinner();
        CantidadH17 = new javax.swing.JSpinner();
        CantidadH18 = new javax.swing.JSpinner();
        Herramienta1B = new javax.swing.JCheckBox();
        Herramienta2B = new javax.swing.JCheckBox();
        Herramienta3B = new javax.swing.JCheckBox();
        Herramienta4B = new javax.swing.JCheckBox();
        Herramienta5B = new javax.swing.JCheckBox();
        Herramienta6B = new javax.swing.JCheckBox();
        Herramienta7B = new javax.swing.JCheckBox();
        Herramienta8B = new javax.swing.JCheckBox();
        Herramienta9B = new javax.swing.JCheckBox();
        Herramienta10B = new javax.swing.JCheckBox();
        Herramienta11B = new javax.swing.JCheckBox();
        Herramienta12B = new javax.swing.JCheckBox();
        Herramienta13B = new javax.swing.JCheckBox();
        Herramienta14B = new javax.swing.JCheckBox();
        Herramienta15B = new javax.swing.JCheckBox();
        Herramienta16B = new javax.swing.JCheckBox();
        Herramienta17B = new javax.swing.JCheckBox();
        Herramienta18B = new javax.swing.JCheckBox();
        SubVentanaD = new javax.swing.JScrollPane();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        Materiales4 = new javax.swing.JLabel();
        Decoracion1 = new javax.swing.JLabel();
        Decoracion2 = new javax.swing.JLabel();
        Decoracion3 = new javax.swing.JLabel();
        Decoracion6 = new javax.swing.JLabel();
        CostoPU4 = new javax.swing.JLabel();
        CostoD1 = new javax.swing.JLabel();
        CostoD2 = new javax.swing.JLabel();
        CostoD3 = new javax.swing.JLabel();
        CostoD6 = new javax.swing.JLabel();
        Cantidad4 = new javax.swing.JLabel();
        CantidadD1 = new javax.swing.JSpinner();
        CantidadD2 = new javax.swing.JSpinner();
        CantidadD3 = new javax.swing.JSpinner();
        CantidadD6 = new javax.swing.JSpinner();
        Atras4B = new javax.swing.JLabel();
        Recurso6 = new javax.swing.JLabel();
        Decoracion1B = new javax.swing.JCheckBox();
        Decoracion2B = new javax.swing.JCheckBox();
        Decoracion3B = new javax.swing.JCheckBox();
        Decoracion6B = new javax.swing.JCheckBox();
        SustentablesD = new javax.swing.JLabel();
        SubVentanaD_S = new javax.swing.JScrollPane();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        Materiales7 = new javax.swing.JLabel();
        Decoracion4 = new javax.swing.JLabel();
        Decoracion5 = new javax.swing.JLabel();
        CostoPU7 = new javax.swing.JLabel();
        CostoD4 = new javax.swing.JLabel();
        CostoD5 = new javax.swing.JLabel();
        Cantidad7 = new javax.swing.JLabel();
        CantidadD4 = new javax.swing.JSpinner();
        CantidadD5 = new javax.swing.JSpinner();
        Atras41B = new javax.swing.JLabel();
        Recurso9 = new javax.swing.JLabel();
        NoSustentablesD = new javax.swing.JLabel();
        Decoracion4B = new javax.swing.JCheckBox();
        Decoracion5B = new javax.swing.JCheckBox();
        SubVentanaP = new javax.swing.JScrollPane();
        jPanel10 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        Materiales5 = new javax.swing.JLabel();
        Proteccion1 = new javax.swing.JLabel();
        Proteccion2 = new javax.swing.JLabel();
        Proteccion3 = new javax.swing.JLabel();
        Proteccion4 = new javax.swing.JLabel();
        CostoPU5 = new javax.swing.JLabel();
        CostoP1 = new javax.swing.JLabel();
        CostoP2 = new javax.swing.JLabel();
        CostoP3 = new javax.swing.JLabel();
        CostoP4 = new javax.swing.JLabel();
        Cantidad5 = new javax.swing.JLabel();
        CantidadP1 = new javax.swing.JSpinner();
        CantidadP2 = new javax.swing.JSpinner();
        CantidadP3 = new javax.swing.JSpinner();
        CantidadP4 = new javax.swing.JSpinner();
        Atras5B = new javax.swing.JLabel();
        Recurso7 = new javax.swing.JLabel();
        Proteccion1B = new javax.swing.JCheckBox();
        Proteccion2B = new javax.swing.JCheckBox();
        Proteccion3B = new javax.swing.JCheckBox();
        Proteccion4B = new javax.swing.JCheckBox();
        Resumen_materiales = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tablamateriales = new javax.swing.JTable();
        HechoB = new javax.swing.JLabel();
        EditarB = new javax.swing.JLabel();
        ResumenMateriales = new javax.swing.JLabel();
        CostoFinal = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1060, 640));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ComprarBanner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Banner_comprar.png"))); // NOI18N
        getContentPane().add(ComprarBanner, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 140));

        TiposMateriales.setBackground(new java.awt.Color(255, 255, 255));

        PanelTipos.setBackground(new java.awt.Color(255, 255, 255));
        PanelTipos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Salir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Salir1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Salir1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Salir1MouseExited(evt);
            }
        });
        PanelTipos.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, 70, 80));

        FinalizarB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/boton_finalizar_1.png"))); // NOI18N
        FinalizarB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        FinalizarB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FinalizarBMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FinalizarBMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                FinalizarBMouseExited(evt);
            }
        });
        PanelTipos.add(FinalizarB, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 400, -1, 70));

        ElegirTipoMaterial.setFont(new java.awt.Font("Garet Heavy", 0, 40)); // NOI18N
        ElegirTipoMaterial.setForeground(new java.awt.Color(35, 155, 228));
        ElegirTipoMaterial.setText(" Elegir Tipo de Material");
        PanelTipos.add(ElegirTipoMaterial, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, -1, -1));

        proteccion_label_btn.setBackground(new java.awt.Color(255, 255, 255));
        proteccion_label_btn.setFont(new java.awt.Font("Questrial", 1, 36)); // NOI18N
        proteccion_label_btn.setForeground(new java.awt.Color(0, 74, 173));
        proteccion_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Casco.png"))); // NOI18N
        proteccion_label_btn.setText("PROTECCIÓN");
        proteccion_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        proteccion_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                proteccion_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                proteccion_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                proteccion_label_btnMouseExited(evt);
            }
        });
        PanelTipos.add(proteccion_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 300, -1, 60));

        estructura_label_btn.setFont(new java.awt.Font("Questrial", 1, 36)); // NOI18N
        estructura_label_btn.setForeground(new java.awt.Color(0, 74, 173));
        estructura_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Acero.png"))); // NOI18N
        estructura_label_btn.setText("ESTRUCTURA");
        estructura_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        estructura_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                estructura_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                estructura_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                estructura_label_btnMouseExited(evt);
            }
        });
        PanelTipos.add(estructura_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, -1, -1));

        ensamblaje_label_btn.setFont(new java.awt.Font("Questrial", 1, 36)); // NOI18N
        ensamblaje_label_btn.setForeground(new java.awt.Color(0, 74, 173));
        ensamblaje_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Tornillos.png"))); // NOI18N
        ensamblaje_label_btn.setText("ENSAMBLAJE");
        ensamblaje_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ensamblaje_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ensamblaje_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ensamblaje_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ensamblaje_label_btnMouseExited(evt);
            }
        });
        PanelTipos.add(ensamblaje_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 110, -1, 60));

        decoracion_label_btn.setFont(new java.awt.Font("Questrial", 1, 36)); // NOI18N
        decoracion_label_btn.setForeground(new java.awt.Color(0, 74, 173));
        decoracion_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/brocha.png"))); // NOI18N
        decoracion_label_btn.setText("DECORACIÓN");
        decoracion_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        decoracion_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                decoracion_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                decoracion_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                decoracion_label_btnMouseExited(evt);
            }
        });
        PanelTipos.add(decoracion_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 300, 330, -1));

        herramientas_label_btn.setFont(new java.awt.Font("Questrial", 1, 36)); // NOI18N
        herramientas_label_btn.setForeground(new java.awt.Color(0, 74, 173));
        herramientas_label_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Herramientas.png"))); // NOI18N
        herramientas_label_btn.setText("HERRAMIENTAS");
        herramientas_label_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        herramientas_label_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                herramientas_label_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                herramientas_label_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                herramientas_label_btnMouseExited(evt);
            }
        });
        PanelTipos.add(herramientas_label_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 210, -1, 60));

        Recurso1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        PanelTipos.add(Recurso1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-190, 110, 320, 280));

        Recurso2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        PanelTipos.add(Recurso2, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 140, 320, 280));

        Tractoricon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo1_comprar.png"))); // NOI18N
        Tractoricon1.setText("s");
        PanelTipos.add(Tractoricon1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 380, 110, 110));

        TiposMateriales.addTab("Tipos", PanelTipos);

        SubVentanaE.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaE.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel13.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Estructura8.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura8.setForeground(new java.awt.Color(0, 74, 173));
        Estructura8.setText("Plancha de PVC ");
        jPanel13.add(Estructura8, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 490, 60));

        Estructura9.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura9.setForeground(new java.awt.Color(0, 74, 173));
        Estructura9.setText("Tubo PP Roscable 1/2\" x 6 mts");
        jPanel13.add(Estructura9, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, 490, 60));

        Recurso8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel13.add(Recurso8, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 130, -1, -1));

        Materiales6.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales6.setForeground(new java.awt.Color(0, 74, 173));
        Materiales6.setText("MATERIALES");
        jPanel13.add(Materiales6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        CostoPU6.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU6.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU6.setText("Costo P/U");
        jPanel13.add(CostoPU6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, 170, 60));

        CostoE8.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE8.setForeground(new java.awt.Color(0, 74, 173));
        CostoE8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE8.setText("11.34$");
        jPanel13.add(CostoE8, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 130, 210, 60));

        CostoE9.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE9.setForeground(new java.awt.Color(0, 74, 173));
        CostoE9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE9.setText("11.85$");
        jPanel13.add(CostoE9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 210, 210, 60));

        Atras12B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras12B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras12B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras12BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras12BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras12BMouseExited(evt);
            }
        });
        jPanel13.add(Atras12B, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, -1, -1));

        Cantidad6.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad6.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad6.setText("Cantidad");
        jPanel13.add(Cantidad6, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadE8.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE8.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel13.add(CantidadE8, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 140, 80, 40));

        CantidadE9.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE9.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel13.add(CantidadE9, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 220, 80, 40));

        Estructura8B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura8BActionPerformed(evt);
            }
        });
        jPanel13.add(Estructura8B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 20, 20));

        Estructura9B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura9BActionPerformed(evt);
            }
        });
        jPanel13.add(Estructura9B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 20, 20));

        SustentablesE.setFont(new java.awt.Font("Garet Book", 1, 12)); // NOI18N
        SustentablesE.setForeground(new java.awt.Color(0, 74, 173));
        SustentablesE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SustentablesE.setText("ir a sustentables");
        SustentablesE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SustentablesEMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SustentablesEMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SustentablesEMouseExited(evt);
            }
        });
        jPanel13.add(SustentablesE, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 140, 30));

        jPanel12.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 540));

        SubVentanaE.setViewportView(jPanel12);

        TiposMateriales.addTab("Estructura", SubVentanaE);

        SubVentanaE_S.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaE_S.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel4.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Estructura1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura1.setForeground(new java.awt.Color(0, 74, 173));
        Estructura1.setText("Pingos de Eucalipto");
        jPanel4.add(Estructura1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 110, 390, 60));

        Estructura2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura2.setForeground(new java.awt.Color(0, 74, 173));
        Estructura2.setText("Bambu culmos 6m x (2m diametro)");
        jPanel4.add(Estructura2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 270, 390, 60));

        Estructura3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura3.setForeground(new java.awt.Color(0, 74, 173));
        Estructura3.setText("Madera reciclada de pino");
        jPanel4.add(Estructura3, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 390, 60));

        Estructura4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura4.setForeground(new java.awt.Color(0, 74, 173));
        Estructura4.setText("Carton Reciclado");
        jPanel4.add(Estructura4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 350, 390, 60));

        Estructura5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura5.setForeground(new java.awt.Color(0, 74, 173));
        Estructura5.setText("Palets 100 x 120 fuerte reciclado");
        jPanel4.add(Estructura5, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 430, 440, 60));

        Estructura6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura6.setForeground(new java.awt.Color(0, 74, 173));
        Estructura6.setText("Planchas De Cartón Corrugado Kraft ");
        jPanel4.add(Estructura6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 510, 490, 60));

        Estructura7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Estructura7.setForeground(new java.awt.Color(0, 74, 173));
        Estructura7.setText("Paneles de latilla de bambú");
        jPanel4.add(Estructura7, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 590, 490, 60));

        Recurso3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel4.add(Recurso3, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 260, -1, -1));

        Materiales1.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales1.setForeground(new java.awt.Color(0, 74, 173));
        Materiales1.setText("MATERIALES");
        jPanel4.add(Materiales1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        CostoPU1.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU1.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU1.setText("Costo P/U");
        jPanel4.add(CostoPU1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, 170, 60));

        CostoE1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE1.setForeground(new java.awt.Color(0, 74, 173));
        CostoE1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE1.setText("7.50$");
        jPanel4.add(CostoE1, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 110, 210, 60));

        CostoE2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE2.setForeground(new java.awt.Color(0, 74, 173));
        CostoE2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE2.setText("10$");
        jPanel4.add(CostoE2, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 190, 210, 60));

        CostoE3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE3.setForeground(new java.awt.Color(0, 74, 173));
        CostoE3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE3.setText("6.51$");
        jPanel4.add(CostoE3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 270, 210, 60));

        CostoE4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE4.setForeground(new java.awt.Color(0, 74, 173));
        CostoE4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE4.setText("0.10$");
        jPanel4.add(CostoE4, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 350, 210, 60));

        CostoE5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE5.setForeground(new java.awt.Color(0, 74, 173));
        CostoE5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE5.setText("5.77$");
        jPanel4.add(CostoE5, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 430, 210, 60));

        CostoE6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE6.setForeground(new java.awt.Color(0, 74, 173));
        CostoE6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE6.setText("1.75$");
        jPanel4.add(CostoE6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 510, 210, 60));

        CostoE7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoE7.setForeground(new java.awt.Color(0, 74, 173));
        CostoE7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoE7.setText("8.87$");
        jPanel4.add(CostoE7, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 590, 210, 60));

        Atras1B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras1B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras1B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras1BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras1BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras1BMouseExited(evt);
            }
        });
        jPanel4.add(Atras1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 670, -1, -1));

        Cantidad1.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad1.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad1.setText("Cantidad");
        jPanel4.add(Cantidad1, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadE1.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE1, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 120, 80, 40));

        CantidadE2.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE2, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 200, 80, 40));

        CantidadE3.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE3, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 280, 80, 40));

        CantidadE4.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE4.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 360, 80, 40));

        CantidadE5.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE5.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE5, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 440, 80, 40));

        CantidadE6.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE6.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE6, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 520, 80, 40));

        CantidadE7.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadE7.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel4.add(CantidadE7, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 600, 80, 40));

        Estructura1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura1BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 130, 20, 20));

        Estructura2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura2BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, 20, 20));

        Estructura3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura3BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 290, 20, 20));

        Estructura4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura4BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 370, 20, 20));

        Estructura5B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura5BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 450, 20, 20));

        Estructura6B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura6BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura6B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 530, 20, 20));

        Estructura7B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Estructura7BActionPerformed(evt);
            }
        });
        jPanel4.add(Estructura7B, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 610, 20, 20));

        NoSustentablesE.setFont(new java.awt.Font("Garet Book", 1, 12)); // NOI18N
        NoSustentablesE.setForeground(new java.awt.Color(0, 74, 173));
        NoSustentablesE.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NoSustentablesE.setText("ir a no sustentables");
        NoSustentablesE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NoSustentablesEMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                NoSustentablesEMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                NoSustentablesEMouseExited(evt);
            }
        });
        jPanel4.add(NoSustentablesE, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 150, 30));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 760));

        SubVentanaE_S.setViewportView(jPanel2);

        TiposMateriales.addTab("Estructura", SubVentanaE_S);

        SubVentanaEn.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaEn.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel5.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Materiales2.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales2.setForeground(new java.awt.Color(0, 74, 173));
        Materiales2.setText("MATERIALES");
        jPanel5.add(Materiales2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        Ensamblaje1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje1.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje1.setText("Clavos de libra funda 454g CC 75x3,80");
        jPanel5.add(Ensamblaje1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 100, 410, 60));

        Ensamblaje2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje2.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje2.setText("Tornillo Madera 1 1/2x8 RG");
        jPanel5.add(Ensamblaje2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 390, 60));

        Ensamblaje3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje3.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje3.setText("Perno A325 1/2\"x1-1/2\" C/T + Arandela");
        jPanel5.add(Ensamblaje3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 180, 420, 60));

        Ensamblaje4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje4.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje4.setText("Cajetín rectangular \"Plastigama\" plástico");
        jPanel5.add(Ensamblaje4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, 440, 60));

        Ensamblaje5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje5.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje5.setText("Cable Sólido THHN #12 AWG 100 m.");
        jPanel5.add(Ensamblaje5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 420, 440, 60));

        Ensamblaje6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje6.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje6.setText("Tomacorriente Doble Amer 2P+E Blitz\t");
        jPanel5.add(Ensamblaje6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 500, 490, 60));

        Ensamblaje7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Ensamblaje7.setForeground(new java.awt.Color(0, 74, 173));
        Ensamblaje7.setText("Interruptor Simple 10A Negro Aqua L100044\t");
        jPanel5.add(Ensamblaje7, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 580, 490, 60));

        CostoPU2.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU2.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU2.setText("Costo P/U");
        jPanel5.add(CostoPU2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 170, 60));

        CostoEn1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn1.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn1.setText("60.34$");
        jPanel5.add(CostoEn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 100, 210, 60));

        CostoEn2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn2.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn2.setText("0.83$");
        jPanel5.add(CostoEn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, 210, 60));

        CostoEn3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn3.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn3.setText("0.03$");
        jPanel5.add(CostoEn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 260, 210, 60));

        CostoEn4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn4.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn4.setText("1.03$");
        jPanel5.add(CostoEn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 340, 210, 60));

        CostoEn5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn5.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn5.setText("71.30$");
        jPanel5.add(CostoEn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 420, 210, 60));

        CostoEn6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn6.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn6.setText("1.89$");
        jPanel5.add(CostoEn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 500, 210, 60));

        CostoEn7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoEn7.setForeground(new java.awt.Color(0, 74, 173));
        CostoEn7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoEn7.setText("2.69$");
        jPanel5.add(CostoEn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 580, 210, 60));

        Cantidad2.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad2.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad2.setText("Cantidad");
        jPanel5.add(Cantidad2, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadEn1.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 110, 80, 40));

        CantidadEn2.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 190, 80, 40));

        CantidadEn3.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 80, 40));

        CantidadEn4.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn4.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn4, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 350, 80, 40));

        CantidadEn5.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn5.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 430, 80, 40));

        CantidadEn6.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn6.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 510, 80, 40));

        CantidadEn7.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadEn7.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel5.add(CantidadEn7, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 590, 80, 40));

        Atras2B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras2B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras2B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras2BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras2BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras2BMouseExited(evt);
            }
        });
        jPanel5.add(Atras2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 650, -1, -1));

        Recurso4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel5.add(Recurso4, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 260, -1, -1));

        Ensamblaje1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje1BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 120, 20, 20));

        Ensamblaje2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje2BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 20, -1));

        Ensamblaje3B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Ensamblaje3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje3BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 280, 20, 20));

        Ensamblaje4B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Ensamblaje4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje4BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 360, 20, -1));

        Ensamblaje5B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Ensamblaje5B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje5BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 440, 20, 20));

        Ensamblaje6B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Ensamblaje6B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje6BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje6B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 520, 20, -1));

        Ensamblaje7B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Ensamblaje7B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Ensamblaje7BActionPerformed(evt);
            }
        });
        jPanel5.add(Ensamblaje7B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 600, 20, 20));

        jPanel3.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 740));

        SubVentanaEn.setViewportView(jPanel3);

        TiposMateriales.addTab("Ensamblaje", SubVentanaEn);

        SubVentanaH.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaH.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel7.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Materiales3.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales3.setForeground(new java.awt.Color(0, 74, 173));
        Materiales3.setText("MATERIALES");
        jPanel7.add(Materiales3, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        Herramienta1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta1.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta1.setText("Martillo metálico de 29mm");
        jPanel7.add(Herramienta1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, 390, 60));

        Herramienta2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta2.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta2.setText("Arco Sierra Elite 24\"");
        jPanel7.add(Herramienta2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 260, 390, 60));

        Herramienta3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta3.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta3.setText("Carretilla con llanta inflable\t");
        jPanel7.add(Herramienta3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 180, 390, 60));

        Herramienta4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta4.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta4.setText("Juegos de destornilladores WorkPro\t");
        jPanel7.add(Herramienta4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, 390, 60));

        Herramienta5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta5.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta5.setText("Cinta métrica Stanley");
        jPanel7.add(Herramienta5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 420, 440, 60));

        Herramienta6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta6.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta6.setText("Nivel resina estructural Stanley");
        jPanel7.add(Herramienta6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 500, 490, 60));

        Herramienta7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta7.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta7.setText("Alicate Universal Stanley");
        jPanel7.add(Herramienta7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 580, 490, 60));

        Herramienta8.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta8.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta8.setText("Serrucho Luctador Stanley");
        jPanel7.add(Herramienta8, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 660, 490, 60));

        Herramienta9.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta9.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta9.setText("Escuadra 12\" para carpintero");
        jPanel7.add(Herramienta9, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 740, 490, 60));

        Herramienta10.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta10.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta10.setText("Lápiz Para Carpintero Stanley");
        jPanel7.add(Herramienta10, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 820, 490, 60));

        Herramienta11.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta11.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta11.setText("Set llaves mixtas rachet 8PCS");
        jPanel7.add(Herramienta11, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 900, 490, 60));

        Herramienta12.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta12.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta12.setText("Prensa sargento 157 5 pies");
        jPanel7.add(Herramienta12, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 980, 490, 60));

        Herramienta13.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta13.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta13.setText("Paquete variado de papel de lija");
        jPanel7.add(Herramienta13, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1060, 490, 60));

        Herramienta14.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta14.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta14.setText("Taladro de Rotación de 3/8\" Dewalt");
        jPanel7.add(Herramienta14, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1140, 490, 60));

        Herramienta15.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta15.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta15.setText("Sierra Ingleteadora de 10\" 15A Dewalt\t\t ");
        jPanel7.add(Herramienta15, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1220, 490, 60));

        Herramienta16.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta16.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta16.setText("Sierra Circular 7 1/4\" Stanley");
        jPanel7.add(Herramienta16, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1300, 490, 60));

        Herramienta17.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta17.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta17.setText("Atornillador de Impacto Inalámbrico");
        jPanel7.add(Herramienta17, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1380, 490, 60));

        Herramienta18.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Herramienta18.setForeground(new java.awt.Color(0, 74, 173));
        Herramienta18.setText("Lijadora roto orbital Stanley");
        jPanel7.add(Herramienta18, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 1460, 490, 60));

        Recurso5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel7.add(Recurso5, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 290, -1, -1));

        CostoPU3.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU3.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU3.setText("Costo P/U");
        jPanel7.add(CostoPU3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 20, 170, 60));

        CostoH1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH1.setForeground(new java.awt.Color(0, 74, 173));
        CostoH1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH1.setText("5.16$");
        jPanel7.add(CostoH1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 100, 210, 60));

        CostoH2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH2.setForeground(new java.awt.Color(0, 74, 173));
        CostoH2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH2.setText("22.39$");
        jPanel7.add(CostoH2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, 210, 60));

        CostoH3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH3.setForeground(new java.awt.Color(0, 74, 173));
        CostoH3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH3.setText("4.59$");
        jPanel7.add(CostoH3, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 260, 210, 60));

        CostoH4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH4.setForeground(new java.awt.Color(0, 74, 173));
        CostoH4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH4.setText("14.36$");
        jPanel7.add(CostoH4, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 340, 210, 60));

        CostoH5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH5.setForeground(new java.awt.Color(0, 74, 173));
        CostoH5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH5.setText("2.16$");
        jPanel7.add(CostoH5, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 420, 210, 60));

        CostoH6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH6.setForeground(new java.awt.Color(0, 74, 173));
        CostoH6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH6.setText("5.70$");
        jPanel7.add(CostoH6, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 500, 210, 60));

        CostoH7.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH7.setForeground(new java.awt.Color(0, 74, 173));
        CostoH7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH7.setText("6.36$");
        jPanel7.add(CostoH7, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 580, 210, 60));

        CostoH8.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH8.setForeground(new java.awt.Color(0, 74, 173));
        CostoH8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH8.setText("6.60$");
        jPanel7.add(CostoH8, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 660, 210, 60));

        CostoH9.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH9.setForeground(new java.awt.Color(0, 74, 173));
        CostoH9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH9.setText("8.00$");
        jPanel7.add(CostoH9, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 740, 210, 60));

        CostoH10.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH10.setForeground(new java.awt.Color(0, 74, 173));
        CostoH10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH10.setText("0.69$");
        jPanel7.add(CostoH10, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 820, 210, 60));

        CostoH11.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH11.setForeground(new java.awt.Color(0, 74, 173));
        CostoH11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH11.setText("38.94$");
        jPanel7.add(CostoH11, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 900, 210, 60));

        CostoH12.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH12.setForeground(new java.awt.Color(0, 74, 173));
        CostoH12.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH12.setText("32.25");
        jPanel7.add(CostoH12, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 980, 210, 60));

        CostoH13.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH13.setForeground(new java.awt.Color(0, 74, 173));
        CostoH13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH13.setText("5.99$");
        jPanel7.add(CostoH13, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1060, 210, 60));

        CostoH14.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH14.setForeground(new java.awt.Color(0, 74, 173));
        CostoH14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH14.setText("75.01$");
        jPanel7.add(CostoH14, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1140, 210, 60));

        CostoH15.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH15.setForeground(new java.awt.Color(0, 74, 173));
        CostoH15.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH15.setText("339.86$");
        jPanel7.add(CostoH15, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1220, 210, 60));

        CostoH16.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH16.setForeground(new java.awt.Color(0, 74, 173));
        CostoH16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH16.setText("115.19$");
        jPanel7.add(CostoH16, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1300, 210, 60));

        CostoH17.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH17.setForeground(new java.awt.Color(0, 74, 173));
        CostoH17.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH17.setText("101.46$");
        jPanel7.add(CostoH17, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1380, 210, 60));

        CostoH18.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoH18.setForeground(new java.awt.Color(0, 74, 173));
        CostoH18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoH18.setText("58.64$");
        jPanel7.add(CostoH18, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 1460, 210, 60));

        Atras3B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras3B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras3BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras3BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras3BMouseExited(evt);
            }
        });
        jPanel7.add(Atras3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 1530, -1, -1));

        Cantidad3.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad3.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad3.setText("Cantidad");
        jPanel7.add(Cantidad3, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadH1.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 110, 80, 40));

        CantidadH2.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 190, 80, 40));

        CantidadH3.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 80, 40));

        CantidadH4.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH4.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH4, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 350, 80, 40));

        CantidadH5.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH5.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH5, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 430, 80, 40));

        CantidadH6.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH6.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 510, 80, 40));

        CantidadH7.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH7.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH7, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 590, 80, 40));

        CantidadH8.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH8.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH8, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 670, 80, 40));

        CantidadH9.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH9.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH9, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 750, 80, 40));

        CantidadH10.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH10.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH10, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 830, 80, 40));

        CantidadH11.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH11.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH11, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 910, 80, 40));

        CantidadH12.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH12.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH12, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 990, 80, 40));

        CantidadH13.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH13.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH13, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1070, 80, 40));

        CantidadH14.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH14.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH14, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1150, 80, 40));

        CantidadH15.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH15.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH15, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1230, 80, 40));

        CantidadH16.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH16.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH16, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1310, 80, 40));

        CantidadH17.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH17.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH17, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1390, 80, 40));

        CantidadH18.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadH18.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel7.add(CantidadH18, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 1470, 80, 40));

        Herramienta1B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta1BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 20, 20));

        Herramienta2B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta2BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 20, 20));

        Herramienta3B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta3BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 280, 20, -1));

        Herramienta4B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta4BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 360, 20, 20));

        Herramienta5B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta5B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta5BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 440, 20, 20));

        Herramienta6B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta6B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta6BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta6B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 520, 20, -1));

        Herramienta7B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta7B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta7BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta7B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 600, 20, -1));

        Herramienta8B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta8B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta8BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta8B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 680, 20, -1));

        Herramienta9B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta9B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta9BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta9B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 760, 20, 20));

        Herramienta10B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta10B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta10BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta10B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 840, 20, 20));

        Herramienta11B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta11B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta11BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta11B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 920, 20, 20));

        Herramienta12B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta12B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta12BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta12B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1000, 20, 20));

        Herramienta13B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta13B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta13BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta13B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1080, 20, 20));

        Herramienta14B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta14B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta14BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta14B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1160, 20, -1));

        Herramienta15B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta15B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta15BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta15B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1240, 20, 20));

        Herramienta16B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta16B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta16BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta16B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1320, 20, 20));

        Herramienta17B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta17B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta17BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta17B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1400, 20, 20));

        Herramienta18B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Herramienta18B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Herramienta18BActionPerformed(evt);
            }
        });
        jPanel7.add(Herramienta18B, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 1480, 20, 20));

        jPanel6.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 1620));

        SubVentanaH.setViewportView(jPanel6);

        TiposMateriales.addTab("Estructura", SubVentanaH);

        SubVentanaD.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaD.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel9.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Materiales4.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales4.setForeground(new java.awt.Color(0, 74, 173));
        Materiales4.setText("MATERIALES");
        jPanel9.add(Materiales4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        Decoracion1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion1.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion1.setText("Cola plástica Adheplast de 1 galón");
        jPanel9.add(Decoracion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 100, 410, 60));

        Decoracion2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion2.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion2.setText("Masilla P/Madera 4Oz");
        jPanel9.add(Decoracion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 260, 390, 60));

        Decoracion3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion3.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion3.setText("Barniz tropical para exteriores galón wesco");
        jPanel9.add(Decoracion3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 470, 60));

        Decoracion6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion6.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion6.setText("Silicona adhesiva de acrílico pantalla multiusos");
        jPanel9.add(Decoracion6, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 510, 60));

        CostoPU4.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU4.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU4.setText("Costo P/U");
        jPanel9.add(CostoPU4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 170, 60));

        CostoD1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD1.setForeground(new java.awt.Color(0, 74, 173));
        CostoD1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD1.setText("8.65$");
        jPanel9.add(CostoD1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 100, 210, 60));

        CostoD2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD2.setForeground(new java.awt.Color(0, 74, 173));
        CostoD2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD2.setText("35.93$");
        jPanel9.add(CostoD2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 180, 210, 60));

        CostoD3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD3.setForeground(new java.awt.Color(0, 74, 173));
        CostoD3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD3.setText("6.11$");
        jPanel9.add(CostoD3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 260, 210, 60));

        CostoD6.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD6.setForeground(new java.awt.Color(0, 74, 173));
        CostoD6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD6.setText("2.35$");
        jPanel9.add(CostoD6, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 340, 210, 60));

        Cantidad4.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad4.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad4.setText("Cantidad");
        jPanel9.add(Cantidad4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadD1.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel9.add(CantidadD1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 110, 80, 40));

        CantidadD2.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel9.add(CantidadD2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 190, 80, 40));

        CantidadD3.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel9.add(CantidadD3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 270, 80, 40));

        CantidadD6.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD6.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel9.add(CantidadD6, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 350, 80, 40));

        Atras4B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras4B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras4B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras4BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras4BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras4BMouseExited(evt);
            }
        });
        jPanel9.add(Atras4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 410, -1, -1));

        Recurso6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel9.add(Recurso6, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 260, -1, -1));

        Decoracion1B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion1BActionPerformed(evt);
            }
        });
        jPanel9.add(Decoracion1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 120, 20, 20));

        Decoracion2B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion2BActionPerformed(evt);
            }
        });
        jPanel9.add(Decoracion2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 20, 20));

        Decoracion3B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion3BActionPerformed(evt);
            }
        });
        jPanel9.add(Decoracion3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, 20, 20));

        Decoracion6B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion6B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion6BActionPerformed(evt);
            }
        });
        jPanel9.add(Decoracion6B, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 360, 20, 20));

        SustentablesD.setFont(new java.awt.Font("Garet Book", 1, 12)); // NOI18N
        SustentablesD.setForeground(new java.awt.Color(0, 74, 173));
        SustentablesD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        SustentablesD.setText("ir a sustentables");
        SustentablesD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SustentablesDMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SustentablesDMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SustentablesDMouseExited(evt);
            }
        });
        jPanel9.add(SustentablesD, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 140, 30));

        jPanel8.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 500));

        SubVentanaD.setViewportView(jPanel8);

        TiposMateriales.addTab("Ensamblaje", SubVentanaD);

        SubVentanaD_S.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaD_S.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel15.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Materiales7.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales7.setForeground(new java.awt.Color(0, 74, 173));
        Materiales7.setText("MATERIALES");
        jPanel15.add(Materiales7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        Decoracion4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion4.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion4.setText("Pintura a base de agua ");
        jPanel15.add(Decoracion4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 440, 60));

        Decoracion5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Decoracion5.setForeground(new java.awt.Color(0, 74, 173));
        Decoracion5.setText("Acrílico reciclado");
        jPanel15.add(Decoracion5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 440, 60));

        CostoPU7.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU7.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU7.setText("Costo P/U");
        jPanel15.add(CostoPU7, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 170, 60));

        CostoD4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD4.setForeground(new java.awt.Color(0, 74, 173));
        CostoD4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD4.setText("4,65$");
        jPanel15.add(CostoD4, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 120, 210, 60));

        CostoD5.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoD5.setForeground(new java.awt.Color(0, 74, 173));
        CostoD5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoD5.setText("27.37$");
        jPanel15.add(CostoD5, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 200, 210, 60));

        Cantidad7.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad7.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad7.setText("Cantidad");
        jPanel15.add(Cantidad7, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadD4.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD4.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel15.add(CantidadD4, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 130, 80, 40));

        CantidadD5.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadD5.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel15.add(CantidadD5, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 210, 80, 40));

        Atras41B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras41B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras41B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras41BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras41BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras41BMouseExited(evt);
            }
        });
        jPanel15.add(Atras41B, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, -1, -1));

        Recurso9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel15.add(Recurso9, new org.netbeans.lib.awtextra.AbsoluteConstraints(900, 260, -1, -1));

        NoSustentablesD.setFont(new java.awt.Font("Garet Book", 1, 12)); // NOI18N
        NoSustentablesD.setForeground(new java.awt.Color(0, 74, 173));
        NoSustentablesD.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        NoSustentablesD.setText("ir a no sustentables");
        NoSustentablesD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                NoSustentablesDMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                NoSustentablesDMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                NoSustentablesDMouseExited(evt);
            }
        });
        jPanel15.add(NoSustentablesD, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 70, 140, 30));

        Decoracion4B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion4BActionPerformed(evt);
            }
        });
        jPanel15.add(Decoracion4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, 20, 20));

        Decoracion5B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Decoracion5B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Decoracion5BActionPerformed(evt);
            }
        });
        jPanel15.add(Decoracion5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 20, 20));

        jPanel14.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 500));

        SubVentanaD_S.setViewportView(jPanel14);

        TiposMateriales.addTab("Ensamblaje", SubVentanaD_S);

        SubVentanaP.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        SubVentanaP.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setMinimumSize(new java.awt.Dimension(1140, 840));
        jPanel11.setPreferredSize(new java.awt.Dimension(1140, 840));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Materiales5.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Materiales5.setForeground(new java.awt.Color(0, 74, 173));
        Materiales5.setText("MATERIALES");
        jPanel11.add(Materiales5, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 20, 170, 60));

        Proteccion1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Proteccion1.setForeground(new java.awt.Color(0, 74, 173));
        Proteccion1.setText("Guante de Kevlar resistente al corte");
        jPanel11.add(Proteccion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 410, 60));

        Proteccion2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Proteccion2.setForeground(new java.awt.Color(0, 74, 173));
        Proteccion2.setText("Máscara Media Cara Delta Plus");
        jPanel11.add(Proteccion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 230, 390, 60));

        Proteccion3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Proteccion3.setForeground(new java.awt.Color(0, 74, 173));
        Proteccion3.setText("Gafa de seguridad");
        jPanel11.add(Proteccion3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, 470, 60));

        Proteccion4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        Proteccion4.setForeground(new java.awt.Color(0, 74, 173));
        Proteccion4.setText("Orejeras Interlagos2 Delta Plus");
        jPanel11.add(Proteccion4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 310, 440, 60));

        CostoPU5.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        CostoPU5.setForeground(new java.awt.Color(0, 74, 173));
        CostoPU5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoPU5.setText("Costo P/U");
        jPanel11.add(CostoPU5, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 170, 60));

        CostoP1.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoP1.setForeground(new java.awt.Color(0, 74, 173));
        CostoP1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoP1.setText("15.41$");
        jPanel11.add(CostoP1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 70, 210, 60));

        CostoP2.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoP2.setForeground(new java.awt.Color(0, 74, 173));
        CostoP2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoP2.setText("6.45$");
        jPanel11.add(CostoP2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 150, 210, 60));

        CostoP3.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoP3.setForeground(new java.awt.Color(0, 74, 173));
        CostoP3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoP3.setText("10.99$");
        jPanel11.add(CostoP3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 230, 210, 60));

        CostoP4.setFont(new java.awt.Font("Questrial", 0, 24)); // NOI18N
        CostoP4.setForeground(new java.awt.Color(0, 74, 173));
        CostoP4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        CostoP4.setText("26.50$");
        jPanel11.add(CostoP4, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 310, 210, 60));

        Cantidad5.setFont(new java.awt.Font("Garet Heavy", 0, 24)); // NOI18N
        Cantidad5.setForeground(new java.awt.Color(0, 74, 173));
        Cantidad5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Cantidad5.setText("Cantidad");
        jPanel11.add(Cantidad5, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 170, 60));

        CantidadP1.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadP1.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel11.add(CantidadP1, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 80, 80, 40));

        CantidadP2.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadP2.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel11.add(CantidadP2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 160, 80, 40));

        CantidadP3.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadP3.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel11.add(CantidadP3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 240, 80, 40));

        CantidadP4.setFont(new java.awt.Font("Garet Heavy", 0, 12)); // NOI18N
        CantidadP4.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanel11.add(CantidadP4, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 320, 80, 40));

        Atras5B.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Atras.png"))); // NOI18N
        Atras5B.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Atras5B.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Atras5BMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Atras5BMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Atras5BMouseExited(evt);
            }
        });
        jPanel11.add(Atras5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 410, -1, -1));

        Recurso7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        jPanel11.add(Recurso7, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 100, -1, -1));

        Proteccion1B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Proteccion1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Proteccion1BActionPerformed(evt);
            }
        });
        jPanel11.add(Proteccion1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 20, 20));

        Proteccion2B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Proteccion2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Proteccion2BActionPerformed(evt);
            }
        });
        jPanel11.add(Proteccion2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 170, 20, 20));

        Proteccion3B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Proteccion3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Proteccion3BActionPerformed(evt);
            }
        });
        jPanel11.add(Proteccion3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 20, 20));

        Proteccion4B.setText("        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB); ");
        Proteccion4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Proteccion4BActionPerformed(evt);
            }
        });
        jPanel11.add(Proteccion4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 330, 20, -1));

        jPanel10.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1090, 504));

        SubVentanaP.setViewportView(jPanel10);

        TiposMateriales.addTab("Ensamblaje", SubVentanaP);

        Resumen_materiales.setBackground(new java.awt.Color(255, 255, 255));
        Resumen_materiales.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        Tablamateriales.setBackground(new java.awt.Color(240, 246, 250));
        Tablamateriales.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Tablamateriales.setFont(new java.awt.Font("Garet Book", 0, 14)); // NOI18N
        Tablamateriales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Material", "Rubro", "Cantidad", "Costo P/U", "Costo Total"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        Tablamateriales.setGridColor(new java.awt.Color(163, 211, 240));
        Tablamateriales.setRowHeight(25);
        Tablamateriales.setShowGrid(false);
        Tablamateriales.setShowHorizontalLines(true);
        jScrollPane1.setViewportView(Tablamateriales);

        Resumen_materiales.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 920, 300));

        HechoB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/boton_hecho_1.png"))); // NOI18N
        HechoB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        HechoB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                HechoBMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                HechoBMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                HechoBMouseExited(evt);
            }
        });
        Resumen_materiales.add(HechoB, new org.netbeans.lib.awtextra.AbsoluteConstraints(830, 420, -1, -1));

        EditarB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/boton_editar_1.png"))); // NOI18N
        EditarB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EditarB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                EditarBMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                EditarBMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                EditarBMouseExited(evt);
            }
        });
        Resumen_materiales.add(EditarB, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, -1, 70));

        ResumenMateriales.setFont(new java.awt.Font("Garet Heavy", 0, 40)); // NOI18N
        ResumenMateriales.setForeground(new java.awt.Color(145, 209, 248));
        ResumenMateriales.setText("Resumen de Materiales");
        Resumen_materiales.add(ResumenMateriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, -1, -1));

        CostoFinal.setFont(new java.awt.Font("Garet Book", 0, 30)); // NOI18N
        CostoFinal.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Resumen_materiales.add(CostoFinal, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 430, 540, 50));

        TiposMateriales.addTab("tab7", Resumen_materiales);

        getContentPane().add(TiposMateriales, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 100, 1100, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
// - - - - - - - - Metodos de la ventana de tipos de material - - - - - - - - 
  
    
    private void estructura_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_estructura_label_btnMouseEntered
        estructura_label_btn.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_estructura_label_btnMouseEntered

    private void estructura_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_estructura_label_btnMouseExited
        estructura_label_btn.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_estructura_label_btnMouseExited

    private void estructura_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_estructura_label_btnMouseClicked
        TiposMateriales.setSelectedIndex(1);
    }//GEN-LAST:event_estructura_label_btnMouseClicked

    private void ensamblaje_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ensamblaje_label_btnMouseEntered
        ensamblaje_label_btn.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_ensamblaje_label_btnMouseEntered

    private void ensamblaje_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ensamblaje_label_btnMouseExited
        ensamblaje_label_btn.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_ensamblaje_label_btnMouseExited

    private void ensamblaje_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ensamblaje_label_btnMouseClicked
        TiposMateriales.setSelectedIndex(3);
    }//GEN-LAST:event_ensamblaje_label_btnMouseClicked

    private void herramientas_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_herramientas_label_btnMouseEntered
        herramientas_label_btn.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_herramientas_label_btnMouseEntered

    private void herramientas_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_herramientas_label_btnMouseExited
        herramientas_label_btn.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_herramientas_label_btnMouseExited

    private void herramientas_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_herramientas_label_btnMouseClicked
        TiposMateriales.setSelectedIndex(4);
    }//GEN-LAST:event_herramientas_label_btnMouseClicked

    private void decoracion_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decoracion_label_btnMouseEntered
        decoracion_label_btn.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_decoracion_label_btnMouseEntered

    private void decoracion_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decoracion_label_btnMouseExited
        decoracion_label_btn.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_decoracion_label_btnMouseExited

    private void decoracion_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_decoracion_label_btnMouseClicked
        TiposMateriales.setSelectedIndex(5);
    }//GEN-LAST:event_decoracion_label_btnMouseClicked

    private void proteccion_label_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proteccion_label_btnMouseEntered
        proteccion_label_btn.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_proteccion_label_btnMouseEntered

    private void proteccion_label_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proteccion_label_btnMouseExited
        proteccion_label_btn.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_proteccion_label_btnMouseExited

    private void proteccion_label_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proteccion_label_btnMouseClicked
        TiposMateriales.setSelectedIndex(7);
    }//GEN-LAST:event_proteccion_label_btnMouseClicked
    
    private void FinalizarBMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FinalizarBMouseEntered
        if(FinalizarB.isEnabled()){
            FinalizarB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_finalizar_claro_1.png"));
        }
    }//GEN-LAST:event_FinalizarBMouseEntered

    private void FinalizarBMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FinalizarBMouseExited
        FinalizarB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_finalizar_1.png"));
    }//GEN-LAST:event_FinalizarBMouseExited

    private void Salir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseClicked
        UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 18));
        UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 18));
        int confirmacion = JOptionPane.showOptionDialog(
            null, "¿Desea descartar el progreso de Compra?", "Confirmación",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, new ImageIcon("src/images/ventanaComprar/Aviso2_icono.png"), opciones, opciones[0]);
        if (confirmacion == 0){
            VentanaComprar1 ventana = new VentanaComprar1(usuarioActual);
            ventana.usuarioActual = usuarioActual;
            control.activaVentana(ventana, this);
        }
    }//GEN-LAST:event_Salir1MouseClicked

    private void Salir1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseEntered
        Salir1.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Salir1MouseEntered

    private void Salir1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseExited
        Salir1.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Salir1MouseExited
    
    private void FinalizarBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FinalizarBMouseClicked
        if (FinalizarB.isEnabled()){
            TiposMateriales.setSelectedIndex(8);
        
            control.chequear_Spinners(Estructura1B, CantidadE1, materiales, "Pingos de Eucalipto", "Estructura", 7.50,nombre);
            control.chequear_Spinners(Estructura2B, CantidadE2, materiales, "Madera reciclada de pino", "Estructura", 10,nombre);
            control.chequear_Spinners(Estructura3B, CantidadE3, materiales, "Bambu Culmos", "Estructura", 6.51,nombre);
            control.chequear_Spinners(Estructura4B, CantidadE4, materiales, "Carton reciclado", "Estructura", 0.10,nombre);
            control.chequear_Spinners(Estructura5B, CantidadE5, materiales, "Palets 100 x 120 fuerte abierto reciclado", "Estructura", 5.77,nombre);
            control.chequear_Spinners(Estructura6B, CantidadE6, materiales, "Planchas De Carton Corrugado Kraft", "Estructura", 1.75,nombre);
            control.chequear_Spinners(Estructura7B, CantidadE7, materiales, "Paneles de latilla de bambú", "Estructura", 8.87,nombre);
            control.chequear_Spinners(Estructura8B, CantidadE8, materiales, "Plancha de PVC", "Estructura", 11.34,nombre);
            control.chequear_Spinners(Estructura9B, CantidadE9, materiales, "Tubo PP Roscable", "Estructura", 11.85,nombre);

            control.chequear_Spinners(Ensamblaje1B, CantidadEn1, materiales, "Clavos de libra funda", "Ensamblaje", 60.34,nombre);
            control.chequear_Spinners(Ensamblaje2B, CantidadEn2, materiales, "Perno A325 1/2\"x1-1/2\" C/T + Arandela", "Ensamblaje", 0.83,nombre);
            control.chequear_Spinners(Ensamblaje3B, CantidadEn3, materiales, "Tornillo Madera 1 1/2x8 RG", "Ensamblaje", 0.03,nombre);
            control.chequear_Spinners(Ensamblaje4B, CantidadEn4, materiales, "Cajetín rectangular \"Plastigama\" plástico", "Ensamblaje", 1.03,nombre);
            control.chequear_Spinners(Ensamblaje5B, CantidadEn5, materiales, "Cable Sólido THHN #12 AWG 100 m", "Ensamblaje", 71.30,nombre);
            control.chequear_Spinners(Ensamblaje6B, CantidadEn6, materiales, "Tomacorriente Doble Amer 2P+E Blitz", "Ensamblaje", 1.89,nombre);
            control.chequear_Spinners(Ensamblaje7B, CantidadEn7, materiales, "Interruptor Simple 10A Negro Aqua L100044", "Ensamblaje", 2.69,nombre);

            control.chequear_Spinners(Herramienta1B, CantidadH1, materiales, "Martillo metálico de 29mm", "Herramienta", 5.16,nombre);
            control.chequear_Spinners(Herramienta2B, CantidadH2, materiales, "Carretilla con llanta inflable", "Herramienta", 22.39,nombre);
            control.chequear_Spinners(Herramienta3B, CantidadH3, materiales, "Arco Sierra Elite 24\"", "Herramienta", 4.59,nombre);
            control.chequear_Spinners(Herramienta4B, CantidadH4, materiales, "Juegos de destornilladores WorkPro", "Herramienta", 14.36,nombre);
            control.chequear_Spinners(Herramienta5B, CantidadH5, materiales, "Cinta métrica Stanley", "Herramienta", 2.16,nombre);
            control.chequear_Spinners(Herramienta6B, CantidadH6, materiales, "Nivel resina estructural Stanley", "Herramienta", 5.70,nombre);
            control.chequear_Spinners(Herramienta7B, CantidadH7, materiales, "Alicate Universal Stanley", "Herramienta", 6.36,nombre);
            control.chequear_Spinners(Herramienta8B, CantidadH8, materiales, "Serrucho Luctador Stanley", "Herramienta", 6.60,nombre);
            control.chequear_Spinners(Herramienta9B, CantidadH9, materiales, "Escuadra 12\" para carpintero", "Herramienta", 8,nombre);
            control.chequear_Spinners(Herramienta10B, CantidadH10, materiales, "Lápiz Para Carpintero Stanley", "Herramienta", 0.69,nombre);
            control.chequear_Spinners(Herramienta11B, CantidadH11, materiales, "Set llaves mixtas rachet 8PCS", "Herramienta", 38.94,nombre);
            control.chequear_Spinners(Herramienta12B, CantidadH12, materiales, "Prensa sargento 157 5 pies", "Herramienta", 32.25,nombre);
            control.chequear_Spinners(Herramienta13B, CantidadH13, materiales, "Paquete variado de papel de lija", "Herramienta", 5.99,nombre);
            control.chequear_Spinners(Herramienta14B, CantidadH14, materiales, "Taladro de Rotación de 3/8\" Dewalt", "Herramienta", 75.01,nombre);
            control.chequear_Spinners(Herramienta15B, CantidadH15, materiales, "Sierra Ingleteadora de 10\" 15A Dewalt", "Herramienta", 339.86,nombre);
            control.chequear_Spinners(Herramienta16B, CantidadH16, materiales, "Sierra Circular 7 1/4\" Stanley", "Herramienta", 115.19,nombre);
            control.chequear_Spinners(Herramienta17B, CantidadH17, materiales, "Atornillador de Impacto Inalámbrico", "Herramienta", 101.46,nombre);
            control.chequear_Spinners(Herramienta18B, CantidadH18, materiales, "Lijadora roto orbital Stanley", "Herramienta", 58.64,nombre);

            control.chequear_Spinners(Decoracion1B, CantidadD1, materiales, "Cola plástica Adheplast de 1 galón", "Decoración", 8.65,nombre);
            control.chequear_Spinners(Decoracion2B, CantidadD2, materiales, "Barniz tropical para exteriores galón wesco", "Decoración", 35.93,nombre);
            control.chequear_Spinners(Decoracion3B, CantidadD3, materiales, "Masilla P/Madera 4Oz", "Decoración", 6.11,nombre);
            control.chequear_Spinners(Decoracion4B, CantidadD4, materiales, "Pintura a base de agua ", "Decoración", 4.65,nombre);
            control.chequear_Spinners(Decoracion5B, CantidadD5, materiales, "Acrílico reciclado", "Decoración", 27.37,nombre);
            control.chequear_Spinners(Decoracion6B, CantidadD6, materiales, "Silicona adhesiva de acrílico pantalla multiusos", "Decoración", 2.35,nombre);

            control.chequear_Spinners(Proteccion1B, CantidadP1, materiales, "Guante de Kevlar resistente al corte", "Protección", 15.41,nombre);
            control.chequear_Spinners(Proteccion2B, CantidadP2, materiales, "Gafa de seguridad", "Protección", 6.45,nombre);
            control.chequear_Spinners(Proteccion3B, CantidadP3, materiales, "Máscara Media Cara Delta Plus", "Protección", 10.99,nombre);
            control.chequear_Spinners(Proteccion4B, CantidadP4, materiales, "Orejeras Interlagos2 Delta Plus", "Protección", 26.50,nombre);

            control.llenar_tabla_materiales(Tablamateriales, materiales);
            CostoFinal.setText("Costo Final: "+control.costo_Final(materiales)+"$");
        }
        
        
    }//GEN-LAST:event_FinalizarBMouseClicked

    private void HechoBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HechoBMouseClicked
        Diseño diseñoNuevo = diseñoActual;
        diseñoNuevo.setTerminado("1");
        String costo = control.costo_Final(materiales);
        diseñoNuevo.setCostoTotal(costo);
        control.actualizarDiseño(datosDise, diseñoNuevo, nombre);
        Material materialNuevo = new Material();
        
        for (int i=0; i<materiales.size();i++) {
            materialNuevo = materiales.get(i);
            materialNuevo.setDiseno(nombre);
            control.guardarMaterial(datosMat, materialNuevo);
        }
        
        VentanaPrincipal ventana = new VentanaPrincipal(usuarioActual); //que se pase usuario actual
        control.activaVentana(ventana,this);
    }//GEN-LAST:event_HechoBMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de estructura (Sustentables)  - - - - - - - - 

    
    private void Estructura1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura1BActionPerformed
        control.super_Spinners(Estructura1B, CantidadE1, FinalizarB);
    }//GEN-LAST:event_Estructura1BActionPerformed

    private void Estructura2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura2BActionPerformed
        control.super_Spinners(Estructura2B, CantidadE2, FinalizarB);
    }//GEN-LAST:event_Estructura2BActionPerformed

    private void Estructura3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura3BActionPerformed
        control.super_Spinners(Estructura3B, CantidadE3, FinalizarB);
    }//GEN-LAST:event_Estructura3BActionPerformed

    private void Estructura4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura4BActionPerformed
        control.super_Spinners(Estructura4B, CantidadE4, FinalizarB);
    }//GEN-LAST:event_Estructura4BActionPerformed

    private void Estructura5BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura5BActionPerformed
        control.super_Spinners(Estructura5B, CantidadE5, FinalizarB);
    }//GEN-LAST:event_Estructura5BActionPerformed

    private void Estructura6BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura6BActionPerformed
        control.super_Spinners(Estructura6B, CantidadE6, FinalizarB);
    }//GEN-LAST:event_Estructura6BActionPerformed

    private void Estructura7BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura7BActionPerformed
        control.super_Spinners(Estructura7B, CantidadE7, FinalizarB);
    }//GEN-LAST:event_Estructura7BActionPerformed

    private void Atras1BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras1BMouseEntered
        Atras1B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras1BMouseEntered

    private void Atras1BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras1BMouseExited
        Atras1B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras1BMouseExited

    private void Atras1BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras1BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras1BMouseClicked

    private void NoSustentablesEMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesEMouseEntered
        NoSustentablesE.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_NoSustentablesEMouseEntered

    private void NoSustentablesEMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesEMouseExited
        NoSustentablesE.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_NoSustentablesEMouseExited

    private void NoSustentablesEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesEMouseClicked
        TiposMateriales.setSelectedIndex(1);
    }//GEN-LAST:event_NoSustentablesEMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de estructura (No Sustentables)  - - - - - - - - 

    
    private void Estructura8BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura8BActionPerformed
        control.super_Spinners(Estructura8B, CantidadE8, FinalizarB);
    }//GEN-LAST:event_Estructura8BActionPerformed

    private void Estructura9BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Estructura9BActionPerformed
        control.super_Spinners(Estructura9B, CantidadE9, FinalizarB);
    }//GEN-LAST:event_Estructura9BActionPerformed

    private void Atras12BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras12BMouseEntered
        Atras1B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras12BMouseEntered

    private void Atras12BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras12BMouseExited
        Atras1B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras12BMouseExited

    private void Atras12BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras12BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras12BMouseClicked

    private void SustentablesEMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesEMouseEntered
        SustentablesE.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_SustentablesEMouseEntered

    private void SustentablesEMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesEMouseExited
        SustentablesE.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_SustentablesEMouseExited

    private void SustentablesEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesEMouseClicked
        TiposMateriales.setSelectedIndex(2);
    }//GEN-LAST:event_SustentablesEMouseClicked

 
    // - - - - - - - - Metodos de la subventana de materiales de ensamblaje - - - - - - - - 

    
    private void Ensamblaje1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje1BActionPerformed
        control.super_Spinners(Ensamblaje1B, CantidadEn1, FinalizarB);
    }//GEN-LAST:event_Ensamblaje1BActionPerformed

    private void Ensamblaje2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje2BActionPerformed
        control.super_Spinners(Ensamblaje2B, CantidadEn2, FinalizarB);
    }//GEN-LAST:event_Ensamblaje2BActionPerformed

    private void Ensamblaje3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje3BActionPerformed
        control.super_Spinners(Ensamblaje3B, CantidadEn3, FinalizarB);
    }//GEN-LAST:event_Ensamblaje3BActionPerformed

    private void Ensamblaje4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje4BActionPerformed
        control.super_Spinners(Ensamblaje4B, CantidadEn4, FinalizarB);
    }//GEN-LAST:event_Ensamblaje4BActionPerformed

    private void Ensamblaje5BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje5BActionPerformed
        control.super_Spinners(Ensamblaje5B, CantidadEn5, FinalizarB);
    }//GEN-LAST:event_Ensamblaje5BActionPerformed

    private void Ensamblaje6BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje6BActionPerformed
        control.super_Spinners(Ensamblaje6B, CantidadEn6, FinalizarB);
    }//GEN-LAST:event_Ensamblaje6BActionPerformed

    private void Ensamblaje7BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Ensamblaje7BActionPerformed
        control.super_Spinners(Ensamblaje7B, CantidadEn7, FinalizarB);
    }//GEN-LAST:event_Ensamblaje7BActionPerformed

    private void Atras2BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras2BMouseEntered
        Atras2B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras2BMouseEntered

    private void Atras2BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras2BMouseExited
        Atras2B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras2BMouseExited

    private void Atras2BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras2BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras2BMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de Herramientas - - - - - - - - 
    
    
    private void Herramienta1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta1BActionPerformed
        control.super_Spinners(Herramienta1B, CantidadH1, FinalizarB);
    }//GEN-LAST:event_Herramienta1BActionPerformed

    private void Herramienta2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta2BActionPerformed
        control.super_Spinners(Herramienta2B, CantidadH2, FinalizarB);
    }//GEN-LAST:event_Herramienta2BActionPerformed

    private void Herramienta3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta3BActionPerformed
        control.super_Spinners(Herramienta3B, CantidadH3, FinalizarB);
    }//GEN-LAST:event_Herramienta3BActionPerformed

    private void Herramienta4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta4BActionPerformed
        control.super_Spinners(Herramienta4B, CantidadH4, FinalizarB);
    }//GEN-LAST:event_Herramienta4BActionPerformed

    private void Herramienta5BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta5BActionPerformed
        control.super_Spinners(Herramienta5B, CantidadH5, FinalizarB);
    }//GEN-LAST:event_Herramienta5BActionPerformed

    private void Herramienta6BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta6BActionPerformed
        control.super_Spinners(Herramienta6B, CantidadH6, FinalizarB);
    }//GEN-LAST:event_Herramienta6BActionPerformed

    private void Herramienta7BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta7BActionPerformed
        control.super_Spinners(Herramienta7B, CantidadH7, FinalizarB);
    }//GEN-LAST:event_Herramienta7BActionPerformed

    private void Herramienta8BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta8BActionPerformed
        control.super_Spinners(Herramienta8B, CantidadH8, FinalizarB);
    }//GEN-LAST:event_Herramienta8BActionPerformed

    private void Herramienta9BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta9BActionPerformed
        control.super_Spinners(Herramienta9B, CantidadH9, FinalizarB);
    }//GEN-LAST:event_Herramienta9BActionPerformed

    private void Herramienta10BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta10BActionPerformed
        control.super_Spinners(Herramienta10B, CantidadH10, FinalizarB);
    }//GEN-LAST:event_Herramienta10BActionPerformed

    private void Herramienta11BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta11BActionPerformed
        control.super_Spinners(Herramienta11B, CantidadH11, FinalizarB);
    }//GEN-LAST:event_Herramienta11BActionPerformed

    private void Herramienta12BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta12BActionPerformed
        control.super_Spinners(Herramienta12B, CantidadH12, FinalizarB);
    }//GEN-LAST:event_Herramienta12BActionPerformed

    private void Herramienta13BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta13BActionPerformed
        control.super_Spinners(Herramienta13B, CantidadH13, FinalizarB);
    }//GEN-LAST:event_Herramienta13BActionPerformed

    private void Herramienta14BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta14BActionPerformed
        control.super_Spinners(Herramienta14B, CantidadH14, FinalizarB);
    }//GEN-LAST:event_Herramienta14BActionPerformed

    private void Herramienta15BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta15BActionPerformed
        control.super_Spinners(Herramienta15B, CantidadH15, FinalizarB);
    }//GEN-LAST:event_Herramienta15BActionPerformed

    private void Herramienta16BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta16BActionPerformed
        control.super_Spinners(Herramienta16B, CantidadH16, FinalizarB);
    }//GEN-LAST:event_Herramienta16BActionPerformed

    private void Herramienta17BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta17BActionPerformed
        control.super_Spinners(Herramienta17B, CantidadH17, FinalizarB);
    }//GEN-LAST:event_Herramienta17BActionPerformed

    private void Herramienta18BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Herramienta18BActionPerformed
        control.super_Spinners(Herramienta18B, CantidadH18, FinalizarB);
    }//GEN-LAST:event_Herramienta18BActionPerformed

    private void Atras3BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras3BMouseEntered
        Atras3B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras3BMouseEntered

    private void Atras3BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras3BMouseExited
        Atras3B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras3BMouseExited

    private void Atras3BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras3BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras3BMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de Decoracion (No Sustentables) - - - - - - - - 
    
    
    private void Decoracion1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion1BActionPerformed
        control.super_Spinners(Decoracion1B, CantidadD1, FinalizarB);
    }//GEN-LAST:event_Decoracion1BActionPerformed

    private void Decoracion2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion2BActionPerformed
        control.super_Spinners(Decoracion2B, CantidadD2, FinalizarB);
    }//GEN-LAST:event_Decoracion2BActionPerformed

    private void Decoracion3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion3BActionPerformed
        control.super_Spinners(Decoracion3B, CantidadD3, FinalizarB);
    }//GEN-LAST:event_Decoracion3BActionPerformed

    private void Decoracion6BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion6BActionPerformed
        control.super_Spinners(Decoracion6B, CantidadD6, FinalizarB);
    }//GEN-LAST:event_Decoracion6BActionPerformed

    private void Atras4BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras4BMouseEntered
        Atras4B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras4BMouseEntered

    private void Atras4BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras4BMouseExited
        Atras4B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras4BMouseExited

    private void Atras4BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras4BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras4BMouseClicked

    private void SustentablesDMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesDMouseEntered
        SustentablesD.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_SustentablesDMouseEntered

    private void SustentablesDMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesDMouseExited
        SustentablesD.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_SustentablesDMouseExited

    private void SustentablesDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SustentablesDMouseClicked
        TiposMateriales.setSelectedIndex(6);
    }//GEN-LAST:event_SustentablesDMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de Decoracion (Sustentables) - - - - - - - - 
    
    
    private void Decoracion4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion4BActionPerformed
        control.super_Spinners(Decoracion4B, CantidadD4, FinalizarB);
    }//GEN-LAST:event_Decoracion4BActionPerformed

    private void Decoracion5BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Decoracion5BActionPerformed
        control.super_Spinners(Decoracion5B, CantidadD5, FinalizarB);
    }//GEN-LAST:event_Decoracion5BActionPerformed

    private void Atras41BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras41BMouseEntered
        Atras41B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras41BMouseEntered

    private void Atras41BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras41BMouseExited
        Atras41B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras41BMouseExited

    private void Atras41BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras41BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras41BMouseClicked

    private void NoSustentablesDMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesDMouseEntered
        NoSustentablesD.setForeground(new Color(0,153,196));
    }//GEN-LAST:event_NoSustentablesDMouseEntered

    private void NoSustentablesDMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesDMouseExited
        NoSustentablesD.setForeground(new Color(0,74,173));
    }//GEN-LAST:event_NoSustentablesDMouseExited

    private void NoSustentablesDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_NoSustentablesDMouseClicked
        TiposMateriales.setSelectedIndex(5);
    }//GEN-LAST:event_NoSustentablesDMouseClicked

    
    // - - - - - - - - Metodos de la subventana de materiales de Proteccion - - - - - - - - 
    
    
    private void Proteccion1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Proteccion1BActionPerformed
        control.super_Spinners(Proteccion1B, CantidadP1, FinalizarB);
    }//GEN-LAST:event_Proteccion1BActionPerformed

    private void Proteccion2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Proteccion2BActionPerformed
        control.super_Spinners(Proteccion2B, CantidadP2, FinalizarB);
    }//GEN-LAST:event_Proteccion2BActionPerformed

    private void Proteccion3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Proteccion3BActionPerformed
        control.super_Spinners(Proteccion3B, CantidadP3, FinalizarB);
    }//GEN-LAST:event_Proteccion3BActionPerformed

    private void Proteccion4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Proteccion4BActionPerformed
        control.super_Spinners(Proteccion4B, CantidadP4, FinalizarB);
    }//GEN-LAST:event_Proteccion4BActionPerformed

    private void Atras5BMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras5BMouseEntered
        Atras5B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras_claro.png"));
    }//GEN-LAST:event_Atras5BMouseEntered

    private void Atras5BMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras5BMouseExited
        Atras5B.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Atras.png"));
    }//GEN-LAST:event_Atras5BMouseExited

    private void Atras5BMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Atras5BMouseClicked
        TiposMateriales.setSelectedIndex(0);
    }//GEN-LAST:event_Atras5BMouseClicked

    
    // - - - - - - - - Metodos de la subventana de resumen de materiales - - - - - - - - 
    
    
    private void EditarBMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditarBMouseEntered
       EditarB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_editar_claro_1.png"));
    }//GEN-LAST:event_EditarBMouseEntered

    private void EditarBMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditarBMouseExited
       EditarB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_editar_1.png")); 
    }//GEN-LAST:event_EditarBMouseExited

    private void EditarBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EditarBMouseClicked
        TiposMateriales.setSelectedIndex(0);
        for (int i = materiales.size()-1; i>-1; i--){
           materiales.remove(i);
        }
    }//GEN-LAST:event_EditarBMouseClicked

    private void HechoBMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HechoBMouseEntered
        HechoB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_hecho_claro_1.png"));
    }//GEN-LAST:event_HechoBMouseEntered

    private void HechoBMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HechoBMouseExited
        HechoB.setIcon(new ImageIcon("src/images/ventanaComprar/boton_hecho_1.png"));
    }//GEN-LAST:event_HechoBMouseExited






    
    
    
    


    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaComprar2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Atras12B;
    private javax.swing.JLabel Atras1B;
    private javax.swing.JLabel Atras2B;
    private javax.swing.JLabel Atras3B;
    private javax.swing.JLabel Atras41B;
    private javax.swing.JLabel Atras4B;
    private javax.swing.JLabel Atras5B;
    private javax.swing.JLabel Cantidad1;
    private javax.swing.JLabel Cantidad2;
    private javax.swing.JLabel Cantidad3;
    private javax.swing.JLabel Cantidad4;
    private javax.swing.JLabel Cantidad5;
    private javax.swing.JLabel Cantidad6;
    private javax.swing.JLabel Cantidad7;
    private javax.swing.JSpinner CantidadD1;
    private javax.swing.JSpinner CantidadD2;
    private javax.swing.JSpinner CantidadD3;
    private javax.swing.JSpinner CantidadD4;
    private javax.swing.JSpinner CantidadD5;
    private javax.swing.JSpinner CantidadD6;
    private javax.swing.JSpinner CantidadE1;
    private javax.swing.JSpinner CantidadE2;
    private javax.swing.JSpinner CantidadE3;
    private javax.swing.JSpinner CantidadE4;
    private javax.swing.JSpinner CantidadE5;
    private javax.swing.JSpinner CantidadE6;
    private javax.swing.JSpinner CantidadE7;
    private javax.swing.JSpinner CantidadE8;
    private javax.swing.JSpinner CantidadE9;
    private javax.swing.JSpinner CantidadEn1;
    private javax.swing.JSpinner CantidadEn2;
    private javax.swing.JSpinner CantidadEn3;
    private javax.swing.JSpinner CantidadEn4;
    private javax.swing.JSpinner CantidadEn5;
    private javax.swing.JSpinner CantidadEn6;
    private javax.swing.JSpinner CantidadEn7;
    private javax.swing.JSpinner CantidadH1;
    private javax.swing.JSpinner CantidadH10;
    private javax.swing.JSpinner CantidadH11;
    private javax.swing.JSpinner CantidadH12;
    private javax.swing.JSpinner CantidadH13;
    private javax.swing.JSpinner CantidadH14;
    private javax.swing.JSpinner CantidadH15;
    private javax.swing.JSpinner CantidadH16;
    private javax.swing.JSpinner CantidadH17;
    private javax.swing.JSpinner CantidadH18;
    private javax.swing.JSpinner CantidadH2;
    private javax.swing.JSpinner CantidadH3;
    private javax.swing.JSpinner CantidadH4;
    private javax.swing.JSpinner CantidadH5;
    private javax.swing.JSpinner CantidadH6;
    private javax.swing.JSpinner CantidadH7;
    private javax.swing.JSpinner CantidadH8;
    private javax.swing.JSpinner CantidadH9;
    private javax.swing.JSpinner CantidadP1;
    private javax.swing.JSpinner CantidadP2;
    private javax.swing.JSpinner CantidadP3;
    private javax.swing.JSpinner CantidadP4;
    private javax.swing.JLabel ComprarBanner;
    private javax.swing.JLabel CostoD1;
    private javax.swing.JLabel CostoD2;
    private javax.swing.JLabel CostoD3;
    private javax.swing.JLabel CostoD4;
    private javax.swing.JLabel CostoD5;
    private javax.swing.JLabel CostoD6;
    private javax.swing.JLabel CostoE1;
    private javax.swing.JLabel CostoE2;
    private javax.swing.JLabel CostoE3;
    private javax.swing.JLabel CostoE4;
    private javax.swing.JLabel CostoE5;
    private javax.swing.JLabel CostoE6;
    private javax.swing.JLabel CostoE7;
    private javax.swing.JLabel CostoE8;
    private javax.swing.JLabel CostoE9;
    private javax.swing.JLabel CostoEn1;
    private javax.swing.JLabel CostoEn2;
    private javax.swing.JLabel CostoEn3;
    private javax.swing.JLabel CostoEn4;
    private javax.swing.JLabel CostoEn5;
    private javax.swing.JLabel CostoEn6;
    private javax.swing.JLabel CostoEn7;
    private javax.swing.JLabel CostoFinal;
    private javax.swing.JLabel CostoH1;
    private javax.swing.JLabel CostoH10;
    private javax.swing.JLabel CostoH11;
    private javax.swing.JLabel CostoH12;
    private javax.swing.JLabel CostoH13;
    private javax.swing.JLabel CostoH14;
    private javax.swing.JLabel CostoH15;
    private javax.swing.JLabel CostoH16;
    private javax.swing.JLabel CostoH17;
    private javax.swing.JLabel CostoH18;
    private javax.swing.JLabel CostoH2;
    private javax.swing.JLabel CostoH3;
    private javax.swing.JLabel CostoH4;
    private javax.swing.JLabel CostoH5;
    private javax.swing.JLabel CostoH6;
    private javax.swing.JLabel CostoH7;
    private javax.swing.JLabel CostoH8;
    private javax.swing.JLabel CostoH9;
    private javax.swing.JLabel CostoP1;
    private javax.swing.JLabel CostoP2;
    private javax.swing.JLabel CostoP3;
    private javax.swing.JLabel CostoP4;
    private javax.swing.JLabel CostoPU1;
    private javax.swing.JLabel CostoPU2;
    private javax.swing.JLabel CostoPU3;
    private javax.swing.JLabel CostoPU4;
    private javax.swing.JLabel CostoPU5;
    private javax.swing.JLabel CostoPU6;
    private javax.swing.JLabel CostoPU7;
    private javax.swing.JLabel Decoracion1;
    private javax.swing.JCheckBox Decoracion1B;
    private javax.swing.JLabel Decoracion2;
    private javax.swing.JCheckBox Decoracion2B;
    private javax.swing.JLabel Decoracion3;
    private javax.swing.JCheckBox Decoracion3B;
    private javax.swing.JLabel Decoracion4;
    private javax.swing.JCheckBox Decoracion4B;
    private javax.swing.JLabel Decoracion5;
    private javax.swing.JCheckBox Decoracion5B;
    private javax.swing.JLabel Decoracion6;
    private javax.swing.JCheckBox Decoracion6B;
    private javax.swing.JLabel EditarB;
    private javax.swing.JLabel ElegirTipoMaterial;
    private javax.swing.JLabel Ensamblaje1;
    private javax.swing.JCheckBox Ensamblaje1B;
    private javax.swing.JLabel Ensamblaje2;
    private javax.swing.JCheckBox Ensamblaje2B;
    private javax.swing.JLabel Ensamblaje3;
    private javax.swing.JCheckBox Ensamblaje3B;
    private javax.swing.JLabel Ensamblaje4;
    private javax.swing.JCheckBox Ensamblaje4B;
    private javax.swing.JLabel Ensamblaje5;
    private javax.swing.JCheckBox Ensamblaje5B;
    private javax.swing.JLabel Ensamblaje6;
    private javax.swing.JCheckBox Ensamblaje6B;
    private javax.swing.JLabel Ensamblaje7;
    private javax.swing.JCheckBox Ensamblaje7B;
    private javax.swing.JLabel Estructura1;
    private javax.swing.JCheckBox Estructura1B;
    private javax.swing.JLabel Estructura2;
    private javax.swing.JCheckBox Estructura2B;
    private javax.swing.JLabel Estructura3;
    private javax.swing.JCheckBox Estructura3B;
    private javax.swing.JLabel Estructura4;
    private javax.swing.JCheckBox Estructura4B;
    private javax.swing.JLabel Estructura5;
    private javax.swing.JCheckBox Estructura5B;
    private javax.swing.JLabel Estructura6;
    private javax.swing.JCheckBox Estructura6B;
    private javax.swing.JLabel Estructura7;
    private javax.swing.JCheckBox Estructura7B;
    private javax.swing.JLabel Estructura8;
    private javax.swing.JCheckBox Estructura8B;
    private javax.swing.JLabel Estructura9;
    private javax.swing.JCheckBox Estructura9B;
    private javax.swing.JLabel FinalizarB;
    private javax.swing.JLabel HechoB;
    private javax.swing.JLabel Herramienta1;
    private javax.swing.JLabel Herramienta10;
    private javax.swing.JCheckBox Herramienta10B;
    private javax.swing.JLabel Herramienta11;
    private javax.swing.JCheckBox Herramienta11B;
    private javax.swing.JLabel Herramienta12;
    private javax.swing.JCheckBox Herramienta12B;
    private javax.swing.JLabel Herramienta13;
    private javax.swing.JCheckBox Herramienta13B;
    private javax.swing.JLabel Herramienta14;
    private javax.swing.JCheckBox Herramienta14B;
    private javax.swing.JLabel Herramienta15;
    private javax.swing.JCheckBox Herramienta15B;
    private javax.swing.JLabel Herramienta16;
    private javax.swing.JCheckBox Herramienta16B;
    private javax.swing.JLabel Herramienta17;
    private javax.swing.JCheckBox Herramienta17B;
    private javax.swing.JLabel Herramienta18;
    private javax.swing.JCheckBox Herramienta18B;
    private javax.swing.JCheckBox Herramienta1B;
    private javax.swing.JLabel Herramienta2;
    private javax.swing.JCheckBox Herramienta2B;
    private javax.swing.JLabel Herramienta3;
    private javax.swing.JCheckBox Herramienta3B;
    private javax.swing.JLabel Herramienta4;
    private javax.swing.JCheckBox Herramienta4B;
    private javax.swing.JLabel Herramienta5;
    private javax.swing.JCheckBox Herramienta5B;
    private javax.swing.JLabel Herramienta6;
    private javax.swing.JCheckBox Herramienta6B;
    private javax.swing.JLabel Herramienta7;
    private javax.swing.JCheckBox Herramienta7B;
    private javax.swing.JLabel Herramienta8;
    private javax.swing.JCheckBox Herramienta8B;
    private javax.swing.JLabel Herramienta9;
    private javax.swing.JCheckBox Herramienta9B;
    private javax.swing.JLabel Materiales1;
    private javax.swing.JLabel Materiales2;
    private javax.swing.JLabel Materiales3;
    private javax.swing.JLabel Materiales4;
    private javax.swing.JLabel Materiales5;
    private javax.swing.JLabel Materiales6;
    private javax.swing.JLabel Materiales7;
    private javax.swing.JLabel NoSustentablesD;
    private javax.swing.JLabel NoSustentablesE;
    private javax.swing.JPanel PanelTipos;
    private javax.swing.JLabel Proteccion1;
    private javax.swing.JCheckBox Proteccion1B;
    private javax.swing.JLabel Proteccion2;
    private javax.swing.JCheckBox Proteccion2B;
    private javax.swing.JLabel Proteccion3;
    private javax.swing.JCheckBox Proteccion3B;
    private javax.swing.JLabel Proteccion4;
    private javax.swing.JCheckBox Proteccion4B;
    private javax.swing.JLabel Recurso1;
    private javax.swing.JLabel Recurso2;
    private javax.swing.JLabel Recurso3;
    private javax.swing.JLabel Recurso4;
    private javax.swing.JLabel Recurso5;
    private javax.swing.JLabel Recurso6;
    private javax.swing.JLabel Recurso7;
    private javax.swing.JLabel Recurso8;
    private javax.swing.JLabel Recurso9;
    private javax.swing.JLabel ResumenMateriales;
    private javax.swing.JPanel Resumen_materiales;
    private javax.swing.JLabel Salir1;
    private javax.swing.JScrollPane SubVentanaD;
    private javax.swing.JScrollPane SubVentanaD_S;
    private javax.swing.JScrollPane SubVentanaE;
    private javax.swing.JScrollPane SubVentanaE_S;
    private javax.swing.JScrollPane SubVentanaEn;
    private javax.swing.JScrollPane SubVentanaH;
    private javax.swing.JScrollPane SubVentanaP;
    private javax.swing.JLabel SustentablesD;
    private javax.swing.JLabel SustentablesE;
    private javax.swing.JTable Tablamateriales;
    private javax.swing.JTabbedPane TiposMateriales;
    private javax.swing.JLabel Tractoricon1;
    private javax.swing.JLabel decoracion_label_btn;
    private javax.swing.JLabel ensamblaje_label_btn;
    private javax.swing.JLabel estructura_label_btn;
    private javax.swing.JLabel herramientas_label_btn;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel proteccion_label_btn;
    // End of variables declaration//GEN-END:variables
}
