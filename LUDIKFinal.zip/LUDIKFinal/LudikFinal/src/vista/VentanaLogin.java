/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;
import java.awt.*;
import java.applet.*;
import controller.Controladora;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import modelo.Usuario;
import persistencia.UsuariosXML;


public class VentanaLogin extends javax.swing.JFrame {
    
    //DECLARACIÓN DE VARIABLES
    Controladora control;
    UsuariosXML datosUsua = new UsuariosXML();
    ArrayList <Usuario> listaUsuarios = datosUsua.todosLosUsuarios();
    String nameTag;
    Object[] opciones = {"Sí", "No"};
   
    boolean errorUsuario=false;
    boolean errorContra=false;
    
    public VentanaLogin() {
        initComponents();
        
        control = new Controladora(this,IngreseUsuario,Contrasena);
        
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        
        this.listaUsuarios = new ArrayList<>();
        this.nameTag="";
        btn_focus.requestFocus();
 
    }
    
    /**
    public VentanaLogin(ArrayList <Usuario> usuarios) {
        initComponents();
        control = new Controladora(this,IngreseUsuario,Contrasena);
        
        control.iniciaVentana(this,"src/imagenes/ventanaLoginRegistroDisenar/logoLudik.PNG");
        this.listaUsuarios = usuarios;
        this.nameTag="";
        IngreseUsuario.requestFocus();
    }*/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        Salir1 = new javax.swing.JLabel();
        Banner = new javax.swing.JLabel();
        Contrasena1 = new javax.swing.JLabel();
        empezar_btn = new javax.swing.JLabel();
        Usuario = new javax.swing.JLabel();
        FondoCampo2 = new javax.swing.JPanel();
        IngreseUsuario = new javax.swing.JTextField();
        FondoCampo = new javax.swing.JPanel();
        Contrasena = new javax.swing.JPasswordField();
        inicioDeSesion_label = new javax.swing.JLabel();
        Registrarse = new javax.swing.JLabel();
        NoTieneCuenta = new javax.swing.JLabel();
        focus_btn = new javax.swing.JButton();
        errorContraInvalida = new javax.swing.JLabel();
        errorUsuarioNoReg = new javax.swing.JLabel();
        btn_focus = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Salir1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/equisitaIcon.PNG"))); // NOI18N
        Salir1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Salir1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Salir1MouseClicked(evt);
            }
        });
        Fondo.add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 10, 40, 50));

        Banner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/BienvenidoALudik11.PNG"))); // NOI18N
        Fondo.add(Banner, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 640));

        Contrasena1.setBackground(new java.awt.Color(0, 74, 173));
        Contrasena1.setFont(new java.awt.Font("Questrial", 0, 27)); // NOI18N
        Contrasena1.setForeground(new java.awt.Color(0, 74, 173));
        Contrasena1.setText("Contraseña");
        Fondo.add(Contrasena1, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 310, -1, -1));

        empezar_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/Empezar.PNG"))); // NOI18N
        empezar_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        empezar_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                empezar_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                empezar_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                empezar_btnMouseExited(evt);
            }
        });
        Fondo.add(empezar_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 440, 230, 80));

        Usuario.setBackground(new java.awt.Color(0, 74, 173));
        Usuario.setFont(new java.awt.Font("Questrial", 0, 27)); // NOI18N
        Usuario.setForeground(new java.awt.Color(0, 74, 173));
        Usuario.setText("Usuario");
        Fondo.add(Usuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 180, -1, -1));

        FondoCampo2.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampo2Layout = new javax.swing.GroupLayout(FondoCampo2);
        FondoCampo2.setLayout(FondoCampo2Layout);
        FondoCampo2Layout.setHorizontalGroup(
            FondoCampo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampo2Layout.setVerticalGroup(
            FondoCampo2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 250, 380, 5));

        IngreseUsuario.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        IngreseUsuario.setForeground(new java.awt.Color(143, 167, 198));
        IngreseUsuario.setText("Ingrese su nombre de usuario.");
        IngreseUsuario.setBorder(null);
        IngreseUsuario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                IngreseUsuarioMousePressed(evt);
            }
        });
        IngreseUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngreseUsuarioActionPerformed(evt);
            }
        });
        Fondo.add(IngreseUsuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 220, 380, 30));

        FondoCampo.setBackground(new java.awt.Color(213, 225, 240));

        javax.swing.GroupLayout FondoCampoLayout = new javax.swing.GroupLayout(FondoCampo);
        FondoCampo.setLayout(FondoCampoLayout);
        FondoCampoLayout.setHorizontalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 380, Short.MAX_VALUE)
        );
        FondoCampoLayout.setVerticalGroup(
            FondoCampoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        Fondo.add(FondoCampo, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 380, 380, 5));

        Contrasena.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        Contrasena.setForeground(new java.awt.Color(143, 167, 198));
        Contrasena.setText("Ingrese su contraseña");
        Contrasena.setToolTipText("");
        Contrasena.setBorder(null);
        Contrasena.setEchoChar('\u0000');
        Contrasena.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                ContrasenaMousePressed(evt);
            }
        });
        Contrasena.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContrasenaActionPerformed(evt);
            }
        });
        Fondo.add(Contrasena, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 340, 370, 50));

        inicioDeSesion_label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/ventanaLoginRegistroDisenar/IniciarSesion.PNG"))); // NOI18N
        Fondo.add(inicioDeSesion_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 70, 340, 80));

        Registrarse.setBackground(new java.awt.Color(0, 74, 173));
        Registrarse.setFont(new java.awt.Font("Questrial", 0, 20)); // NOI18N
        Registrarse.setForeground(new java.awt.Color(143, 167, 198));
        Registrarse.setText("Registrarse.");
        Registrarse.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Registrarse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                RegistrarseMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                RegistrarseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                RegistrarseMouseExited(evt);
            }
        });
        Fondo.add(Registrarse, new org.netbeans.lib.awtextra.AbsoluteConstraints(890, 510, -1, 50));

        NoTieneCuenta.setBackground(new java.awt.Color(0, 74, 173));
        NoTieneCuenta.setFont(new java.awt.Font("Questrial", 0, 20)); // NOI18N
        NoTieneCuenta.setForeground(new java.awt.Color(113, 114, 135));
        NoTieneCuenta.setText("¿No tiene una cuenta?");
        Fondo.add(NoTieneCuenta, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 510, -1, 50));

        focus_btn.setText("jButton1");
        Fondo.add(focus_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 170, -1, -1));

        errorContraInvalida.setBackground(new java.awt.Color(0, 74, 173));
        errorContraInvalida.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        errorContraInvalida.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(errorContraInvalida, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 390, 380, 30));

        errorUsuarioNoReg.setBackground(new java.awt.Color(0, 74, 173));
        errorUsuarioNoReg.setFont(new java.awt.Font("Questrial", 0, 18)); // NOI18N
        errorUsuarioNoReg.setForeground(new java.awt.Color(204, 0, 51));
        Fondo.add(errorUsuarioNoReg, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 260, 380, 30));

        btn_focus.setText("jButton1");
        Fondo.add(btn_focus, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, -1, -1));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IngreseUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngreseUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_IngreseUsuarioActionPerformed
    
    
    
    private void RegistrarseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegistrarseMouseEntered
        Registrarse.setForeground(Color.blue);
    }//GEN-LAST:event_RegistrarseMouseEntered

    private void RegistrarseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegistrarseMouseExited
        Registrarse.setForeground(new Color(143,167,198));
    }//GEN-LAST:event_RegistrarseMouseExited

    private void ContrasenaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContrasenaActionPerformed
        
    }//GEN-LAST:event_ContrasenaActionPerformed

    private void IngreseUsuarioMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IngreseUsuarioMousePressed
        FondoCampo.setBackground(new Color(213,225,240));
        errorUsuarioNoReg.setText("");
        errorContraInvalida.setText("");
        
        if (errorUsuario==true) {
            errorUsuario=false;
            IngreseUsuario.setText("");
        }
        
        if (IngreseUsuario.getText().equals("Ingrese su nombre de usuario.")) {
           IngreseUsuario.setText("");
           IngreseUsuario.setForeground(new Color(47,58,129));
            }
        if (String.valueOf(Contrasena.getPassword()).isEmpty()) {
          Contrasena.setEchoChar('\0');
          Contrasena.setText("Ingrese su contraseña");
          Contrasena.setForeground(new Color(143,167,198)); 
        }
      
        FondoCampo2.setBackground(new Color(0,74,173));
    }//GEN-LAST:event_IngreseUsuarioMousePressed

    private void ContrasenaMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ContrasenaMousePressed
      FondoCampo2.setBackground(new Color(213,225,240));
      errorUsuarioNoReg.setText("");
      errorContraInvalida.setText("");
      
      if (errorContra==true) {
          errorContra=false;
          Contrasena.setText("");
      }
      
      if (String.valueOf(Contrasena.getPassword()).equals("Ingrese su contraseña")) {
          Contrasena.setEchoChar('\u2022');
          Contrasena.setText("");
          Contrasena.setForeground(new Color(47,58,129));
       }
      if (IngreseUsuario.getText().isEmpty()) {
         IngreseUsuario.setText("Ingrese su nombre de usuario.");
         IngreseUsuario.setForeground(new Color(143,167,198));
        }
      
      FondoCampo.setBackground(new Color(0,74,173));
    }//GEN-LAST:event_ContrasenaMousePressed

    private void RegistrarseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_RegistrarseMouseClicked
        VentanaRegistro ventana = new VentanaRegistro();
        control.activaVentana(ventana,this); 
    }//GEN-LAST:event_RegistrarseMouseClicked

    private void empezar_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_empezar_btnMouseClicked

        if ((control.validarUsuario(IngreseUsuario.getText())==false)) {
            errorUsuario=true;
            FondoCampo2.setBackground(new Color(204,0,51));
            errorUsuarioNoReg.setText("Este usuario no se encuentra registrado.");
            IngreseUsuario.requestFocus();
            Contrasena.setForeground(new Color(143,167,198));
            FondoCampo.setBackground(new Color(213,225,240));
            Contrasena.setText("");
        }
        else if (control.validarContrasena(IngreseUsuario.getText(),String.valueOf(Contrasena.getPassword()))==false) {
            errorContra=true;
            FondoCampo2.setBackground(new Color(213,225,240));
            
            errorUsuarioNoReg.setText("");
            FondoCampo.setBackground(new Color(204,0,51));
            errorContraInvalida.setText("La contraseña es incorrecta. Intente de nuevo.");
            Contrasena.requestFocus();
        }
        else {
            FondoCampo2.setBackground(new Color(213,225,240));
            errorUsuarioNoReg.setText("");
            FondoCampo.setBackground(new Color(213,225,240));
            errorContraInvalida.setText("");
            
            
            nameTag = control.obtenerNametag(IngreseUsuario.getText());
            Usuario usuarioActual = new Usuario();
            
            usuarioActual= control.usuarioActual(IngreseUsuario.getText());
            VentanaPrincipal ventana = new VentanaPrincipal(usuarioActual);
            ventana.usuarioActual=usuarioActual;
            control.activaVentana(ventana, this);
        }
    }//GEN-LAST:event_empezar_btnMouseClicked

    private void empezar_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_empezar_btnMouseEntered
        empezar_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/boton_empezar_claro.png"));
    }//GEN-LAST:event_empezar_btnMouseEntered

    private void empezar_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_empezar_btnMouseExited
        empezar_btn.setIcon(new ImageIcon("src/imagenes/ventanaLoginRegistroDisenar/Empezar.png"));
    }//GEN-LAST:event_empezar_btnMouseExited

    private void Salir1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Salir1MouseClicked
        UIManager.put("OptionPane.messageFont", new Font("Garet Book", Font.PLAIN, 12));
        UIManager.put("OptionPane.buttonFont", new Font("Garet Book", Font.PLAIN, 12));
        int confirmacion = JOptionPane.showOptionDialog(
            null, "¿Desea salir de Ludik?", "Confirmación",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, new ImageIcon("src/images/ventanaPrincipal/aviso_icono.png"), opciones, opciones[0]);
        if (confirmacion == 0){
            this.dispose();//elimina la ventana de la memoria y no continúa ejecutándose
        }
    }//GEN-LAST:event_Salir1MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaLogin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaLogin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Banner;
    private javax.swing.JPasswordField Contrasena;
    private javax.swing.JLabel Contrasena1;
    private javax.swing.JPanel Fondo;
    private javax.swing.JPanel FondoCampo;
    private javax.swing.JPanel FondoCampo2;
    private javax.swing.JTextField IngreseUsuario;
    private javax.swing.JLabel NoTieneCuenta;
    private javax.swing.JLabel Registrarse;
    private javax.swing.JLabel Salir1;
    private javax.swing.JLabel Usuario;
    private javax.swing.JButton btn_focus;
    private javax.swing.JLabel empezar_btn;
    private javax.swing.JLabel errorContraInvalida;
    private javax.swing.JLabel errorUsuarioNoReg;
    private javax.swing.JButton focus_btn;
    private javax.swing.JLabel inicioDeSesion_label;
    // End of variables declaration//GEN-END:variables
}
