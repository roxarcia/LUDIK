/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package vista;

import controller.Controladora;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JTable;
import modelo.Diseño;
import modelo.Usuario;
import persistencia.DiseñosXML;

/**
 *
 * @author Adrian
 */
public class VentanaComprar1 extends javax.swing.JFrame {

    Controladora control;
    DiseñosXML datosDise = new DiseñosXML();
    ArrayList<Diseño> listaDiseños= datosDise.todosLosDiseños();
    ArrayList<Diseño> diseñosDisponibles;
    JTable tablaDisenos;
    Usuario usuarioActual;
    Diseño diseñoActual;
    
    public VentanaComprar1() {
        initComponents();
        control = new Controladora(this, tablaDisenos, Elegir);
        //control.llenarCombo();
        this.listaDiseños= new ArrayList<>();
        this.usuarioActual=new Usuario();
        this.diseñosDisponibles= new ArrayList<>();
        this.diseñoActual = new Diseño();
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        control.activa_Desactiva(false, siguiente_btn);
    }
    
    public VentanaComprar1(Usuario user) {
        initComponents();
        control = new Controladora(this, tablaDisenos, Elegir);
        
        this.listaDiseños=new ArrayList<>();
        this.diseñosDisponibles= new ArrayList<>();
        this.usuarioActual=user;
        this.diseñoActual = new Diseño();
        String usuario= usuarioActual.getUser();
        diseñosDisponibles = control.llenarMisCompras(usuario);
        control.llenarTabla(diseñosDisponibles,TablaDisenos);
        control.llenarCombo(Elegir,diseñosDisponibles);
        control.iniciaVentana(this,"src/imagenes/stuIconN.png" );
        control.iniciaVentana(this, "src/images/ventanaPrincipal/logoLudik.png");
        control.activa_Desactiva(false, siguiente_btn);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        ComprarBanner = new javax.swing.JLabel();
        cancelar_btn = new javax.swing.JButton();
        Recurso1 = new javax.swing.JLabel();
        Recurso2 = new javax.swing.JLabel();
        ElegirDiseno = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TablaDisenos = new javax.swing.JTable();
        Elegir = new javax.swing.JComboBox<>();
        siguiente_btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Fondo.setBackground(new java.awt.Color(255, 255, 255));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ComprarBanner.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Banner_comprar.png"))); // NOI18N
        Fondo.add(ComprarBanner, new org.netbeans.lib.awtextra.AbsoluteConstraints(-20, 0, 1090, 140));

        cancelar_btn.setBackground(new java.awt.Color(242, 242, 242));
        cancelar_btn.setFont(new java.awt.Font("Garet Book", 0, 18)); // NOI18N
        cancelar_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/homeIcon.PNG"))); // NOI18N
        cancelar_btn.setBorder(null);
        cancelar_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cancelar_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cancelar_btnMouseClicked(evt);
            }
        });
        cancelar_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelar_btnActionPerformed(evt);
            }
        });
        Fondo.add(cancelar_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 530, 100, 90));

        Recurso1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        Fondo.add(Recurso1, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 210, -1, -1));

        Recurso2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/fondo2_comprar.png"))); // NOI18N
        Fondo.add(Recurso2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-160, 184, 320, 280));

        ElegirDiseno.setFont(new java.awt.Font("Garet Heavy", 0, 40)); // NOI18N
        ElegirDiseno.setForeground(new java.awt.Color(145, 209, 248));
        ElegirDiseno.setText(" Elegir Diseño");
        Fondo.add(ElegirDiseno, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, -1, -1));

        jScrollPane2.setForeground(new java.awt.Color(19, 166, 255));
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane2.setFont(new java.awt.Font("Garet Book", 0, 12)); // NOI18N

        TablaDisenos.setBackground(new java.awt.Color(212, 235, 250));
        TablaDisenos.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TablaDisenos.setFont(new java.awt.Font("Garet Book", 0, 24)); // NOI18N
        TablaDisenos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"Parque Celeste", "Moderno"},
                {"", ""},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, ""},
                {null, null}
            },
            new String [] {
                "Nombre", "Estilo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TablaDisenos.setGridColor(new java.awt.Color(90, 189, 240));
        TablaDisenos.setIntercellSpacing(new java.awt.Dimension(2, 2));
        TablaDisenos.setRowHeight(30);
        TablaDisenos.setSelectionBackground(new java.awt.Color(0, 123, 197));
        TablaDisenos.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaDisenos.setShowGrid(true);
        jScrollPane2.setViewportView(TablaDisenos);

        Fondo.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 260, 690, 270));
        jScrollPane2.getAccessibleContext().setAccessibleDescription("");

        Elegir.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "No seleccionado" }));
        Elegir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ElegirActionPerformed(evt);
            }
        });
        Fondo.add(Elegir, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 560, 300, 40));

        siguiente_btn.setBackground(new java.awt.Color(242, 242, 242));
        siguiente_btn.setFont(new java.awt.Font("Garet Book", 0, 18)); // NOI18N
        siguiente_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ventanaComprar/Boton_Adelante.png"))); // NOI18N
        siguiente_btn.setBorder(null);
        siguiente_btn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        siguiente_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                siguiente_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                siguiente_btnMouseExited(evt);
            }
        });
        siguiente_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                siguiente_btnActionPerformed(evt);
            }
        });
        Fondo.add(siguiente_btn, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 550, 70, 70));

        getContentPane().add(Fondo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 640));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ElegirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ElegirActionPerformed
        if(Elegir.getSelectedItem() == "No seleccionado" || Elegir.getSelectedIndex() == -1){
            siguiente_btn.setEnabled(false);
        } else{
            siguiente_btn.setEnabled(true);
        }
    }//GEN-LAST:event_ElegirActionPerformed

    private void siguiente_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_siguiente_btnActionPerformed
        if(Elegir.getSelectedItem() != "No seleccionado" && Elegir.getSelectedIndex() != -1){
            
            String nombre = Elegir.getSelectedItem().toString();
            String usuario= usuarioActual.getUser();
            diseñoActual = control.diseñoActual(nombre,usuario);
            VentanaComprar2 ventana = new VentanaComprar2(diseñoActual,usuarioActual);
            ventana.usuarioActual= usuarioActual;
            ventana.diseñoActual=diseñoActual;
            control.activaVentana(ventana, this);
        }
    }//GEN-LAST:event_siguiente_btnActionPerformed

    private void cancelar_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelar_btnActionPerformed
        VentanaPrincipal ventana = new VentanaPrincipal(usuarioActual);
        ventana.usuarioActual=usuarioActual;
        control.activaVentana(ventana, this);
    }//GEN-LAST:event_cancelar_btnActionPerformed

    private void siguiente_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguiente_btnMouseEntered
        if(siguiente_btn.isEnabled()){
            siguiente_btn.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Adelante_claro.png"));
        }
    }//GEN-LAST:event_siguiente_btnMouseEntered

    private void siguiente_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_siguiente_btnMouseExited
        siguiente_btn.setIcon(new ImageIcon("src/images/ventanaComprar/Boton_Adelante.png"));
    }//GEN-LAST:event_siguiente_btnMouseExited

    private void cancelar_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cancelar_btnMouseClicked
       VentanaPrincipal ventana = new VentanaPrincipal(usuarioActual);
       ventana.usuarioActual=usuarioActual;
    }//GEN-LAST:event_cancelar_btnMouseClicked

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaComprar1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaComprar1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ComprarBanner;
    private javax.swing.JComboBox<String> Elegir;
    private javax.swing.JLabel ElegirDiseno;
    private javax.swing.JPanel Fondo;
    private javax.swing.JLabel Recurso1;
    private javax.swing.JLabel Recurso2;
    private javax.swing.JTable TablaDisenos;
    private javax.swing.JButton cancelar_btn;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton siguiente_btn;
    // End of variables declaration//GEN-END:variables
}
