/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author user
 */
public class Diseño {
   private String tipo; //exterior o interior
    private String medidas;
    private String estilo;
    private String nombre;
    private String terminado; //1 para verdadero, 0 para falso
    private String costoTotal;
    private String userAutor; //creador del diseño
    
    public Diseño() {
        this.tipo = "";
        this.medidas = "";
        this.estilo = "";
        this.nombre = "";
        this.terminado ="0";
        this.costoTotal = "";
        this.userAutor = "";
    }
    public Diseño(String tipo, String medidas, String estilo, String nombre, String terminado, String costoTotal, String userAutor) {
        this.tipo = tipo;
        this.medidas = medidas;
        this.estilo = estilo;
        this.nombre = nombre;
        this.terminado = terminado;
        this.costoTotal = costoTotal;
        this.userAutor = userAutor;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMedidas() {
        return medidas;
    }

    public void setMedidas(String medidas) {
        this.medidas = medidas;
    }

    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTerminado() {
        return terminado;
    }

    public void setTerminado(String terminado) {
        this.terminado = terminado;
    }

    public String getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(String costoTotal) {
        this.costoTotal = costoTotal;
    }

    public String getUserAutor() {
        return userAutor;
    }

    public void setUserAutor(String userAutor) {
        this.userAutor = userAutor;
    }
    
    
}
