/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.*;
import persistencia.UsuariosXML;
/**
 *
 * @author Cristian De Sousa
 */
public class Utilitaria {
    
    static UsuariosXML datosUsua = new UsuariosXML();
    
    public static boolean validarPatron(String patron, String cadena){
        Pattern pat = Pattern.compile(patron);
        Matcher mat = pat.matcher(cadena);
        return !mat.matches();
    }
    
    public static boolean cantidadDeCaracteres(JTextField entrada, int cantidad){
        if(entrada.getText().length() < cantidad){
            return true;
        }
        return false;
        
    }
    
    public static boolean confirmarContrasena(JTextField entrada1, JTextField entrada2){
        if(!entrada1.getText().equals(entrada2.getText())){
            return true;
        }
        return false;
    }
    
    public static boolean usuarioExistente(JTextField entrada){
        if (datosUsua.buscarUsuario(entrada.getText()) != null){
            return true;
        }
        return false;
    }
    
}
