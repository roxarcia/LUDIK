/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author Adrian
 */
public class Material {
   private String nombre;
    private String rubro;
    private String unidad;
    private String diseno;
    private int cantidad;
    private double costound;
    private double costototal;

    public Material() {
        nombre = "";
        rubro = "";
        unidad = "";
        diseno = "";
        cantidad = 0;
        costound = 0;
        costototal = 0;
    }

    public Material(String nombre, String rubro, int cantidad, double costound, String diseno) {
        this.nombre = nombre;
        this.rubro = rubro;
        this.cantidad = cantidad;
        this.costound = costound;
        this.diseno = diseno;       
    }

    
    
    public Material(String nombre, String rubro, String unidad, int cantidad, double costound, String diseno) {
        this.nombre = nombre;
        this.rubro = rubro;
        this.unidad = unidad;
        this.cantidad = cantidad;
        this.costound = costound;
        this.diseno = diseno;
    }
    
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRubro() {
        return rubro;
    }
    
    public void setRubro(String rubro) {
        this.rubro = rubro;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public String getDiseno() {
        return diseno;
    }

    public void setDiseno(String diseno) {
        this.diseno = diseno;
    }
    
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getCostound() {
        return costound;
    }

    public void setCostound(double costound) {
        this.costound = costound;
    }

    public double getCostototal() {
        return costototal;
    }

    public void setCostototal(double costototal) {
        this.costototal = costototal;
    }
    
    public void calcularCostoTotal(){
        costototal = cantidad * costound;
    }
    
}
