/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;

public class Usuario {
    private String user;
    private String nombre;
    private String contrasena;
    private String email;
    private ArrayList<Diseño> listaDiseños;
    
    public Usuario() {
        this.user ="";
        this.nombre = "";
        this.contrasena ="";
        this.email = "";
        this.listaDiseños = new ArrayList<>();
    }

    public Usuario(String user, String nombre, String contrasena, String email) {
        this.user = user;
        this.nombre = nombre;
        this.contrasena = contrasena;
        this.email = email;
        this.listaDiseños = new ArrayList<>();
    }
    public Usuario( ArrayList<Diseño> listaDiseños) {
        this.listaDiseños = listaDiseños;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public ArrayList<Diseño> getListaDiseños() {
        return listaDiseños;
    }

    public void setListaDiseños(ArrayList<Diseño> listaDiseños) {
        this.listaDiseños = listaDiseños;
    }
    
    
}