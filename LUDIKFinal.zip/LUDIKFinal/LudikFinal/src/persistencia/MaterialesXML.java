/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

/**
 *
 * @author Adrian
 */
import modelo.Material;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import modelo.Usuario;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

public class MaterialesXML {
    
    private Element root;/* variable que contiene la raiz del documento Xml*/
    private String fileLocation = "src//archivosXML//materiales.xml";
    /* variable que contiene la localizacion del archivo xml*/

    public MaterialesXML() {
        /*  constructor por defecto que inicia los valores para trabajar
     *  con el documento xml
     */
        try {
            SAXBuilder builder = new SAXBuilder(false); //parse que maneja el XMl
            Document doc = builder.build(fileLocation);
            root = doc.getRootElement();
        } catch (JDOMException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        }
    }
    
    private Element MaterialtoXmlElement(Material nMaterial) {
    /*Aqui lleno todo el contexto que le voy a insertar al archivo, es decir
      el nodo proncipal que es Estudiante con los atributos que le corresponden,
      los cuales seria cedula,nombre y apellido,etc. Debes ser muuuuy preciso en
      este llenado, es decir, indicar los atributos con pelos y señales exactamente
      como están en la Clase, de lo contrario la tabla XML no se generará y no
      se produzca ningún error que te advierta que falta un acento, un espacio u
     otro símbolo     
     */     
        Element Materialtrans = new Element("Material");//nombre de la Clase
        Element nombre = new Element("nombre"); 
        nombre.setText(nMaterial.getNombre()); 
        Element diseno = new Element("diseno");//se crea cada etiqueta del XML
        diseno.setText(nMaterial.getDiseno());//asocia el valor a la etiqueta 
        Element rubro = new Element("rubro");
        rubro.setText(nMaterial.getRubro());     
        Element cantidad = new Element("cantidad");
        cantidad.setText(Integer.toString(nMaterial.getCantidad()));
        Element costo = new Element ("costo");
        costo.setText(Double.toString(nMaterial.getCostound()));
        Element costototal = new Element ("costototal");
        costototal.setText(Double.toString(nMaterial.getCantidad()*nMaterial.getCostound()));
        Materialtrans.addContent(nombre); //se pasan los valores al documento XML
        Materialtrans.addContent(diseno);
        Materialtrans.addContent(rubro);
        Materialtrans.addContent(cantidad);
        Materialtrans.addContent(costo);
        Materialtrans.addContent(costototal);

        return Materialtrans;
    }
    
    private Material MaterialToObject(Element element) throws ParseException {
    /*Método que retorna un Estudiante. A este metodo se le manda un Element y con
    sus datos se hará los pasos requeridos para crear el objeto Estudiante*/
        Material nMaterial = new Material(element.getChildText("nombre"),element.getChildText("rubro"),
                Integer.parseInt(element.getChildText("cantidad")), Double.parseDouble(element.getChildText("costo")),
                element.getChildText("diseno"));
        nMaterial.calcularCostoTotal();
        return nMaterial;
    }
    
    private boolean updateDocument() {
    /* método para guardar en el documento Xml los cambios efectuados
    * @return true si se cumplió la operacion con éxito, false en caso contrario*/
        try {
            XMLOutputter out = new XMLOutputter(org.jdom.output.Format.getPrettyFormat());
            FileOutputStream file = new FileOutputStream(fileLocation);
            out.output(root, file);
            file.flush();
            file.close();
            return true;
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
            return false;
        }
    }

    public static Element buscar(List raiz, String dato1, String dato2) {
    /* Operacion que busca un elemento que cumpla con una condicion en el id del xml
     * @param raiz = raiz del documento xml
     * @param dato = elemento a buscar.
     * @return retorna el elemento si existe con la condicion, en caso contrario retorna null */
      Iterator i = raiz.iterator();
      while (i.hasNext()) {
         Element e = (Element) i.next();
         if (dato1.equals(e.getChild("nombre").getText())&&dato2.equals(e.getChild("diseno").getText())) {
             return e;
            }
        }
      return null;
    }
    
    public static Element buscar(List raiz, String dato) {
   /* Operacion que busca un elemento que cumpla con una condicion en el id del xml
     * @param raiz = raiz del documento xml
     * @param dato = elemento a buscar.
     * @return retorna el elemento si existe con la condicion, en caso contrario retorna null */
      Iterator i = raiz.iterator();
      while (i.hasNext()) {
         Element e = (Element) i.next();
         if (dato.equals(e.getChild("diseno").getText())) {
             return e;
            }
        }
      return null;
    }
    
    public boolean agregarMaterial(Material nMaterial) {
    // @return valor boleano con la condición de éxito     
        root.addContent(MaterialtoXmlElement(nMaterial));
        boolean resultado = updateDocument();
        return resultado;
    }
    
    public Material buscarMaterial(String nombre,String diseno) {
    /* @param cedula número de cedula del Estudiante a buscar
    * @return objeto Estudiante con sus datos segun busqueda*/
        Element aux = new Element("Material");
        List Materiales = this.root.getChildren("Material");
        while (aux != null) {
        aux = MaterialesXML.buscar(Materiales, nombre, diseno);
        if (aux != null) {
            try {
                 return MaterialToObject(aux);
            } catch (ParseException ex) {
                 System.out.println(ex.getMessage());
            }
       }
     }
       return null;
    }
    
    public boolean actualizarMaterial(Material nMaterial, String nombre, String diseno) {
    /* @param Estudiante objeto Estudiante a actualizar
     * @return valor booleano con la condición de éxito */
        boolean resultado = false;
        Element aux = new Element("Material");
        List Materiales = this.root.getChildren("Material");
        while (aux != null) {
            aux = MaterialesXML.buscar(Materiales, nombre, diseno);
            if (aux != null) {
                Materiales.remove(aux);
                resultado = updateDocument();
            }
        }
        agregarMaterial(nMaterial);
        return resultado;
    }
    
    public boolean borrarMaterial(String diseno) {
    /* @param cedula cédula del Estudiante a borrar
    * @return valor booleano con la condición de éxito */ 
        boolean resultado = false;
        Element aux = new Element("Material");
        List Materiales = this.root.getChildren("Material");
        while (aux != null) {
            aux = MaterialesXML.buscar(Materiales, diseno);
            if (aux != null) {
                Materiales.remove(aux);
                resultado = updateDocument();
            }
        }
        return resultado;
    }
    
    public ArrayList<Material> todosLosMateriales() {
    /* Para obtener todas las Personas registradas
     * @return ArrayList con todos los objetos Estudiante  */
      ArrayList<Material> resultado = new ArrayList<Material>();
      for (Object it : root.getChildren()) {
            Element xmlElem = (Element) it;
            try {
                resultado.add(MaterialToObject(xmlElem));
            } catch (ParseException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return resultado;
    }
}
