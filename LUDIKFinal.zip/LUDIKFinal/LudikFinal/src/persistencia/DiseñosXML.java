/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

import modelo.Usuario;
import modelo.Diseño;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;


public class DiseñosXML {
    private Element root;/* variable que contiene la raiz del documento Xml*/
    private String fileLocation = "src//archivosXML//diseños.xml";
    /* variable que contiene la localizacion del archivo xml*/
    public DiseñosXML() {
    /*  constructor por defecto que inicia los valores para trabajar
     *  con el documento xml
     */
        try {
            SAXBuilder builder = new SAXBuilder(false); //parse que maneja el XMl
            Document doc = builder.build(fileLocation);
            root = doc.getRootElement();
        } catch (JDOMException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        }
    }
  
    private Element DiseñotoXmlElement(Diseño nDiseño) {
  
     Element Diseñotrans = new Element("Diseño");//nombre de la Clase
     
     Element tipo = new Element("tipo"); 
     tipo.setText(nDiseño.getTipo()); 
     
     Element medidas = new Element("medidas");//se crea cada etiqueta del XML
     medidas.setText(nDiseño.getMedidas());//asocia el valor a la etiqueta 
     
     Element estilo = new Element("estilo");
     estilo.setText(nDiseño.getEstilo());
     
     Element nombre = new Element("nombre");
     nombre.setText(nDiseño.getNombre());
     
     Element terminado = new Element("terminado");
     terminado.setText(nDiseño.getTerminado());
     
     Element costoTotal = new Element("costoTotal");
     costoTotal.setText(nDiseño.getCostoTotal());
     
     Element userAutor = new Element("userAutor");
     userAutor.setText(nDiseño.getUserAutor());
     
     Diseñotrans.addContent(tipo);
     Diseñotrans.addContent(medidas);
     Diseñotrans.addContent(estilo);
     Diseñotrans.addContent(nombre);
     Diseñotrans.addContent(terminado);
     Diseñotrans.addContent(costoTotal);
     Diseñotrans.addContent(userAutor);
     
     return Diseñotrans;
  }

 private Diseño DiseñoToObject(Element element) throws ParseException {
   /*Método que retorna un Estudiante. A este metodo se le manda un Element y con
    sus datos se hará los pasos requeridos para crear el objeto Estudiante*/
        Diseño nDiseño = new Diseño(element.getChildText("tipo"),element.getChildText("medidas"),element.getChildText("estilo"),element.getChildText("nombre"),element.getChildText("terminado"),element.getChildText("costoTotal"),element.getChildText("userAutor"));
        return nDiseño;
    }

   
  private boolean updateDocument() {
   /* método para guardar en el documento Xml los cambios efectuados
    * @return true si se cumplió la operacion con éxito, false en caso contrario*/
        try {
            XMLOutputter out = new XMLOutputter(org.jdom.output.Format.getPrettyFormat());
            FileOutputStream file = new FileOutputStream(fileLocation);
            out.output(root, file);
            file.flush();
            file.close();
            return true;
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
            return false;
        }
    }

   
    public static Element buscar(List raiz, String dato) {
   /* Operacion que busca un elemento que cumpla con una condicion en el id del xml
     * @param raiz = raiz del documento xml
     * @param dato = elemento a buscar.
     * @return retorna el elemento si existe con la condicion, en caso contrario retorna null */
      Iterator i = raiz.iterator();
      while (i.hasNext()) {
         Element e = (Element) i.next();
         if (dato.equals(e.getChild("nombre").getText())) {
             return e;
            }
        }
      return null;
    }
   
    public boolean agregarDiseño(Diseño nDiseño) {
   // @return valor boleano con la condición de éxito     
        root.addContent(DiseñotoXmlElement(nDiseño));
        boolean  resultado = updateDocument();
        return resultado;
    }
    
    public Diseño buscarDiseño(String nombre) {
    /* @param cedula número de cedula del Estudiante a buscar
    * @return objeto Estudiante con sus datos segun busqueda*/
      Element aux = new Element("Diseño");
      List Diseños = this.root.getChildren("Diseño");
      while (aux != null) {
        aux = DiseñosXML.buscar(Diseños, nombre);
        if (aux != null) {
           try {
                return DiseñoToObject(aux);
           } catch (ParseException ex) {
                System.out.println(ex.getMessage());
           }
       }
     }
       return null;
   }
    
    
    public boolean actualizarDiseño(Diseño nDiseño, String nombre) {
    /* @param Estudiante objeto Estudiante a actualizar
     * @return valor booleano con la condición de éxito */
        boolean resultado = false;
        Element aux = new Element("Diseño");
        List Diseños = this.root.getChildren("Diseño");
        while (aux != null) {
            aux = DiseñosXML.buscar(Diseños, nombre);
            if (aux != null) {
                Diseños.remove(aux);
                resultado = updateDocument();
            }
        }
        agregarDiseño(nDiseño);
        return resultado;
    }
    
    
    public boolean borrarDiseño(String nombre) {
    /* @param cedula cédula del Estudiante a borrar
    * @return valor booleano con la condición de éxito */ 
        boolean resultado = false;
        Element aux = new Element("Diseño");
        List Diseños = this.root.getChildren("Diseño");
        while (aux != null) {
            aux = DiseñosXML.buscar(Diseños, nombre);
            if (aux != null) {
                Diseños.remove(aux);
                resultado = updateDocument();
            }
        }
        return resultado;
    
    }
    
    
    
    public ArrayList<Diseño> todosLosDiseños() {
      /* Para obtener todas las Personas registradas
       * @return ArrayList con todos los objetos Estudiante  */
        ArrayList<Diseño> resultado = new ArrayList<Diseño>();
        for (Object it : root.getChildren()) {
              Element xmlElem = (Element) it;
              try {
                  resultado.add(DiseñoToObject(xmlElem));
              } catch (ParseException ex) {
                  System.out.println(ex.getMessage());
              }
          }
          return resultado;
      }

}
