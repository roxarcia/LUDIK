/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package persistencia;

/**
 *
 * @author Cristian De Sousa
 */
import modelo.Usuario;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

/*
 * Clase de persistencia de implementacion DAO con tecnologia
 * XML para el dominio de Estudiante
 */
public class UsuariosXML {
    
    private Element root;/* variable que contiene la raiz del documento Xml*/
    private String fileLocation = "src//archivosXML//usuarios.xml";
    /* variable que contiene la localizacion del archivo xml*/
    public UsuariosXML() {
    /*  constructor por defecto que inicia los valores para trabajar
     *  con el documento xml
     */
        try {
            SAXBuilder builder = new SAXBuilder(false); //parse que maneja el XMl
            Document doc = builder.build(fileLocation);
            root = doc.getRootElement();
        } catch (JDOMException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("No se pudo iniciar la operacion por: " + ex.getMessage());
        }
    }
  
    private Element UsuariotoXmlElement(Usuario nUsuario) {
  /*Aqui lleno todo el contexto que le voy a insertar al archivo, es decir
    el nodo proncipal que es Estudiante con los atributos que le corresponden,
    los cuales seria cedula,nombre y apellido,etc. Debes ser muuuuy preciso en
    este llenado, es decir, indicar los atributos con pelos y señales exactamente
    como están en la Clase, de lo contrario la tabla XML no se generará y no
    se produzca ningún error que te advierta que falta un acento, un espacio u
   otro símbolo     
   */     
     Element Usuariotrans = new Element("Usuario");//nombre de la Clase
     Element nombre = new Element("nombre"); 
     nombre.setText(nUsuario.getNombre()); 
     Element user = new Element("user");//se crea cada etiqueta del XML
     user.setText(nUsuario.getUser());//asocia el valor a la etiqueta 
     Element email = new Element("email");
     email.setText(nUsuario.getEmail());
     Element contrasena = new Element("contrasena");
     contrasena.setText(nUsuario.getContrasena());
     Usuariotrans.addContent(nombre); //se pasan los valores al documento XML
     Usuariotrans.addContent(user);
     Usuariotrans.addContent(email);
     Usuariotrans.addContent(contrasena);
     return Usuariotrans;
  }

 private Usuario UsuarioToObject(Element element) throws ParseException {
   /*Método que retorna un Estudiante. A este metodo se le manda un Element y con
    sus datos se hará los pasos requeridos para crear el objeto Estudiante*/
        Usuario nUsuario = new Usuario(element.getChildText("user"),element.getChildText("nombre"),
                element.getChildText("contrasena"), element.getChildText("email"));
        return nUsuario;
    }

   
  private boolean updateDocument() {
   /* método para guardar en el documento Xml los cambios efectuados
    * @return true si se cumplió la operacion con éxito, false en caso contrario*/
        try {
            XMLOutputter out = new XMLOutputter(org.jdom.output.Format.getPrettyFormat());
            FileOutputStream file = new FileOutputStream(fileLocation);
            out.output(root, file);
            file.flush();
            file.close();
            return true;
        } catch (Exception e) {
            System.out.println("error: " + e.getMessage());
            return false;
        }
    }

    public static Element buscar(List raiz, String dato) {
   /* Operacion que busca un elemento que cumpla con una condicion en el id del xml
     * @param raiz = raiz del documento xml
     * @param dato = elemento a buscar.
     * @return retorna el elemento si existe con la condicion, en caso contrario retorna null */
      Iterator i = raiz.iterator();
      while (i.hasNext()) {
         Element e = (Element) i.next();
         if (dato.equals(e.getChild("user").getText())) {
             return e;
            }
        }
      return null;
    }

   
    public boolean agregarUsuario(Usuario nUsuario) {
   // @return valor boleano con la condición de éxito     
        root.addContent(UsuariotoXmlElement(nUsuario));
        boolean  resultado = updateDocument();
        return resultado;
    }

    public Usuario buscarUsuario(String user) {
    /* @param cedula número de cedula del Estudiante a buscar
    * @return objeto Estudiante con sus datos segun busqueda*/
      Element aux = new Element("Usuario");
      List Usuarios = this.root.getChildren("Usuario");
      while (aux != null) {
        aux = UsuariosXML.buscar(Usuarios, user);
        if (aux != null) {
           try {
                return UsuarioToObject(aux);
           } catch (ParseException ex) {
                System.out.println(ex.getMessage());
           }
       }
     }
       return null;
   }

    public boolean actualizarUsuario(Usuario nUsuario, String user) {
    /* @param Estudiante objeto Estudiante a actualizar
     * @return valor booleano con la condición de éxito */
        boolean resultado = false;
        Element aux = new Element("Usuario");
        List Usuarios = this.root.getChildren("Usuario");
        while (aux != null) {
            aux = UsuariosXML.buscar(Usuarios, user);
            if (aux != null) {
                Usuarios.remove(aux);
                resultado = updateDocument();
            }
        }
        agregarUsuario(nUsuario);
        return resultado;
    }

    public boolean borrarUsuario(String user) {
    /* @param cedula cédula del Estudiante a borrar
    * @return valor booleano con la condición de éxito */ 
        boolean resultado = false;
        Element aux = new Element("Usuario");
        List Usuarios = this.root.getChildren("Usuario");
        while (aux != null) {
            aux = UsuariosXML.buscar(Usuarios, user);
            if (aux != null) {
                Usuarios.remove(aux);
                resultado = updateDocument();
            }
        }
        return resultado;
    }

  public ArrayList<Usuario> todosLosUsuarios() {
    /* Para obtener todas las Personas registradas
     * @return ArrayList con todos los objetos Estudiante  */
      ArrayList<Usuario> resultado = new ArrayList<Usuario>();
      for (Object it : root.getChildren()) {
            Element xmlElem = (Element) it;
            try {
                resultado.add(UsuarioToObject(xmlElem));
            } catch (ParseException ex) {
                System.out.println(ex.getMessage());
            }
        }
        return resultado;
    }

}

